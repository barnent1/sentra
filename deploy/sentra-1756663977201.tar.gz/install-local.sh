#!/usr/bin/env bash
set -euo pipefail

# Sentra Local Tools Installer
# Installs guard, bridge, and launcher scripts for local development

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    error "This script should not be run as root"
fi

log "🏠 Installing Sentra local development tools..."

# Create directories
log "📁 Creating directories..."
mkdir -p ~/bin
mkdir -p ~/.config/sentra

# Install guard script
log "🛡️ Installing Sentra Guard..."
cp "$SCRIPT_DIR/services/guard/sentra-guard.sh" ~/.sentra-guard.sh
chmod +x ~/.sentra-guard.sh

# Install bridge service
log "🌉 Installing Sentra Bridge..."
cp "$SCRIPT_DIR/services/bridge/sentra-bridge.py" ~/bin/sentra-bridge.py
chmod +x ~/bin/sentra-bridge.py

# Install tmux launcher
log "📺 Installing Sentra Start..."
cp "$SCRIPT_DIR/services/scripts/sentra-start" ~/bin/sentra-start
chmod +x ~/bin/sentra-start

# Check Python dependencies
log "🐍 Checking Python dependencies..."
if ! python3 -c "import httpx, openai" 2>/dev/null; then
    warn "Missing Python dependencies. Installing..."
    if command -v pip3 &>/dev/null; then
        pip3 install --user httpx openai
    elif command -v pip &>/dev/null; then
        pip install --user httpx openai
    else
        error "pip not found. Please install: pip3 install httpx openai"
    fi
fi

# Check if ~/bin is in PATH
if [[ ":$PATH:" != *":$HOME/bin:"* ]]; then
    warn "~/bin is not in your PATH"
    echo "Add this to your ~/.bashrc or ~/.zshrc:"
    echo "export PATH=\"\$HOME/bin:\$PATH\""
fi

# Detect shell and offer to add configuration
SHELL_RC=""
if [[ "$SHELL" == *"zsh"* ]]; then
    SHELL_RC="$HOME/.zshrc"
elif [[ "$SHELL" == *"bash"* ]]; then
    SHELL_RC="$HOME/.bashrc"
fi

if [[ -n "$SHELL_RC" ]]; then
    echo
    read -p "Add Sentra configuration to $SHELL_RC? [y/N]: " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        log "📝 Adding Sentra configuration to $SHELL_RC..."
        
        # Add configuration block
        cat >> "$SHELL_RC" << 'EOF'

# Sentra Configuration
export SENTRA_URL="${SENTRA_URL:-https://sentra.yourdomain.com}"
export SENTRA_API_TOKEN="${SENTRA_API_TOKEN:-your-api-token-here}"
export SENTRA_MACHINE_ID="${SENTRA_MACHINE_ID:-$(hostname)-$(whoami)}"
export OPENAI_API_KEY="${OPENAI_API_KEY:-}"

# Auto-load Sentra Guard (optional - comment out if not wanted)
if [[ -f ~/.sentra-guard.sh ]]; then
    source ~/.sentra-guard.sh
fi
EOF
        
        log "✅ Configuration added to $SHELL_RC"
        log "⚠️  Please edit $SHELL_RC to set your actual API tokens!"
    fi
fi

# Offer to install bridge service
echo
read -p "Install bridge service to auto-start on login? [y/N]: " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    SYSTEM=$(uname -s)
    if [[ "$SYSTEM" == "Darwin" ]]; then
        # macOS launchd service
        log "🍎 Installing macOS launch agent..."
        mkdir -p ~/Library/LaunchAgents
        
        cat > ~/Library/LaunchAgents/com.sentra.bridge.plist << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.sentra.bridge</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/bin/python3</string>
        <string>$HOME/bin/sentra-bridge.py</string>
    </array>
    <key>EnvironmentVariables</key>
    <dict>
        <key>SENTRA_URL</key>
        <string>\${SENTRA_URL}</string>
        <key>SENTRA_API_TOKEN</key>
        <string>\${SENTRA_API_TOKEN}</string>
        <key>SENTRA_MACHINE_ID</key>
        <string>\${SENTRA_MACHINE_ID}</string>
        <key>OPENAI_API_KEY</key>
        <string>\${OPENAI_API_KEY}</string>
    </dict>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$HOME/.sentra-bridge.log</string>
    <key>StandardErrorPath</key>
    <string>$HOME/.sentra-bridge.log</string>
</dict>
</plist>
EOF
        
        log "✅ Launch agent installed"
        log "To start: launchctl load ~/Library/LaunchAgents/com.sentra.bridge.plist"
        
    elif [[ "$SYSTEM" == "Linux" ]]; then
        # Linux systemd user service
        log "🐧 Installing systemd user service..."
        mkdir -p ~/.config/systemd/user
        
        cat > ~/.config/systemd/user/sentra-bridge.service << EOF
[Unit]
Description=Sentra Bridge Service
After=network.target

[Service]
Type=simple
ExecStart=$HOME/bin/sentra-bridge.py
Environment=SENTRA_URL=\${SENTRA_URL}
Environment=SENTRA_API_TOKEN=\${SENTRA_API_TOKEN}
Environment=SENTRA_MACHINE_ID=\${SENTRA_MACHINE_ID}
Environment=OPENAI_API_KEY=\${OPENAI_API_KEY}
Restart=always
RestartSec=10
StandardOutput=append:$HOME/.sentra-bridge.log
StandardError=append:$HOME/.sentra-bridge.log

[Install]
WantedBy=default.target
EOF
        
        log "✅ Systemd service installed"
        log "To enable: systemctl --user enable sentra-bridge"
        log "To start: systemctl --user start sentra-bridge"
    else
        warn "Auto-start not supported on $SYSTEM"
    fi
fi

echo
log "🎉 Sentra local tools installation complete!"
echo
echo -e "${BLUE}Next steps:${NC}"
echo "1. Edit your shell configuration to set SENTRA_URL and SENTRA_API_TOKEN"
echo "2. Restart your shell or run: source $SHELL_RC"
echo "3. Test the guard: sentra-guard-test"
echo "4. Start a development session: sentra-start ~/Projects/myproject"
echo
echo -e "${BLUE}Installed files:${NC}"
echo "- ~/.sentra-guard.sh (command guard)"
echo "- ~/bin/sentra-bridge.py (approval bridge)"
echo "- ~/bin/sentra-start (tmux launcher)"
echo
echo -e "${GREEN}Installation successful! 🚀${NC}"