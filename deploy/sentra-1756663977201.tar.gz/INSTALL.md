# Sentra Installation Guide

Complete setup instructions for the Sentra observability and orchestration system.

## Prerequisites

### Server Requirements (Lightsail/VPS)
- Ubuntu 24.04 LTS
- 2 GB RAM minimum (4 GB recommended)
- 20 GB storage minimum
- Sudo access

### Local Development Machine
- macOS or Linux
- tmux installed
- Python 3.9+ (for bridge service)
- Claude Code CLI tool

### External Services
- **Pushover Account**: For push notifications
- **OpenAI API Key**: For text-to-speech notifications
- **Domain Name**: For SSL certificates (optional but recommended)

## Phase 1: Server Setup

### 1.1 Prepare Your Environment

Create accounts and get API keys:

1. **Pushover Setup**:
   - Sign up at https://pushover.net
   - Create a new application
   - Note your User Key and App Token

2. **OpenAI Setup**:
   - Get API key from https://platform.openai.com
   - Ensure you have credits available

3. **Domain Setup** (recommended):
   - Point your domain to your server's IP
   - Or use the server's IP directly for testing

### 1.2 Clone and Configure

```bash
# On your server
git clone <your-sentra-repo>
cd sentra

# Copy and edit environment file
cp .env.example .env
nano .env
```

Configure your `.env` file:
```bash
# Pushover Integration
PUSHOVER_APP_TOKEN=your_pushover_app_token_here
PUSHOVER_USER_KEY=your_pushover_user_key_here

# OpenAI API for TTS
OPENAI_API_KEY=sk-your_openai_api_key_here

# Server Configuration
SENTRA_PUBLIC_URL=https://your-domain.com
SENTRA_API_TOKEN=your-secure-random-token-here

# Database Configuration
POSTGRES_USER=sentra
POSTGRES_PASSWORD=your-secure-database-password
POSTGRES_DB=sentra
DATABASE_URL=postgresql://sentra:your-secure-database-password@postgres:5432/sentra

# Domain for Caddy (optional)
DOMAIN=your-domain.com
```

### 1.3 Run Bootstrap Script

```bash
# Make bootstrap script executable
chmod +x services/scripts/bootstrap.sh

# Run bootstrap (will install Docker, start services)
./services/scripts/bootstrap.sh
```

The bootstrap script will:
- Install Docker and Docker Compose
- Install and configure Caddy
- Set up firewall rules
- Create sentra user and directories
- Start all services
- Set up systemd services for auto-start

### 1.4 Verify Server Installation

```bash
# Check service status
sudo systemctl status sentra-api
sudo systemctl status sentra-orchestrator

# Check containers
docker-compose ps

# Test API
curl https://your-domain.com/health
```

## Phase 2: Local Development Setup

### 2.1 Install Prerequisites

**macOS:**
```bash
# Install tmux if not already installed
brew install tmux

# Install Python dependencies for bridge
pip3 install httpx openai
```

**Linux:**
```bash
# Ubuntu/Debian
sudo apt install tmux python3-pip

# Install Python dependencies
pip3 install httpx openai
```

### 2.2 Install Local Tools

```bash
# Copy local development tools
cp services/guard/sentra-guard.sh ~/.sentra-guard.sh
cp services/bridge/sentra-bridge.py ~/bin/sentra-bridge.py
cp services/scripts/sentra-start ~/bin/sentra-start

# Make scripts executable
chmod +x ~/.sentra-guard.sh
chmod +x ~/bin/sentra-bridge.py  
chmod +x ~/bin/sentra-start

# Add ~/bin to PATH if not already there
echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### 2.3 Configure Local Environment

Add to your `~/.bashrc` or `~/.zshrc`:

```bash
# Sentra Configuration
export SENTRA_URL="https://your-domain.com"
export SENTRA_API_TOKEN="your-secure-random-token-here"
export SENTRA_MACHINE_ID="$(hostname)-$(whoami)"
export OPENAI_API_KEY="sk-your_openai_api_key_here"

# Auto-load guard in new shells (optional but recommended)
if [[ -f ~/.sentra-guard.sh ]]; then
    source ~/.sentra-guard.sh
fi
```

Reload your shell:
```bash
source ~/.bashrc  # or ~/.zshrc
```

### 2.4 Start Bridge Service

The bridge service polls the server for approvals and replays commands.

**Option 1: Run manually**
```bash
sentra-bridge.py
```

**Option 2: Run as background service (recommended)**

**macOS (launchd):**
```bash
# Create launch agent
cat > ~/Library/LaunchAgents/com.sentra.bridge.plist << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.sentra.bridge</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/bin/python3</string>
        <string>$(echo $HOME)/bin/sentra-bridge.py</string>
    </array>
    <key>EnvironmentVariables</key>
    <dict>
        <key>SENTRA_URL</key>
        <string>https://your-domain.com</string>
        <key>SENTRA_API_TOKEN</key>
        <string>your-secure-random-token-here</string>
        <key>SENTRA_MACHINE_ID</key>
        <string>$(hostname)-$(whoami)</string>
        <key>OPENAI_API_KEY</key>
        <string>sk-your_openai_api_key_here</string>
    </dict>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
</dict>
</plist>
EOF

# Load and start
launchctl load ~/Library/LaunchAgents/com.sentra.bridge.plist
launchctl start com.sentra.bridge
```

**Linux (systemd user service):**
```bash
# Create user service directory
mkdir -p ~/.config/systemd/user

# Create service file
cat > ~/.config/systemd/user/sentra-bridge.service << EOF
[Unit]
Description=Sentra Bridge Service
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 %h/bin/sentra-bridge.py
Environment=SENTRA_URL=https://your-domain.com
Environment=SENTRA_API_TOKEN=your-secure-random-token-here
Environment=SENTRA_MACHINE_ID=$(hostname)-$(whoami)
Environment=OPENAI_API_KEY=sk-your_openai_api_key_here
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
EOF

# Reload and start
systemctl --user daemon-reload
systemctl --user enable sentra-bridge
systemctl --user start sentra-bridge

# Check status
systemctl --user status sentra-bridge
```

## Phase 3: Usage

### 3.1 Test the System

```bash
# Test guard functionality
sentra-guard-test

# Test a command that should require approval
rm -rf /some/important/file
# Should see: "🛡️ Sentra Guard: Approval requested"
# Check your phone for push notification
```

### 3.2 Start Development Session

```bash
# Launch tmux session with Sentra integration
sentra-start ~/Projects/my-project MyProject

# Or with custom session name
sentra-start ~/Projects/my-project MyProject dev-session
```

This creates a tmux session with:
- Main window: Claude Code + development server
- Monitor window: htop, git status, Sentra status

### 3.3 Normal Workflow

1. **Start session**: `sentra-start ~/Projects/myproject`
2. **Work normally**: Commands are monitored automatically
3. **Dangerous commands**: Get blocked and request approval
4. **Phone notification**: Approve/reject via push notification
5. **Auto-execution**: Approved commands run automatically

## Troubleshooting

### Server Issues

```bash
# Check logs
docker-compose logs -f api
docker-compose logs -f orchestrator
journalctl -u sentra-api -f

# Restart services
docker-compose restart
sudo systemctl restart sentra-api
```

### Local Issues

```bash
# Check guard status
sentra-guard-status

# Check bridge logs
tail -f ~/.sentra-bridge.log

# Test connectivity
curl -H "Authorization: Bearer $SENTRA_API_TOKEN" "$SENTRA_URL/health"

# Restart bridge service
# macOS:
launchctl stop com.sentra.bridge && launchctl start com.sentra.bridge

# Linux:
systemctl --user restart sentra-bridge
```

### Common Problems

1. **Commands not being blocked**: Check that guard is loaded with `sentra-guard-status`
2. **Approvals not replaying**: Check bridge service is running and has correct API token
3. **Push notifications not working**: Verify Pushover tokens in server `.env`
4. **Voice not playing**: Ensure OpenAI API key is configured locally

## Security Notes

- **API tokens**: Keep your `SENTRA_API_TOKEN` secure and unique per machine
- **Database passwords**: Use strong, unique passwords
- **Firewall**: Server only exposes ports 80, 443, and SSH
- **TLS**: Caddy automatically handles SSL certificates
- **Local bridge**: Only polls server, never accepts incoming connections

## Updating

### Server Updates
```bash
cd /opt/sentra
git pull
docker-compose build
docker-compose up -d
```

### Local Updates
```bash
# Update local tools
cp services/guard/sentra-guard.sh ~/.sentra-guard.sh
cp services/bridge/sentra-bridge.py ~/bin/sentra-bridge.py
cp services/scripts/sentra-start ~/bin/sentra-start

# Restart bridge service to pick up changes
```