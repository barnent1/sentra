#!/usr/bin/env python3
"""
Sentra Bridge - Local service that polls for approvals and replays commands
Run this as a background daemon on your development machine.
"""

import asyncio
import json
import logging
import os
import platform
import signal
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import httpx
from openai import OpenAI

# Configuration
SENTRA_URL = os.environ.get("SENTRA_URL", "https://sentra.yourdomain.com")
SENTRA_API_TOKEN = os.environ.get("SENTRA_API_TOKEN")
SENTRA_MACHINE_ID = os.environ.get("SENTRA_MACHINE_ID", f"{platform.node()}-{os.getenv('USER')}")
POLL_INTERVAL = int(os.environ.get("SENTRA_POLL_INTERVAL", "2"))  # seconds
LOG_LEVEL = os.environ.get("SENTRA_LOG_LEVEL", "INFO")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

# Setup logging
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper()),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(os.path.expanduser("~/.sentra-bridge.log")),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("sentra-bridge")

class SentraBridge:
    """Main bridge service that handles approval polling and command replay."""
    
    def __init__(self):
        self.running = False
        self.http_client = None
        self.openai_client = None
        
        # Validate configuration
        if not SENTRA_API_TOKEN:
            raise ValueError("SENTRA_API_TOKEN environment variable is required")
        
        if OPENAI_API_KEY:
            self.openai_client = OpenAI(api_key=OPENAI_API_KEY)
        
        logger.info(f"Initialized Sentra Bridge for machine: {SENTRA_MACHINE_ID}")
        logger.info(f"Server: {SENTRA_URL}")
        logger.info(f"Poll interval: {POLL_INTERVAL}s")
    
    async def start(self):
        """Start the bridge service."""
        self.running = True
        self.http_client = httpx.AsyncClient(
            base_url=SENTRA_URL,
            timeout=30.0,
            headers={"Authorization": f"Bearer {SENTRA_API_TOKEN}"}
        )
        
        logger.info("🌉 Sentra Bridge started")
        
        # Test connection
        try:
            response = await self.http_client.get("/health")
            if response.status_code == 200:
                logger.info("✅ Server connection verified")
            else:
                logger.warning(f"⚠️ Server health check returned {response.status_code}")
        except Exception as e:
            logger.error(f"❌ Failed to connect to server: {e}")
            logger.info("Will continue polling - server might be starting up")
        
        # Main polling loop
        while self.running:
            try:
                await self._poll_approvals()
                await asyncio.sleep(POLL_INTERVAL)
            except KeyboardInterrupt:
                logger.info("Received interrupt signal")
                break
            except Exception as e:
                logger.error(f"Error in polling loop: {e}", exc_info=True)
                await asyncio.sleep(POLL_INTERVAL * 2)  # Back off on errors
    
    async def stop(self):
        """Stop the bridge service."""
        logger.info("🛑 Stopping Sentra Bridge...")
        self.running = False
        if self.http_client:
            await self.http_client.aclose()
    
    async def _poll_approvals(self):
        """Poll server for pending approvals."""
        try:
            response = await self.http_client.get(
                "/api/approvals/pending",
                params={"machine_id": SENTRA_MACHINE_ID}
            )
            
            if response.status_code != 200:
                logger.error(f"Failed to poll approvals: HTTP {response.status_code}")
                return
            
            data = response.json()
            approvals = data.get("items", [])
            
            if not approvals:
                logger.debug("No pending approvals")
                return
            
            logger.info(f"📋 Found {len(approvals)} pending approvals")
            
            for approval in approvals:
                await self._process_approval(approval)
                
        except httpx.RequestError as e:
            logger.error(f"Network error polling approvals: {e}")
        except Exception as e:
            logger.error(f"Unexpected error polling approvals: {e}", exc_info=True)
    
    async def _process_approval(self, approval: Dict):
        """Process a single approval item."""
        approval_id = approval["id"]
        command = approval["command"]
        status = approval["status"]
        tmux_target = approval.get("tmux_target", "sentra")
        risk_level = approval.get("risk_level", "medium")
        
        logger.info(f"Processing approval {approval_id}: {status} - {command}")
        
        if status == "approved":
            # Play voice notification
            await self._play_voice_notification(f"Executing approved command: {command[:50]}")
            
            # Execute command via tmux
            success = await self._replay_command(tmux_target, command)
            
            if success:
                # Mark as completed
                await self._mark_approval_completed(approval_id)
                logger.info(f"✅ Successfully executed: {command}")
            else:
                logger.error(f"❌ Failed to execute: {command}")
        
        elif status == "rejected":
            # Play voice notification
            await self._play_voice_notification(f"Command rejected: {command[:50]}")
            logger.info(f"🚫 Command rejected: {command}")
            
            # Mark as completed (processed)
            await self._mark_approval_completed(approval_id)
    
    async def _replay_command(self, tmux_target: str, command: str) -> bool:
        """Replay approved command to tmux session."""
        try:
            # Parse tmux target (session:window.pane format)
            if ":" not in tmux_target:
                tmux_target = f"sentra:{tmux_target}"
            
            # Construct tmux send-keys command with APPROVE=1 prefix
            full_command = f"APPROVE=1 {command}"
            
            tmux_cmd = [
                "tmux", 
                "send-keys", 
                "-t", tmux_target,
                full_command,
                "C-m"  # Enter key
            ]
            
            logger.debug(f"Executing tmux command: {' '.join(tmux_cmd)}")
            
            # Execute tmux command
            result = subprocess.run(
                tmux_cmd,
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                logger.info(f"📤 Command sent to tmux target: {tmux_target}")
                return True
            else:
                logger.error(f"tmux command failed: {result.stderr}")
                
                # Try fallback to default session
                if tmux_target != "sentra":
                    logger.info("Trying fallback to default sentra session")
                    fallback_cmd = tmux_cmd.copy()
                    fallback_cmd[3] = "sentra"
                    
                    fallback_result = subprocess.run(
                        fallback_cmd,
                        capture_output=True,
                        text=True,
                        timeout=10
                    )
                    
                    if fallback_result.returncode == 0:
                        logger.info("✅ Fallback to default session succeeded")
                        return True
                
                return False
                
        except subprocess.TimeoutExpired:
            logger.error("tmux command timed out")
            return False
        except Exception as e:
            logger.error(f"Error replaying command: {e}")
            return False
    
    async def _play_voice_notification(self, text: str):
        """Play text-to-speech notification locally."""
        try:
            if not self.openai_client:
                logger.debug("No OpenAI client - skipping voice notification")
                return
            
            # Generate speech
            response = self.openai_client.audio.speech.create(
                model="tts-1",
                voice="alloy",
                input=text[:200],  # Limit length
                response_format="mp3"
            )
            
            # Save to temporary file
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as temp_file:
                temp_file.write(response.content)
                temp_path = temp_file.name
            
            # Play audio based on platform
            await self._play_audio_file(temp_path)
            
            # Cleanup
            os.unlink(temp_path)
            
        except Exception as e:
            logger.error(f"Failed to play voice notification: {e}")
    
    async def _play_audio_file(self, file_path: str):
        """Play audio file using platform-appropriate command."""
        try:
            system = platform.system().lower()
            
            if system == "darwin":  # macOS
                cmd = ["afplay", file_path]
            elif system == "linux":
                # Try multiple audio players
                for player in ["aplay", "paplay", "mpg123", "ffplay"]:
                    if subprocess.run(["which", player], capture_output=True).returncode == 0:
                        cmd = [player, file_path]
                        break
                else:
                    logger.warning("No audio player found on Linux")
                    return
            else:
                logger.warning(f"Audio playback not supported on {system}")
                return
            
            # Play audio in background
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            
            # Don't wait for completion - let it play in background
            logger.debug(f"Started audio playback: {' '.join(cmd)}")
            
        except Exception as e:
            logger.error(f"Error playing audio: {e}")
    
    async def _mark_approval_completed(self, approval_id: str):
        """Mark an approval as completed."""
        try:
            response = await self.http_client.post(
                f"/api/approvals/{approval_id}/decision",
                json={"decision": "completed"}
            )
            
            if response.status_code == 200:
                logger.debug(f"Marked approval {approval_id} as completed")
            else:
                logger.error(f"Failed to mark approval completed: HTTP {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error marking approval completed: {e}")

def setup_signal_handlers(bridge: SentraBridge):
    """Setup signal handlers for graceful shutdown."""
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}")
        asyncio.create_task(bridge.stop())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

async def main():
    """Main entry point."""
    bridge = SentraBridge()
    setup_signal_handlers(bridge)
    
    try:
        await bridge.start()
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    finally:
        await bridge.stop()
        logger.info("Sentra Bridge stopped")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nSentra Bridge stopped by user")
        sys.exit(0)