#!/usr/bin/env bash
# Sentra Guard - Command approval system for dangerous operations
# Source this file in your shell: source ~/.sentra-guard.sh

# Configuration - set these in your environment
export SENTRA_URL="${SENTRA_URL:-https://sentra.yourdomain.com}"
export SENTRA_API_TOKEN="${SENTRA_API_TOKEN:-your-api-token}"
export SENTRA_MACHINE_ID="${SENTRA_MACHINE_ID:-$(hostname)-$(whoami)}"
export SENTRA_PROJECT="${SENTRA_PROJECT:-default}"
export SENTRA_LOG="${SENTRA_LOG:-$HOME/.sentra-guard.log}"

# Colors for output
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Internal state
_SENTRA_GUARD_ACTIVE=1

# Logging function
_guard_log() {
    echo "[$(date +'%F %T')] $*" >> "$SENTRA_LOG"
}

# Check if command requires approval
_guard_needs_approval() {
    local cmd="$1"
    local first_word="${cmd%% *}"
    
    # Commands that ALWAYS need approval (high risk)
    case "$first_word" in
        rm|rmdir|unlink)
            # Allow safe rm patterns
            case "$cmd" in
                "rm -rf /tmp/"*|"rm /tmp/"*) return 1 ;;  # temp files ok
                "rm "*".log"|"rm "*".tmp") return 1 ;;     # log/temp files ok
                *) return 0 ;;  # everything else needs approval
            esac
            ;;
        sudo|su)
            # All sudo commands need approval
            return 0
            ;;
        chmod|chown|chgrp)
            # Permission changes need approval
            return 0
            ;;
        mv|cp)
            # File operations outside safe directories
            case "$cmd" in
                *"/etc/"*|*"/usr/"*|*"/var/"*|*"/opt/"*) return 0 ;;
                *) return 1 ;;
            esac
            ;;
        git)
            # Git operations that need approval
            case "$cmd" in
                "git push"*|"git push "*) return 0 ;;
                "git merge"*|"git rebase"*) return 0 ;;
                "git reset --hard"*) return 0 ;;
                "git clean -fd"*) return 0 ;;
                *) return 1 ;;
            esac
            ;;
        docker|docker-compose|podman)
            # Container operations
            case "$cmd" in
                *"--rm"*|*"rm"*|*"down"*|*"stop"*) return 0 ;;
                *) return 1 ;;
            esac
            ;;
        npm|yarn|pnpm)
            # Package manager operations
            case "$cmd" in
                *"install"*|*"uninstall"*|*"publish"*) return 0 ;;
                *) return 1 ;;
            esac
            ;;
        pip|pip3)
            # Python package operations
            case "$cmd" in
                *"install"*|*"uninstall"*) return 0 ;;
                *) return 1 ;;
            esac
            ;;
        curl|wget)
            # Network operations that pipe to shell
            case "$cmd" in
                *"| sh"*|*"| bash"*|*"| sudo"*) return 0 ;;
                *) return 1 ;;
            esac
            ;;
        dd|fdisk|mkfs|mount|umount)
            # Disk operations - always need approval
            return 0
            ;;
        systemctl|service)
            # System service operations
            return 0
            ;;
        make)
            # Build operations that might modify system
            case "$cmd" in
                "make install"*|"make uninstall"*) return 0 ;;
                *) return 1 ;;
            esac
            ;;
    esac
    
    # Check for dangerous patterns
    case "$cmd" in
        *"--force"*|*"-f"*) 
            # Force flags often bypass safety checks
            case "$first_word" in
                ls|cat|grep|find|echo|printf) return 1 ;;  # safe commands
                *) return 0 ;;
            esac
            ;;
        *"> /dev/"*|*"| dd"*|*"> /"*) 
            # Redirecting to system locations
            return 0 
            ;;
        *"$(curl"*|*"$(wget"*|*"\$(curl"*|*"\$(wget"*)
            # Command substitution with network calls
            return 0
            ;;
    esac
    
    return 1  # Default: allow
}

# Request approval from Sentra server
_guard_request_approval() {
    local cmd="$*"
    local tmux_target="${TMUX_PANE:-unknown}"
    
    _guard_log "REQUESTING APPROVAL: $cmd"
    
    # Determine risk level
    local risk_level="medium"
    case "$cmd" in
        *"rm -rf"*|*"--force"*|*"sudo rm"*) risk_level="high" ;;
        *"dd"*|*"mkfs"*|*"fdisk"*) risk_level="critical" ;;
        *"git push"*|*"npm publish"*) risk_level="medium" ;;
    esac
    
    # Send approval request
    local response
    response=$(curl -s -w "%{http_code}" \
        -H "Authorization: Bearer $SENTRA_API_TOKEN" \
        -H "Content-Type: application/json" \
        -X POST "$SENTRA_URL/api/approvals" \
        -d "{
            \"project\": \"$SENTRA_PROJECT\",
            \"machine_id\": \"$SENTRA_MACHINE_ID\",
            \"command\": \"$cmd\",
            \"tmux_target\": \"$tmux_target\",
            \"risk_level\": \"$risk_level\"
        }" 2>/dev/null)
    
    local http_code="${response: -3}"
    local body="${response%???}"
    
    if [[ "$http_code" == "200" ]]; then
        echo -e "${BLUE}🛡️  Sentra Guard:${NC} Approval requested for: ${YELLOW}$cmd${NC}"
        echo -e "${BLUE}📱${NC} Check your phone for push notification"
        _guard_log "APPROVAL_REQUESTED: $cmd (risk: $risk_level)"
        return 0
    else
        echo -e "${RED}❌ Sentra Guard:${NC} Failed to request approval (HTTP $http_code)"
        _guard_log "APPROVAL_REQUEST_FAILED: $cmd (HTTP: $http_code)"
        return 1
    fi
}

# Check if we have approval to run a command
_guard_check_approval() {
    local cmd="$*"
    
    # Check if APPROVE=1 environment variable is set (from bridge)
    if [[ "${APPROVE:-0}" == "1" ]]; then
        _guard_log "APPROVED_EXECUTION: $cmd"
        # Clear the approval flag
        unset APPROVE
        return 0
    fi
    
    return 1
}

# Main gate function
_guard_gate() {
    local original_cmd="$*"
    
    # Skip if guard is disabled
    [[ "${_SENTRA_GUARD_ACTIVE:-1}" != "1" ]] && return 0
    
    # Skip if we're in an approval execution
    [[ "${APPROVE:-0}" == "1" ]] && return 0
    
    # Check if command needs approval
    if ! _guard_needs_approval "$original_cmd"; then
        return 0  # Allow without approval
    fi
    
    # Check if we already have approval for this command
    if _guard_check_approval "$original_cmd"; then
        return 0  # Execute with approval
    fi
    
    # Request approval
    printf '\a'  # System beep
    _guard_request_approval "$original_cmd"
    
    echo -e "${YELLOW}⏳ Waiting for approval...${NC}"
    echo -e "${BLUE}💡 The command will be executed automatically once approved${NC}"
    
    # Return error code to prevent execution
    return 42
}

# Wrapper function generator
_guard_wrap() {
    local cmd_name="$1"
    eval "
        $cmd_name() {
            if _guard_gate $cmd_name \"\$@\"; then
                command $cmd_name \"\$@\"
            else
                local exit_code=\$?
                if [[ \$exit_code == 42 ]]; then
                    echo -e \"${RED}🚫 Command blocked pending approval${NC}\"
                    return 1
                else
                    return \$exit_code
                fi
            fi
        }
    "
}

# Guard control functions
sentra-guard-disable() {
    _SENTRA_GUARD_ACTIVE=0
    echo -e "${YELLOW}⚠️  Sentra Guard disabled${NC}"
    _guard_log "GUARD_DISABLED"
}

sentra-guard-enable() {
    _SENTRA_GUARD_ACTIVE=1
    echo -e "${GREEN}✅ Sentra Guard enabled${NC}"
    _guard_log "GUARD_ENABLED"
}

sentra-guard-status() {
    if [[ "${_SENTRA_GUARD_ACTIVE:-1}" == "1" ]]; then
        echo -e "${GREEN}✅ Sentra Guard: ACTIVE${NC}"
        echo -e "   Server: $SENTRA_URL"
        echo -e "   Machine: $SENTRA_MACHINE_ID"
        echo -e "   Project: $SENTRA_PROJECT"
        echo -e "   Log: $SENTRA_LOG"
    else
        echo -e "${YELLOW}⚠️  Sentra Guard: DISABLED${NC}"
    fi
}

sentra-guard-test() {
    echo -e "${BLUE}🧪 Testing Sentra Guard...${NC}"
    echo "This should be allowed:"
    ls /tmp >/dev/null && echo -e "${GREEN}✅ ls allowed${NC}"
    
    echo "This should request approval:"
    _guard_gate "rm -rf /important/file"
    if [[ $? == 42 ]]; then
        echo -e "${GREEN}✅ Dangerous command blocked${NC}"
    else
        echo -e "${RED}❌ Dangerous command not blocked${NC}"
    fi
}

# Wrap dangerous commands
_guard_wrap rm
_guard_wrap mv
_guard_wrap chmod
_guard_wrap chown
_guard_wrap chgrp  
_guard_wrap sudo
_guard_wrap su
_guard_wrap git
_guard_wrap docker
_guard_wrap docker-compose
_guard_wrap npm
_guard_wrap yarn
_guard_wrap pnpm
_guard_wrap pip
_guard_wrap pip3
_guard_wrap systemctl
_guard_wrap service
_guard_wrap make
_guard_wrap dd
_guard_wrap fdisk
_guard_wrap mkfs
_guard_wrap mount
_guard_wrap umount

# Initialize guard
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    # Script was executed directly
    echo "Sentra Guard should be sourced, not executed directly."
    echo "Usage: source ~/.sentra-guard.sh"
    exit 1
else
    # Script was sourced
    _guard_log "GUARD_LOADED (machine: $SENTRA_MACHINE_ID, project: $SENTRA_PROJECT)"
    echo -e "${GREEN}🛡️  Sentra Guard loaded${NC} - type 'sentra-guard-status' for info"
fi