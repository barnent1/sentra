import asyncio
import logging
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import httpx
import schedule

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

class OrchestratorWorker:
    """Main orchestrator worker that manages tasks and agents."""
    
    def __init__(self):
        self.database_url = os.environ.get("DATABASE_URL")
        self.api_url = os.environ.get("SENTRA_API_URL", "http://api:8000")
        self.debug = os.environ.get("DEBUG", "false").lower() == "true"
        
        if not self.database_url:
            raise ValueError("DATABASE_URL environment variable is required")
        
        # Setup database
        self.engine = create_engine(self.database_url)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        
        # HTTP client for API calls
        self.http_client = httpx.AsyncClient(base_url=self.api_url, timeout=30.0)
        
        self.running = True
        logger.info("Orchestrator worker initialized")
    
    async def run(self):
        """Main worker loop."""
        logger.info("Starting orchestrator worker...")
        
        # Schedule periodic tasks
        schedule.every(30).seconds.do(self._schedule_expire_approvals)
        schedule.every(2).minutes.do(self._schedule_process_queued_tasks)
        schedule.every(5).minutes.do(self._schedule_check_agent_health)
        schedule.every(1).hours.do(self._schedule_cleanup_old_events)
        
        while self.running:
            try:
                # Run scheduled tasks
                schedule.run_pending()
                
                # Main orchestration tasks
                await self._process_queued_tasks()
                await self._monitor_running_tasks()
                await self._handle_blocked_tasks()
                await self._cleanup_stale_subagents()
                
                # Sleep between cycles
                await asyncio.sleep(10)
                
            except Exception as e:
                logger.error(f"Error in orchestrator main loop: {e}", exc_info=True)
                await asyncio.sleep(30)  # Back off on errors
    
    async def shutdown(self):
        """Graceful shutdown."""
        logger.info("Shutting down orchestrator worker...")
        self.running = False
        await self.http_client.aclose()
    
    # Scheduled maintenance tasks
    def _schedule_expire_approvals(self):
        """Schedule approval expiration (sync wrapper)."""
        asyncio.create_task(self._expire_old_approvals())
    
    def _schedule_process_queued_tasks(self):
        """Schedule task processing (sync wrapper)."""
        asyncio.create_task(self._process_queued_tasks())
    
    def _schedule_check_agent_health(self):
        """Schedule agent health checks (sync wrapper)."""
        asyncio.create_task(self._check_subagent_health())
    
    def _schedule_cleanup_old_events(self):
        """Schedule event cleanup (sync wrapper)."""
        asyncio.create_task(self._cleanup_old_events())
    
    # Core orchestration methods
    async def _process_queued_tasks(self):
        """Process tasks in the queue and assign to agents."""
        try:
            with self.SessionLocal() as db:
                # Get queued tasks ordered by priority
                result = db.execute(text("""
                    SELECT t.id, t.title, t.spec, t.priority, t.project_id, 
                           p.name as project_name, a.name as agent_name, a.role as agent_role
                    FROM tasks t
                    JOIN projects p ON t.project_id = p.id
                    LEFT JOIN agents a ON t.assigned_agent = a.id
                    WHERE t.status = 'queued'
                    ORDER BY t.priority ASC, t.created_at ASC
                    LIMIT 10
                """))
                
                queued_tasks = result.fetchall()
                
                if not queued_tasks:
                    logger.debug("No queued tasks found")
                    return
                
                logger.info(f"Processing {len(queued_tasks)} queued tasks")
                
                for task in queued_tasks:
                    try:
                        # Check for conflicts with running tasks
                        if await self._has_conflict(task.id, task.spec):
                            logger.info(f"Task {task.id} has conflicts, keeping in queue")
                            continue
                        
                        # Update task status to running
                        db.execute(text("""
                            UPDATE tasks SET status = 'running', updated_at = now()
                            WHERE id = :task_id
                        """), {"task_id": task.id})
                        
                        # Create event
                        db.execute(text("""
                            INSERT INTO events (project_id, task_id, agent_id, event_type, event_data)
                            VALUES (:project_id, :task_id, :agent_id, 'task_started', :event_data)
                        """), {
                            "project_id": task.project_id,
                            "task_id": task.id,
                            "agent_id": task.assigned_agent if hasattr(task, 'assigned_agent') else None,
                            "event_data": {
                                "title": task.title,
                                "agent": task.agent_name,
                                "priority": task.priority
                            }
                        })
                        
                        db.commit()
                        
                        logger.info(f"Started task {task.id}: {task.title[:50]}...")
                        
                        # If task has an agent, we could spawn a subagent here
                        # For now, we just mark it as running
                        
                    except Exception as e:
                        logger.error(f"Error processing task {task.id}: {e}")
                        db.rollback()
                        continue
                
        except Exception as e:
            logger.error(f"Error in _process_queued_tasks: {e}")
    
    async def _monitor_running_tasks(self):
        """Monitor running tasks for completion or issues."""
        try:
            with self.SessionLocal() as db:
                # Check for tasks running too long without updates
                cutoff_time = datetime.utcnow() - timedelta(hours=2)
                
                result = db.execute(text("""
                    SELECT t.id, t.title, t.updated_at, p.name as project_name
                    FROM tasks t
                    JOIN projects p ON t.project_id = p.id
                    WHERE t.status = 'running' 
                    AND t.updated_at < :cutoff_time
                    LIMIT 20
                """), {"cutoff_time": cutoff_time})
                
                stale_tasks = result.fetchall()
                
                for task in stale_tasks:
                    logger.warning(f"Task {task.id} ({task.title[:50]}) has been running for >2 hours without update")
                    
                    # Mark as blocked for review
                    db.execute(text("""
                        UPDATE tasks 
                        SET status = 'blocked', 
                            metadata = COALESCE(metadata, '{}') || '{"blocked_reason": "stale_execution"}'::jsonb,
                            updated_at = now()
                        WHERE id = :task_id
                    """), {"task_id": task.id})
                    
                    # Create event
                    db.execute(text("""
                        INSERT INTO events (project_id, task_id, event_type, event_data)
                        VALUES ((SELECT project_id FROM tasks WHERE id = :task_id), :task_id, 'task_blocked', :event_data)
                    """), {
                        "task_id": task.id,
                        "event_data": {"reason": "stale_execution", "duration_hours": 2}
                    })
                
                if stale_tasks:
                    db.commit()
                    logger.info(f"Marked {len(stale_tasks)} stale tasks as blocked")
                
        except Exception as e:
            logger.error(f"Error in _monitor_running_tasks: {e}")
    
    async def _handle_blocked_tasks(self):
        """Handle tasks that are blocked and may need intervention."""
        try:
            with self.SessionLocal() as db:
                # Get blocked tasks that might be ready to retry
                result = db.execute(text("""
                    SELECT t.id, t.title, t.metadata, t.updated_at
                    FROM tasks t
                    WHERE t.status = 'blocked'
                    AND t.updated_at < now() - interval '10 minutes'
                    LIMIT 10
                """))
                
                blocked_tasks = result.fetchall()
                
                for task in blocked_tasks:
                    # Simple retry logic - could be more sophisticated
                    block_reason = task.metadata.get('blocked_reason') if task.metadata else None
                    
                    if block_reason == 'stale_execution':
                        # Reset to queued for retry
                        db.execute(text("""
                            UPDATE tasks 
                            SET status = 'queued', 
                                metadata = COALESCE(metadata, '{}') || '{"retry_count": 1}'::jsonb,
                                updated_at = now()
                            WHERE id = :task_id
                        """), {"task_id": task.id})
                        
                        logger.info(f"Reset blocked task {task.id} to queued for retry")
                
                if blocked_tasks:
                    db.commit()
                
        except Exception as e:
            logger.error(f"Error in _handle_blocked_tasks: {e}")
    
    async def _has_conflict(self, task_id: str, task_spec: str) -> bool:
        """Check if a task conflicts with running tasks."""
        # Simple heuristic: check if multiple tasks mention the same file paths
        # This could be made more sophisticated with actual file parsing
        
        try:
            with self.SessionLocal() as db:
                result = db.execute(text("""
                    SELECT COUNT(*) as running_count
                    FROM tasks t
                    WHERE t.status = 'running'
                    AND t.id != :task_id
                    AND (
                        t.spec ILIKE ANY(
                            SELECT '%' || unnest(string_to_array(:task_spec, ' ')) || '%'
                            WHERE length(unnest(string_to_array(:task_spec, ' '))) > 10
                        )
                    )
                    LIMIT 1
                """), {"task_id": task_id, "task_spec": task_spec})
                
                count = result.scalar() or 0
                return count > 0
                
        except Exception as e:
            logger.error(f"Error checking task conflicts: {e}")
            return False
    
    async def _expire_old_approvals(self):
        """Mark expired approvals."""
        try:
            with self.SessionLocal() as db:
                result = db.execute(text("""
                    UPDATE approvals 
                    SET status = 'expired', updated_at = now()
                    WHERE status = 'pending' 
                    AND expires_at < now()
                    RETURNING id
                """))
                
                expired_ids = [row[0] for row in result.fetchall()]
                db.commit()
                
                if expired_ids:
                    logger.info(f"Expired {len(expired_ids)} old approvals")
                
        except Exception as e:
            logger.error(f"Error expiring approvals: {e}")
    
    async def _cleanup_stale_subagents(self):
        """Clean up subagents that haven't been seen recently."""
        try:
            with self.SessionLocal() as db:
                cutoff_time = datetime.utcnow() - timedelta(hours=4)
                
                result = db.execute(text("""
                    UPDATE subagents 
                    SET status = 'terminated'
                    WHERE status = 'active'
                    AND last_seen < :cutoff_time
                    RETURNING id
                """), {"cutoff_time": cutoff_time})
                
                terminated_ids = [row[0] for row in result.fetchall()]
                db.commit()
                
                if terminated_ids:
                    logger.info(f"Terminated {len(terminated_ids)} stale subagents")
                
        except Exception as e:
            logger.error(f"Error cleaning up subagents: {e}")
    
    async def _check_subagent_health(self):
        """Check health of active subagents."""
        try:
            with self.SessionLocal() as db:
                result = db.execute(text("""
                    SELECT s.id, s.tmux_target, s.machine_id, t.title
                    FROM subagents s
                    JOIN tasks t ON s.task_id = t.id
                    WHERE s.status = 'active'
                    AND s.last_seen < now() - interval '30 minutes'
                """))
                
                stale_agents = result.fetchall()
                
                for agent in stale_agents:
                    logger.warning(f"Subagent {agent.id} on {agent.machine_id} hasn't been seen in 30+ minutes")
                    # Could send notifications or take corrective action here
                
        except Exception as e:
            logger.error(f"Error checking subagent health: {e}")
    
    async def _cleanup_old_events(self):
        """Clean up old events to prevent database bloat."""
        try:
            with self.SessionLocal() as db:
                # Keep events for 30 days
                cutoff_date = datetime.utcnow() - timedelta(days=30)
                
                result = db.execute(text("""
                    DELETE FROM events 
                    WHERE created_at < :cutoff_date
                    AND event_type NOT IN ('approval_requested', 'task_created')
                """), {"cutoff_date": cutoff_date})
                
                deleted_count = result.rowcount
                db.commit()
                
                if deleted_count > 0:
                    logger.info(f"Cleaned up {deleted_count} old events")
                
        except Exception as e:
            logger.error(f"Error cleaning up old events: {e}")

async def main():
    """Main entry point."""
    worker = OrchestratorWorker()
    
    try:
        await worker.run()
    except KeyboardInterrupt:
        logger.info("Received interrupt signal")
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
    finally:
        await worker.shutdown()

if __name__ == "__main__":
    asyncio.run(main())