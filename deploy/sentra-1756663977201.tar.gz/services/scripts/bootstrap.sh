#!/usr/bin/env bash
set -euo pipefail

# Sentra Server Bootstrap Script
# Run this on a fresh Ubuntu 24.04 LTS server (AWS Lightsail)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    error "This script should not be run as root. Please run as a regular user with sudo access."
fi

# Check if .env file exists
if [[ ! -f "$PROJECT_ROOT/.env" ]]; then
    error "Please create .env file from .env.example before running bootstrap"
fi

log "🚀 Starting Sentra server bootstrap..."
log "Project root: $PROJECT_ROOT"

# Update system
log "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install required packages
log "📦 Installing system dependencies..."
sudo apt install -y \
    curl \
    wget \
    git \
    python3 \
    python3-pip \
    python3-venv \
    postgresql-client \
    ufw \
    htop \
    nano \
    unzip

# Install Docker
if ! command -v docker &> /dev/null; then
    log "🐳 Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    rm get-docker.sh
    log "Docker installed - you may need to log out and back in"
else
    log "✅ Docker already installed"
fi

# Install Docker Compose
if ! command -v docker-compose &> /dev/null; then
    log "🐳 Installing Docker Compose..."
    COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep 'tag_name' | cut -d\" -f4)
    sudo curl -L "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
else
    log "✅ Docker Compose already installed"
fi

# Install Caddy
if ! command -v caddy &> /dev/null; then
    log "🌐 Installing Caddy..."
    sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list
    sudo apt update
    sudo apt install -y caddy
else
    log "✅ Caddy already installed"
fi

# Setup firewall
log "🔥 Configuring firewall..."
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp   # HTTP
sudo ufw allow 443/tcp  # HTTPS
sudo ufw --force enable

# Create sentra user if it doesn't exist
if ! id "sentra" &>/dev/null; then
    log "👤 Creating sentra user..."
    sudo useradd -m -s /bin/bash -G docker sentra
else
    log "✅ Sentra user already exists"
fi

# Setup directories
log "📁 Setting up directories..."
sudo mkdir -p /opt/sentra
sudo chown sentra:sentra /opt/sentra

# Copy project files
log "📋 Copying project files..."
sudo cp -r "$PROJECT_ROOT"/* /opt/sentra/
sudo chown -R sentra:sentra /opt/sentra

# Copy environment file
sudo cp "$PROJECT_ROOT/.env" /opt/sentra/
sudo chown sentra:sentra /opt/sentra/.env

# Install systemd services
log "⚙️  Installing systemd services..."
sudo cp "$SCRIPT_DIR/systemd/sentra-api.service" /etc/systemd/system/
sudo cp "$SCRIPT_DIR/systemd/sentra-orchestrator.service" /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Create log directories
sudo mkdir -p /var/log/sentra
sudo chown sentra:sentra /var/log/sentra

# Build and start services
log "🏗️  Building and starting services..."
cd /opt/sentra

# Start Docker services
sudo -u sentra docker-compose pull
sudo -u sentra docker-compose build

# Start services
sudo -u sentra docker-compose up -d

# Enable systemd services
sudo systemctl enable sentra-api
sudo systemctl enable sentra-orchestrator

# Wait for services to be ready
log "⏳ Waiting for services to start..."
sleep 30

# Check service health
log "🏥 Checking service health..."
if curl -f http://localhost:8000/health &>/dev/null; then
    log "✅ API service is healthy"
else
    warn "API service health check failed - check logs with: docker-compose logs api"
fi

# Show status
log "📊 Service status:"
sudo -u sentra docker-compose ps

log "🎉 Sentra server bootstrap complete!"
echo
echo -e "${BLUE}Next steps:${NC}"
echo "1. Update your DNS to point to this server"
echo "2. Check logs: docker-compose logs -f"
echo "3. Access API docs at: http://$(curl -s ipinfo.io/ip)/docs"
echo "4. Monitor services: systemctl status sentra-api sentra-orchestrator"
echo
echo -e "${YELLOW}Important files:${NC}"
echo "- Project: /opt/sentra"
echo "- Logs: /var/log/sentra"
echo "- Services: systemctl {status,start,stop,restart} sentra-{api,orchestrator}"
echo
echo -e "${GREEN}Bootstrap completed successfully! 🚀${NC}"