from pydantic_settings import BaseSettings
from typing import Optional
import os

class Settings(BaseSettings):
    # Database
    database_url: str
    
    # External APIs
    pushover_app_token: str
    pushover_user_key: str
    openai_api_key: str
    
    # Server
    sentra_public_url: str
    sentra_api_token: str
    debug: bool = False
    
    # Optional settings
    temp_audio_dir: str = "/tmp/sentra-audio"
    approval_expiry_hours: int = 1
    max_memory_results: int = 10
    
    # MCP Settings
    mcp_max_connections: int = 100
    
    class Config:
        env_file = ".env"
        case_sensitive = False

# Global settings instance
settings = Settings()

# Ensure temp directory exists
os.makedirs(settings.temp_audio_dir, exist_ok=True)