from fastapi import APIRouter, Depends, HTTPException, status, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
from datetime import datetime, timedelta
import logging

from core.database import get_db
from core.auth import verify_token
from db.models import Approval, Project, Event
from clients.pushover import pushover
from clients.tts_openai import tts
from core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/approvals", tags=["approvals"])

# Pydantic models for request/response
from pydantic import BaseModel

class ApprovalRequest(BaseModel):
    project: str
    machine_id: str
    command: str
    tmux_target: Optional[str] = None
    risk_level: Optional[str] = "medium"

class ApprovalResponse(BaseModel):
    id: str
    status: str
    created_at: datetime

class DecisionRequest(BaseModel):
    decision: str  # approved|rejected
    reason: Optional[str] = None

class PendingApproval(BaseModel):
    id: str
    command: str
    tmux_target: Optional[str]
    status: str
    created_at: datetime
    risk_level: str

@router.post("", response_model=ApprovalResponse)
async def create_approval(
    approval_req: ApprovalRequest,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Create a new approval request and send push notification."""
    try:
        # Find or create project
        project = db.query(Project).filter(Project.name == approval_req.project).first()
        if not project:
            project = Project(name=approval_req.project, description=f"Auto-created for approval: {approval_req.command[:50]}...")
            db.add(project)
            db.flush()
        
        # Create approval record
        approval = Approval(
            project_id=project.id,
            machine_id=approval_req.machine_id,
            tmux_target=approval_req.tmux_target,
            command=approval_req.command,
            risk_level=approval_req.risk_level,
            expires_at=datetime.utcnow() + timedelta(hours=settings.approval_expiry_hours)
        )
        db.add(approval)
        db.flush()
        
        # Create event
        event = Event(
            project_id=project.id,
            approval_id=approval.id,
            event_type="approval_requested",
            event_data={
                "command": approval_req.command,
                "machine_id": approval_req.machine_id,
                "risk_level": approval_req.risk_level
            },
            machine_id=approval_req.machine_id
        )
        db.add(event)
        db.commit()
        
        # Generate voice message
        voice_text = f"Approval needed for {approval_req.project}. Command: {approval_req.command[:100]}"
        voice_file = tts.speak_to_mp3(voice_text)
        
        # Send push notification
        approve_url = f"{settings.sentra_public_url}/approve?id={approval.id}&decision=approve"
        success = pushover.send_push(
            title=f"Sentra Guard - {approval_req.project}",
            message=f"Command: {approval_req.command}\nMachine: {approval_req.machine_id}\nRisk: {approval_req.risk_level}",
            url=approve_url,
            url_title="Approve in Sentra",
            attachment_path=voice_file,
            priority=1 if approval_req.risk_level in ["high", "critical"] else 0
        )
        
        # Clean up temp voice file
        if voice_file:
            tts.cleanup_temp_file(voice_file)
        
        if not success:
            logger.warning(f"Failed to send push notification for approval {approval.id}")
        
        return ApprovalResponse(
            id=str(approval.id),
            status=approval.status,
            created_at=approval.created_at
        )
        
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create approval: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create approval request"
        )

@router.post("/{approval_id}/decision")
async def make_decision(
    approval_id: UUID,
    decision_req: DecisionRequest,
    db: Session = Depends(get_db)
):
    """Make a decision on an approval request."""
    try:
        approval = db.query(Approval).filter(Approval.id == approval_id).first()
        if not approval:
            raise HTTPException(status_code=404, detail="Approval not found")
        
        if approval.status != "pending":
            raise HTTPException(status_code=400, detail=f"Approval already {approval.status}")
        
        if decision_req.decision not in ["approved", "rejected"]:
            raise HTTPException(status_code=400, detail="Decision must be 'approved' or 'rejected'")
        
        # Update approval
        approval.status = decision_req.decision
        approval.decision_reason = decision_req.reason
        approval.decided_at = datetime.utcnow()
        
        # Create event
        event = Event(
            project_id=approval.project_id,
            approval_id=approval.id,
            event_type=f"approval_{decision_req.decision}",
            event_data={
                "decision": decision_req.decision,
                "reason": decision_req.reason,
                "command": approval.command
            }
        )
        db.add(event)
        db.commit()
        
        logger.info(f"Approval {approval_id} {decision_req.decision}")
        
        return {"ok": True, "status": approval.status}
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to make decision on approval {approval_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process decision"
        )

@router.get("/pending")
async def get_pending_approvals(
    machine_id: str,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
) -> dict:
    """Get pending approvals for a specific machine."""
    try:
        approvals = db.query(Approval).filter(
            Approval.machine_id == machine_id,
            Approval.status.in_(["pending", "approved"])
        ).order_by(Approval.created_at.desc()).limit(50).all()
        
        items = []
        for approval in approvals:
            items.append(PendingApproval(
                id=str(approval.id),
                command=approval.command,
                tmux_target=approval.tmux_target,
                status=approval.status,
                created_at=approval.created_at,
                risk_level=approval.risk_level
            ))
        
        return {"items": items}
        
    except Exception as e:
        logger.error(f"Failed to get pending approvals: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve approvals"
        )

# Web UI routes (no auth required for user-friendly approval)
@router.get("/approve", response_class=HTMLResponse, include_in_schema=False)
async def approve_page(id: str, decision: str = "approve", db: Session = Depends(get_db)):
    """Simple web page for approving/rejecting commands."""
    try:
        approval = db.query(Approval).filter(Approval.id == UUID(id)).first()
        if not approval:
            return HTMLResponse("<h1>Approval not found</h1>", status_code=404)
        
        if approval.status != "pending":
            return HTMLResponse(f"<h1>Already {approval.status}</h1>")
        
        return HTMLResponse(f"""
<!DOCTYPE html>
<html>
<head>
    <title>Sentra Approval</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }}
        .command {{ background: #f5f5f5; padding: 15px; border-radius: 8px; margin: 20px 0; font-family: monospace; }}
        .button {{ display: inline-block; padding: 12px 24px; margin: 10px 5px; border: none; border-radius: 6px; text-decoration: none; font-weight: bold; cursor: pointer; }}
        .approve {{ background: #28a745; color: white; }}
        .reject {{ background: #dc3545; color: white; }}
        .info {{ color: #666; margin: 10px 0; }}
    </style>
</head>
<body>
    <h1>🛡️ Sentra Guard</h1>
    <p><strong>Project:</strong> {approval.project.name}</p>
    <p><strong>Machine:</strong> {approval.machine_id}</p>
    <p><strong>Risk Level:</strong> {approval.risk_level.upper()}</p>
    <p><strong>Requested:</strong> {approval.created_at.strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
    
    <div class="command">
        <strong>Command:</strong><br>
        {approval.command}
    </div>
    
    <form method="post" action="/api/approvals/{id}/decision-web">
        <button type="submit" name="decision" value="approved" class="button approve">✅ Approve</button>
        <button type="submit" name="decision" value="rejected" class="button reject">❌ Reject</button>
    </form>
    
    <div class="info">
        <small>This approval will expire at {approval.expires_at.strftime('%Y-%m-%d %H:%M:%S UTC')}</small>
    </div>
</body>
</html>
        """)
        
    except Exception as e:
        logger.error(f"Error displaying approval page: {e}")
        return HTMLResponse("<h1>Error loading approval</h1>", status_code=500)

@router.post("/{approval_id}/decision-web", include_in_schema=False)
async def make_decision_web(
    approval_id: UUID,
    decision: str = Form(...),
    db: Session = Depends(get_db)
):
    """Web form endpoint for making decisions."""
    try:
        decision_req = DecisionRequest(decision=decision)
        await make_decision(approval_id, decision_req, db)
        
        decision_text = "✅ APPROVED" if decision == "approved" else "❌ REJECTED"
        return HTMLResponse(f"""
<!DOCTYPE html>
<html>
<head>
    <title>Decision Recorded - Sentra</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; text-align: center; }}
        .success {{ color: #28a745; font-size: 2em; margin: 40px 0; }}
        .rejected {{ color: #dc3545; font-size: 2em; margin: 40px 0; }}
    </style>
</head>
<body>
    <h1>🛡️ Sentra Guard</h1>
    <div class="{'success' if decision == 'approved' else 'rejected'}">
        {decision_text}
    </div>
    <p>Your decision has been recorded and the command will be {'executed' if decision == 'approved' else 'blocked'}.</p>
    <small>You can close this page.</small>
</body>
</html>
        """)
        
    except Exception as e:
        logger.error(f"Error processing web decision: {e}")
        return HTMLResponse("<h1>Error processing decision</h1>", status_code=500)