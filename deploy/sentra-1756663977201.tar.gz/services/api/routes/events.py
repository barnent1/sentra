from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
from datetime import datetime
import logging

from core.database import get_db
from core.auth import verify_token
from db.models import Event, Project

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/events", tags=["events"])

# Pydantic models
from pydantic import BaseModel

class EventCreate(BaseModel):
    project_id: Optional[str] = None
    agent_id: Optional[str] = None
    task_id: Optional[str] = None
    approval_id: Optional[str] = None
    event_type: str
    event_data: Optional[dict] = {}
    machine_id: Optional[str] = None

class EventResponse(BaseModel):
    id: str
    project_id: Optional[str]
    agent_id: Optional[str]
    task_id: Optional[str]
    approval_id: Optional[str]
    event_type: str
    event_data: dict
    machine_id: Optional[str]
    created_at: datetime

@router.post("", response_model=EventResponse)
async def create_event(
    event_req: EventCreate,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Create a new event for observability."""
    try:
        # Validate project exists if specified
        if event_req.project_id:
            project = db.query(Project).filter(Project.id == UUID(event_req.project_id)).first()
            if not project:
                raise HTTPException(status_code=404, detail="Project not found")
        
        # Create event
        event = Event(
            project_id=UUID(event_req.project_id) if event_req.project_id else None,
            agent_id=UUID(event_req.agent_id) if event_req.agent_id else None,
            task_id=UUID(event_req.task_id) if event_req.task_id else None,
            approval_id=UUID(event_req.approval_id) if event_req.approval_id else None,
            event_type=event_req.event_type,
            event_data=event_req.event_data or {},
            machine_id=event_req.machine_id
        )
        db.add(event)
        db.commit()
        
        logger.debug(f"Created event: {event_req.event_type} for project {event_req.project_id}")
        
        return EventResponse(
            id=str(event.id),
            project_id=str(event.project_id) if event.project_id else None,
            agent_id=str(event.agent_id) if event.agent_id else None,
            task_id=str(event.task_id) if event.task_id else None,
            approval_id=str(event.approval_id) if event.approval_id else None,
            event_type=event.event_type,
            event_data=event.event_data,
            machine_id=event.machine_id,
            created_at=event.created_at
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create event: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create event"
        )

@router.get("", response_model=List[EventResponse])
async def list_events(
    project_id: Optional[str] = None,
    event_type: Optional[str] = None,
    machine_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    task_id: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """List events with optional filtering."""
    try:
        query = db.query(Event)
        
        if project_id:
            query = query.filter(Event.project_id == UUID(project_id))
        
        if event_type:
            query = query.filter(Event.event_type == event_type)
        
        if machine_id:
            query = query.filter(Event.machine_id == machine_id)
        
        if agent_id:
            query = query.filter(Event.agent_id == UUID(agent_id))
        
        if task_id:
            query = query.filter(Event.task_id == UUID(task_id))
        
        events = query.order_by(Event.created_at.desc()).offset(offset).limit(limit).all()
        
        return [
            EventResponse(
                id=str(event.id),
                project_id=str(event.project_id) if event.project_id else None,
                agent_id=str(event.agent_id) if event.agent_id else None,
                task_id=str(event.task_id) if event.task_id else None,
                approval_id=str(event.approval_id) if event.approval_id else None,
                event_type=event.event_type,
                event_data=event.event_data,
                machine_id=event.machine_id,
                created_at=event.created_at
            )
            for event in events
        ]
        
    except Exception as e:
        logger.error(f"Failed to list events: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve events"
        )

@router.get("/types")
async def get_event_types(
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Get all unique event types for filtering."""
    try:
        result = db.execute("SELECT DISTINCT event_type FROM events ORDER BY event_type")
        event_types = [row[0] for row in result.fetchall()]
        
        return {"event_types": event_types}
        
    except Exception as e:
        logger.error(f"Failed to get event types: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve event types"
        )