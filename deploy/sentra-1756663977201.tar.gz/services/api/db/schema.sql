-- Sentra Database Schema
-- Enable extensions first
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;

-- Projects table
CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT UNIQUE NOT NULL,
    repo_url TEXT,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Agent personas table
CREATE TABLE agents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    role TEXT NOT NULL,            -- analyst, pm, dev, qa, uiux, orchestrator
    prompt TEXT NOT NULL,          -- canonical persona prompt
    config JSONB DEFAULT '{}',     -- additional configuration
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Tasks table
CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id),
    title TEXT NOT NULL,
    spec TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'queued',  -- queued|running|waiting_approval|blocked|done|failed
    assigned_agent UUID REFERENCES agents(id),
    parent_task_id UUID REFERENCES tasks(id),  -- for task hierarchies
    priority INTEGER DEFAULT 1,    -- 1=high, 5=low
    metadata JSONB DEFAULT '{}',    -- flexible task data
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Approvals table
CREATE TABLE approvals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id),
    machine_id TEXT NOT NULL,
    tmux_target TEXT,              -- e.g. "dev:ProjectA.1"
    command TEXT NOT NULL,
    risk_level TEXT DEFAULT 'medium',  -- low|medium|high|critical
    status TEXT NOT NULL DEFAULT 'pending',  -- pending|approved|rejected|expired|completed
    decision_reason TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    decided_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ DEFAULT (now() + interval '1 hour')
);

-- Events table (for observability)
CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id),
    agent_id UUID REFERENCES agents(id),
    task_id UUID REFERENCES tasks(id),
    approval_id UUID REFERENCES approvals(id),
    event_type TEXT NOT NULL,      -- task_started, approval_requested, command_executed, etc.
    event_data JSONB DEFAULT '{}',
    machine_id TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Vectorized memory items
CREATE TABLE memory_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id),
    task_id UUID REFERENCES tasks(id),
    kind TEXT NOT NULL,            -- doc, code, note, decision, log, artifact
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    embedding vector(1536),        -- text-embedding-3-small
    metadata JSONB DEFAULT '{}',   -- file_path, language, tags, etc.
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Sub-agents table (for tracking spawned Claude instances)
CREATE TABLE subagents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID REFERENCES agents(id),
    task_id UUID REFERENCES tasks(id),
    machine_id TEXT NOT NULL,
    tmux_target TEXT NOT NULL,     -- where the subagent is running
    status TEXT DEFAULT 'active',  -- active|idle|terminated
    context_summary TEXT,          -- brief context for the subagent
    created_at TIMESTAMPTZ DEFAULT now(),
    last_seen TIMESTAMPTZ DEFAULT now()
);

-- Indexes for performance
CREATE INDEX idx_tasks_project_status ON tasks(project_id, status);
CREATE INDEX idx_tasks_assigned_agent ON tasks(assigned_agent);
CREATE INDEX idx_approvals_machine_status ON approvals(machine_id, status);
CREATE INDEX idx_approvals_expires ON approvals(expires_at);
CREATE INDEX idx_events_project_type ON events(project_id, event_type);
CREATE INDEX idx_events_created_at ON events(created_at);
CREATE INDEX idx_memory_project_kind ON memory_items(project_id, kind);
CREATE INDEX idx_subagents_machine_status ON subagents(machine_id, status);

-- Vector search index for memory items
CREATE INDEX idx_memory_embedding ON memory_items USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);

-- Update triggers for timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON agents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_memory_items_updated_at BEFORE UPDATE ON memory_items
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically expire old approvals
CREATE OR REPLACE FUNCTION expire_old_approvals()
RETURNS void AS $$
BEGIN
    UPDATE approvals 
    SET status = 'expired'
    WHERE status = 'pending' 
    AND expires_at < now();
END;
$$ LANGUAGE plpgsql;

-- Function to search memory items by similarity
CREATE OR REPLACE FUNCTION search_memory(
    p_project_id UUID,
    p_query_embedding vector(1536),
    p_kind TEXT DEFAULT NULL,
    p_limit INTEGER DEFAULT 10
)
RETURNS TABLE (
    id UUID,
    title TEXT,
    content TEXT,
    kind TEXT,
    similarity FLOAT,
    metadata JSONB,
    created_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id,
        m.title,
        m.content,
        m.kind,
        (1 - (m.embedding <=> p_query_embedding)) as similarity,
        m.metadata,
        m.created_at
    FROM memory_items m
    WHERE m.project_id = p_project_id
    AND (p_kind IS NULL OR m.kind = p_kind)
    ORDER BY m.embedding <=> p_query_embedding
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;