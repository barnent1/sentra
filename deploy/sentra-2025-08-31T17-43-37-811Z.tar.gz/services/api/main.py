from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import logging
import uvicorn
import asyncio

from .core.config import settings
from .core.database import init_db, test_connection
from .routes import approvals, tasks, events, memory
from .mcp.server import mcp_server

# Configure logging
logging.basicConfig(
    level=logging.INFO if not settings.debug else logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Sentra API",
    description="Observability and orchestration system for Claude Code development workflows",
    version="1.0.0",
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.debug else [settings.sentra_public_url],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(approvals.router)
app.include_router(tasks.router)
app.include_router(events.router)
app.include_router(memory.router)

@app.websocket("/mcp")
async def mcp_websocket_endpoint(websocket: WebSocket):
    """MCP (Model Context Protocol) WebSocket endpoint."""
    client_id = None
    try:
        client_id = await mcp_server.connect(websocket)
        
        while True:
            message = await websocket.receive_text()
            await mcp_server.handle_message(websocket, message, client_id)
            
    except WebSocketDisconnect:
        logger.info(f"MCP WebSocket disconnected: {client_id}")
    except Exception as e:
        logger.error(f"MCP WebSocket error: {e}")
    finally:
        if client_id:
            await mcp_server.disconnect(client_id)

@app.on_event("startup")
async def startup_event():
    """Initialize the application."""
    logger.info("Starting Sentra API...")
    
    # Test database connection
    if not test_connection():
        logger.error("Failed to connect to database - exiting")
        raise RuntimeError("Database connection failed")
    
    # Initialize database
    await init_db()
    
    logger.info(f"Sentra API started successfully (debug={'on' if settings.debug else 'off'})")

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    try:
        # Test database connection
        db_healthy = test_connection()
        
        return {
            "status": "healthy" if db_healthy else "degraded",
            "database": "connected" if db_healthy else "disconnected",
            "version": "1.0.0"
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail="Service unhealthy")

@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "Sentra API",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs" if settings.debug else "disabled in production"
    }

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Global exception handler."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        log_level="debug" if settings.debug else "info",
        reload=settings.debug
    )