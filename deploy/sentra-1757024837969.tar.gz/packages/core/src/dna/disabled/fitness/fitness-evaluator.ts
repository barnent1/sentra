/**
 * Fitness Evaluator - Multi-criteria fitness scoring for DNA patterns
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 * 
 * Implements comprehensive fitness evaluation across 6+ dimensions:
 * - Context match (how well DNA fits project context)
 * - Performance metrics (speed, efficiency, quality)
 * - Adaptability (flexibility and learning capacity)
 * - Stability (consistency and reliability)
 * - Novelty (innovation and uniqueness)
 * - Generation penalty (to prevent stagnation)
 */

import {
  CodeDNA,
  ProjectContext,
  FitnessScore,
  PerformanceFeedback,
  PerformanceMetrics,
  GeneticMarkers,
  PatternType
} from '../../types';
import type { Brand } from '@sentra/types';

/**
 * Individual fitness dimension scores
 */
export interface FitnessDimensions {
  readonly contextMatch: number;      // 0-1: How well DNA matches project context
  readonly performance: number;       // 0-1: Overall performance metrics score
  readonly adaptability: number;      // 0-1: Flexibility and learning capacity
  readonly stability: number;         // 0-1: Consistency and reliability
  readonly novelty: number;          // 0-1: Innovation and uniqueness
  readonly generationPenalty: number; // 0-1: Penalty for excessive generations
  readonly collaborationFit: number;  // 0-1: Team collaboration effectiveness
  readonly resourceEfficiency: number; // 0-1: Computational resource usage
}

/**
 * Weights for different fitness dimensions
 */
export interface FitnessWeights {
  readonly contextMatch: number;
  readonly performance: number;
  readonly adaptability: number;
  readonly stability: number;
  readonly novelty: number;
  readonly generationPenalty: number;
  readonly collaborationFit: number;
  readonly resourceEfficiency: number;
}

/**
 * Fitness evaluation configuration
 */
export interface FitnessConfig {
  readonly weights: FitnessWeights;
  readonly noveltyThreshold: number;
  readonly maxGenerationsBeforePenalty: number;
  readonly stabilityWindowSize: number;
  readonly performanceThresholds: PerformanceThresholds;
}

/**
 * Performance thresholds for different metrics
 */
export interface PerformanceThresholds {
  readonly minSuccessRate: number;
  readonly maxResponseTime: number;
  readonly minCodeQuality: number;
  readonly maxBugRate: number;
  readonly minTestCoverage: number;
  readonly minUserSatisfaction: number;
}

/**
 * Default fitness configuration
 */
const DEFAULT_FITNESS_CONFIG: FitnessConfig = {
  weights: {
    contextMatch: 0.25,
    performance: 0.25,
    adaptability: 0.15,
    stability: 0.15,
    novelty: 0.1,
    generationPenalty: 0.05,
    collaborationFit: 0.03,
    resourceEfficiency: 0.02,
  },
  noveltyThreshold: 0.7,
  maxGenerationsBeforePenalty: 10,
  stabilityWindowSize: 5,
  performanceThresholds: {
    minSuccessRate: 0.8,
    maxResponseTime: 2000,
    minCodeQuality: 0.7,
    maxBugRate: 0.1,
    minTestCoverage: 0.8,
    minUserSatisfaction: 0.7,
  },
} as const;

/**
 * Comprehensive fitness evaluator for DNA patterns
 */
export class FitnessEvaluator {
  private readonly config: FitnessConfig;
  private readonly contextPatterns: Map<string, number[]> = new Map();
  
  constructor(config: Partial<FitnessConfig> = {}) {
    this.config = {
      weights: { ...DEFAULT_FITNESS_CONFIG.weights, ...config.weights },
      noveltyThreshold: config.noveltyThreshold ?? DEFAULT_FITNESS_CONFIG.noveltyThreshold,
      maxGenerationsBeforePenalty: config.maxGenerationsBeforePenalty ?? DEFAULT_FITNESS_CONFIG.maxGenerationsBeforePenalty,
      stabilityWindowSize: config.stabilityWindowSize ?? DEFAULT_FITNESS_CONFIG.stabilityWindowSize,
      performanceThresholds: { ...DEFAULT_FITNESS_CONFIG.performanceThresholds, ...config.performanceThresholds },
    };
  }

  /**
   * Evaluate comprehensive fitness of DNA pattern
   */
  async evaluateFitness(
    dna: CodeDNA,
    context: ProjectContext,
    feedback?: PerformanceFeedback
  ): Promise<FitnessScore> {
    const dimensions = await this.calculateFitnessDimensions(dna, context, feedback);
    
    // Calculate weighted fitness score
    const weightedScore = 
      dimensions.contextMatch * this.config.weights.contextMatch +
      dimensions.performance * this.config.weights.performance +
      dimensions.adaptability * this.config.weights.adaptability +
      dimensions.stability * this.config.weights.stability +
      dimensions.novelty * this.config.weights.novelty +
      (1 - dimensions.generationPenalty) * this.config.weights.generationPenalty +
      dimensions.collaborationFit * this.config.weights.collaborationFit +
      dimensions.resourceEfficiency * this.config.weights.resourceEfficiency;
    
    // Ensure score is within bounds
    const finalScore = Math.max(0, Math.min(1, weightedScore));
    
    return finalScore as FitnessScore;
  }

  /**
   * Calculate individual fitness dimensions
   */
  private async calculateFitnessDimensions(
    dna: CodeDNA,
    context: ProjectContext,
    feedback?: PerformanceFeedback
  ): Promise<FitnessDimensions> {
    return {
      contextMatch: this.evaluateContextMatch(dna, context),
      performance: this.evaluatePerformance(dna.performance, feedback),
      adaptability: this.evaluateAdaptability(dna.genetics, dna.evolutionHistory),
      stability: this.evaluateStability(dna.evolutionHistory),
      novelty: this.evaluateNovelty(dna),
      generationPenalty: this.calculateGenerationPenalty(dna.generation),
      collaborationFit: this.evaluateCollaborationFit(dna.genetics, context),
      resourceEfficiency: this.evaluateResourceEfficiency(dna.performance),
    };
  }

  /**
   * Evaluate how well DNA matches project context
   */
  private evaluateContextMatch(dna: CodeDNA, context: ProjectContext): number {
    let score = 0.5; // Base score
    
    // Pattern type alignment
    const patternTypeScore = this.getPatternTypeAlignment(dna.patternType, context);
    score += patternTypeScore * 0.3;
    
    // Tech stack compatibility
    const techStackScore = this.evaluateTechStackCompatibility(dna, context);
    score += techStackScore * 0.2;
    
    // Complexity alignment
    const complexityScore = this.evaluateComplexityAlignment(dna.genetics.complexity, context.complexity);
    score += complexityScore * 0.2;
    
    // Domain expertise
    const domainScore = this.evaluateDomainExpertise(dna, context);
    score += domainScore * 0.15;
    
    // Team size compatibility
    const teamScore = this.evaluateTeamSizeCompatibility(dna.genetics.collaborationAffinity, context.teamSize);
    score += teamScore * 0.1;
    
    // Regulatory compliance fit
    const complianceScore = this.evaluateComplianceFit(dna, context);
    score += complianceScore * 0.05;
    
    return Math.max(0, Math.min(1, score));
  }

  /**
   * Get pattern type alignment score
   */
  private getPatternTypeAlignment(patternType: string, context: ProjectContext): number {
    const alignmentMap: Record<string, Record<string, number>> = {
      [PatternType.ANALYTICAL]: {
        'ai-ml': 0.9,
        'api': 0.7,
        'library': 0.8,
        'infrastructure': 0.6,
        'web-app': 0.5,
        'cli': 0.6,
        'blockchain': 0.7,
        'embedded': 0.6,
      },
      [PatternType.CREATIVE]: {
        'web-app': 0.8,
        'ai-ml': 0.7,
        'cli': 0.4,
        'library': 0.5,
        'api': 0.4,
        'infrastructure': 0.3,
        'blockchain': 0.6,
        'embedded': 0.4,
      },
      [PatternType.SYSTEMATIC]: {
        'infrastructure': 0.9,
        'api': 0.8,
        'library': 0.9,
        'cli': 0.7,
        'blockchain': 0.8,
        'embedded': 0.8,
        'web-app': 0.6,
        'ai-ml': 0.6,
      },
      [PatternType.ADAPTIVE]: {
        'web-app': 0.9,
        'ai-ml': 0.8,
        'api': 0.7,
        'cli': 0.6,
        'library': 0.6,
        'infrastructure': 0.5,
        'blockchain': 0.6,
        'embedded': 0.7,
      },
      [PatternType.COLLABORATIVE]: {
        'web-app': 0.8,
        'api': 0.7,
        'infrastructure': 0.6,
        'ai-ml': 0.6,
        'library': 0.5,
        'cli': 0.4,
        'blockchain': 0.5,
        'embedded': 0.4,
      },
    };
    
    return alignmentMap[patternType]?.[context.projectType] ?? 0.5;
  }

  /**
   * Evaluate tech stack compatibility
   */
  private evaluateTechStackCompatibility(dna: CodeDNA, context: ProjectContext): number {
    // This would be expanded with actual tech stack analysis
    // For now, return a score based on adaptability
    return dna.genetics.adaptability * 0.8 + dna.genetics.learningVelocity * 0.2;
  }

  /**
   * Evaluate complexity alignment
   */
  private evaluateComplexityAlignment(dnaComplexity: number, contextComplexity: string): number {
    const complexityMap: Record<string, number> = {
      'low': 0.3,
      'medium': 0.5,
      'high': 0.7,
      'enterprise': 0.9,
      'research': 1.0,
    };
    
    const targetComplexity = complexityMap[contextComplexity] ?? 0.5;
    const difference = Math.abs(dnaComplexity - targetComplexity);
    
    // Return higher score for closer alignment
    return Math.max(0, 1 - difference);
  }

  /**
   * Evaluate domain expertise
   */
  private evaluateDomainExpertise(dna: CodeDNA, context: ProjectContext): number {
    // Check if DNA has experience in this domain
    const hasRelevantExperience = dna.tags.includes(context.industryDomain) ||
                                 dna.viabilityAssessment.recommendedContexts.includes(context.industryDomain);
    
    const baseScore = hasRelevantExperience ? 0.8 : 0.4;
    const transferabilityBonus = dna.genetics.transferability * 0.2;
    
    return Math.min(1, baseScore + transferabilityBonus);
  }

  /**
   * Evaluate team size compatibility
   */
  private evaluateTeamSizeCompatibility(collaborationAffinity: number, teamSize: number): number {
    // Optimal collaboration affinity varies with team size
    let optimalAffinity: number;
    
    if (teamSize <= 3) {
      optimalAffinity = 0.6; // Small teams need moderate collaboration
    } else if (teamSize <= 10) {
      optimalAffinity = 0.8; // Medium teams need high collaboration
    } else {
      optimalAffinity = 0.9; // Large teams need very high collaboration
    }
    
    const difference = Math.abs(collaborationAffinity - optimalAffinity);
    return Math.max(0, 1 - difference);
  }

  /**
   * Evaluate regulatory compliance fit
   */
  private evaluateComplianceFit(dna: CodeDNA, context: ProjectContext): number {
    if (context.regulatoryCompliance.length === 0) {
      return 1.0; // No compliance requirements
    }
    
    // Higher thoroughness and stability are better for compliance
    return (dna.genetics.thoroughness * 0.6 + dna.genetics.stability * 0.4);
  }

  /**
   * Evaluate performance metrics
   */
  private evaluatePerformance(metrics: PerformanceMetrics, feedback?: PerformanceFeedback): number {
    const thresholds = this.config.performanceThresholds;
    let score = 0;
    let totalWeight = 0;
    
    // Success rate (weight: 0.25)
    const successWeight = 0.25;
    const successScore = Math.min(1, metrics.successRate / thresholds.minSuccessRate);
    score += successScore * successWeight;
    totalWeight += successWeight;
    
    // Response time (weight: 0.2)
    const responseWeight = 0.2;
    const responseScore = Math.max(0, 1 - (metrics.responseLatency / thresholds.maxResponseTime));
    score += responseScore * responseWeight;
    totalWeight += responseWeight;
    
    // Code quality (weight: 0.2)
    const qualityWeight = 0.2;
    const qualityScore = Math.min(1, metrics.codeQualityScore / thresholds.minCodeQuality);
    score += qualityScore * qualityWeight;
    totalWeight += qualityWeight;
    
    // Bug rate (weight: 0.15, inverted)
    const bugWeight = 0.15;
    const bugScore = Math.max(0, 1 - (metrics.bugIntroductionRate / thresholds.maxBugRate));
    score += bugScore * bugWeight;
    totalWeight += bugWeight;
    
    // Test coverage (weight: 0.1)
    const coverageWeight = 0.1;
    const coverageScore = Math.min(1, metrics.testCoverage / thresholds.minTestCoverage);
    score += coverageScore * coverageWeight;
    totalWeight += coverageWeight;
    
    // User satisfaction (weight: 0.1)
    const satisfactionWeight = 0.1;
    const satisfactionScore = Math.min(1, metrics.userSatisfactionRating / thresholds.minUserSatisfaction);
    score += satisfactionScore * satisfactionWeight;
    totalWeight += satisfactionWeight;
    
    // Apply feedback if available
    if (feedback) {
      const feedbackBonus = this.calculateFeedbackBonus(feedback);
      score += feedbackBonus * 0.1;
      totalWeight += 0.1;
    }
    
    return totalWeight > 0 ? score / totalWeight : 0;
  }

  /**
   * Calculate feedback bonus
   */
  private calculateFeedbackBonus(feedback: PerformanceFeedback): number {
    let bonus = 0;
    
    // Positive outcome
    if (feedback.outcome === 'success') {
      bonus += 0.3;
    } else if (feedback.outcome === 'partial') {
      bonus += 0.1;
    }
    
    // User satisfaction
    if (feedback.userSatisfaction !== undefined) {
      bonus += feedback.userSatisfaction * 0.2;
    }
    
    // Improvements vs regressions
    const improvementRatio = feedback.improvements.length / 
                           Math.max(1, feedback.improvements.length + feedback.regressions.length);
    bonus += improvementRatio * 0.2;
    
    return Math.min(0.5, bonus); // Cap bonus at 0.5
  }

  /**
   * Evaluate adaptability based on genetics and history
   */
  private evaluateAdaptability(genetics: GeneticMarkers, evolutionHistory: readonly any[]): number {
    // Base adaptability from genetics
    let score = genetics.adaptability * 0.4;
    
    // Learning velocity contribution
    score += genetics.learningVelocity * 0.3;
    
    // Transferability contribution
    score += genetics.transferability * 0.2;
    
    // Evolution history shows actual adaptation
    if (evolutionHistory.length > 0) {
      const recentEvolutions = evolutionHistory.slice(-5);
      const improvementCount = recentEvolutions.filter(
        step => step.outcome === 'improvement'
      ).length;
      const adaptationBonus = (improvementCount / recentEvolutions.length) * 0.1;
      score += adaptationBonus;
    }
    
    return Math.max(0, Math.min(1, score));
  }

  /**
   * Evaluate stability based on evolution history
   */
  private evaluateStability(evolutionHistory: readonly any[]): number {
    if (evolutionHistory.length < this.config.stabilityWindowSize) {
      return 0.5; // Default stability for new DNA
    }
    
    const recentHistory = evolutionHistory.slice(-this.config.stabilityWindowSize);
    
    // Count stable outcomes (no degradation)
    const stableCount = recentHistory.filter(
      step => step.outcome !== 'degradation'
    ).length;
    
    const stabilityRatio = stableCount / recentHistory.length;
    
    // Performance variance analysis
    const performanceValues = recentHistory.map(step => 
      this.calculatePerformanceScore(step.performanceAfter)
    );
    
    const variance = this.calculateVariance(performanceValues);
    const varianceScore = Math.max(0, 1 - variance); // Lower variance = higher stability
    
    // Combine stability ratio and variance score
    return (stabilityRatio * 0.7) + (varianceScore * 0.3);
  }

  /**
   * Calculate performance score from metrics
   */
  private calculatePerformanceScore(metrics: any): number {
    // Simplified performance scoring
    return (metrics.successRate + metrics.codeQualityScore + metrics.userSatisfactionRating) / 3;
  }

  /**
   * Calculate variance of an array of numbers
   */
  private calculateVariance(values: number[]): number {
    if (values.length === 0) return 0;
    
    const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
    const squaredDifferences = values.map(val => Math.pow(val - mean, 2));
    const variance = squaredDifferences.reduce((sum, val) => sum + val, 0) / values.length;
    
    return Math.sqrt(variance); // Return standard deviation
  }

  /**
   * Evaluate novelty of DNA pattern
   */
  private evaluateNovelty(dna: CodeDNA): number {
    // Base novelty from genetics
    let noveltyScore = dna.genetics.novelty;
    
    // Age-based novelty (newer patterns are more novel)
    const daysSinceCreation = (Date.now() - dna.timestamp.getTime()) / (1000 * 60 * 60 * 24);
    const ageScore = Math.max(0, 1 - (daysSinceCreation / 30)); // Decrease over 30 days
    noveltyScore += ageScore * 0.2;
    
    // Generation-based novelty (earlier generations more novel)
    const generationScore = Math.max(0, 1 - (dna.generation / 20)); // Decrease over 20 generations
    noveltyScore += generationScore * 0.1;
    
    // Activation frequency (less used patterns are more novel)
    const activationScore = Math.max(0, 1 - (dna.activationCount / 100)); // Decrease over 100 uses
    noveltyScore += activationScore * 0.1;
    
    return Math.max(0, Math.min(1, noveltyScore));
  }

  /**
   * Calculate generation penalty
   */
  private calculateGenerationPenalty(generation: number): number {
    if (generation <= this.config.maxGenerationsBeforePenalty) {
      return 0; // No penalty
    }
    
    const excessGenerations = generation - this.config.maxGenerationsBeforePenalty;
    const penalty = Math.min(0.5, excessGenerations * 0.02); // 2% penalty per excess generation, max 50%
    
    return penalty;
  }

  /**
   * Evaluate collaboration fit
   */
  private evaluateCollaborationFit(genetics: GeneticMarkers, context: ProjectContext): number {
    let score = genetics.collaborationAffinity * 0.4;
    
    // Communication clarity is important for collaboration
    score += genetics.communicationClarity * 0.3;
    
    // Empathy helps with team dynamics
    score += genetics.empathy * 0.2;
    
    // Error recovery is important for team work
    score += genetics.errorRecovery * 0.1;
    
    // Adjust for team size
    if (context.teamSize > 5) {
      score *= 1.1; // Bonus for large team fit
    } else if (context.teamSize <= 2) {
      score *= 0.9; // Small penalty for small team over-optimization
    }
    
    return Math.max(0, Math.min(1, score));
  }

  /**
   * Evaluate resource efficiency
   */
  private evaluateResourceEfficiency(performance: PerformanceMetrics): number {
    let score = 0;
    
    // Computational efficiency (weight: 0.4)
    score += performance.computationalEfficiency * 0.4;
    
    // Resource utilization (weight: 0.3)
    score += performance.resourceUtilization * 0.3;
    
    // Throughput efficiency (weight: 0.2)
    const throughputScore = Math.min(1, performance.throughput / 50); // Normalize to 50 tasks/hour
    score += throughputScore * 0.2;
    
    // Response latency efficiency (weight: 0.1, inverted)
    const latencyScore = Math.max(0, 1 - (performance.responseLatency / 5000)); // Normalize to 5s max
    score += latencyScore * 0.1;
    
    return Math.max(0, Math.min(1, score));
  }

  /**
   * Get detailed fitness breakdown for debugging
   */
  async getFitnessBreakdown(
    dna: CodeDNA,
    context: ProjectContext,
    feedback?: PerformanceFeedback
  ): Promise<{
    finalScore: FitnessScore;
    dimensions: FitnessDimensions;
    weights: FitnessWeights;
    recommendations: string[];
  }> {
    const dimensions = await this.calculateFitnessDimensions(dna, context, feedback);
    const finalScore = await this.evaluateFitness(dna, context, feedback);
    
    const recommendations = this.generateRecommendations(dimensions, context);
    
    return {
      finalScore,
      dimensions,
      weights: this.config.weights,
      recommendations,
    };
  }

  /**
   * Generate improvement recommendations based on fitness dimensions
   */
  private generateRecommendations(dimensions: FitnessDimensions, context: ProjectContext): string[] {
    const recommendations: string[] = [];
    const threshold = 0.6;
    
    if (dimensions.contextMatch < threshold) {
      recommendations.push(`Improve context alignment for ${context.projectType} projects`);
    }
    
    if (dimensions.performance < threshold) {
      recommendations.push('Focus on performance optimization and quality metrics');
    }
    
    if (dimensions.adaptability < threshold) {
      recommendations.push('Enhance learning velocity and adaptability traits');
    }
    
    if (dimensions.stability < threshold) {
      recommendations.push('Improve consistency and reduce performance variance');
    }
    
    if (dimensions.novelty < threshold) {
      recommendations.push('Explore more creative and innovative approaches');
    }
    
    if (dimensions.collaborationFit < threshold) {
      recommendations.push('Develop better communication and teamwork capabilities');
    }
    
    if (dimensions.resourceEfficiency < threshold) {
      recommendations.push('Optimize computational resource usage and efficiency');
    }
    
    return recommendations;
  }
}

export default FitnessEvaluator;