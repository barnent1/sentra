/**
 * Mutation Validator - Comprehensive validation and safety checks for DNA mutations
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 * 
 * This validator provides:
 * - Safety validation for mutations
 * - Rollback mechanisms
 * - Risk assessment
 * - Constraint checking
 */

import {
  Mutation,
  CodeDNA,
  GeneticMarkers,
  ProjectContext,
  MutationType
} from '../../types';

/**
 * Validation result with detailed feedback
 */
export interface ValidationResult {
  readonly success: boolean;
  readonly confidence: number;
  readonly risks: readonly string[];
  readonly warnings: readonly string[];
  readonly recommendations: readonly string[];
  readonly safetyScore: number;          // 0-1, higher is safer
  readonly rollbackPlan?: RollbackPlan;
  readonly constraintViolations: readonly string[];
}

/**
 * Rollback plan for reverting problematic mutations
 */
export interface RollbackPlan {
  readonly canRollback: boolean;
  readonly originalValue: number;
  readonly rollbackSteps: readonly string[];
  readonly rollbackRisk: number;        // 0-1, risk of rollback operation
}

/**
 * Validation constraints for mutations
 */
export interface ValidationConstraints {
  readonly maxChangePerMutation: number;      // Maximum allowed change in single mutation
  readonly minGeneValue: number;              // Minimum allowed gene value
  readonly maxGeneValue: number;              // Maximum allowed gene value
  readonly maxMutationsPerCycle: number;      // Maximum mutations in single evolution cycle
  readonly forbiddenGenes: readonly (keyof GeneticMarkers)[];  // Genes that cannot be mutated
  readonly preserveRatios: readonly {         // Genes that must maintain ratios
    gene1: keyof GeneticMarkers;
    gene2: keyof GeneticMarkers;
    maxRatioDifference: number;
  }[];
  readonly stabilityRequirements: {           // Stability-related constraints
    minStability: number;
    criticalGenes: readonly (keyof GeneticMarkers)[];
  };
}

/**
 * Context-specific validation rules
 */
export interface ContextualValidationRules {
  readonly projectType: string;
  readonly complexityLevel: string;
  readonly teamSize: number;
  readonly criticalityLevel: 'low' | 'medium' | 'high' | 'critical';
  readonly customRules: readonly string[];
}

/**
 * Default validation constraints
 */
const DEFAULT_CONSTRAINTS: ValidationConstraints = {
  maxChangePerMutation: 0.3,
  minGeneValue: 0.05,
  maxGeneValue: 0.95,
  maxMutationsPerCycle: 5,
  forbiddenGenes: [], // No forbidden genes by default
  preserveRatios: [
    // Stability and adaptability should be somewhat balanced
    { gene1: 'stability', gene2: 'adaptability', maxRatioDifference: 0.5 },
    // Complexity and pragmatism should be inversely related
    { gene1: 'complexity', gene2: 'pragmatism', maxRatioDifference: 0.4 },
  ],
  stabilityRequirements: {
    minStability: 0.2,
    criticalGenes: ['stability', 'errorRecovery', 'successRate'],
  },
} as const;

/**
 * Comprehensive mutation validator
 */
export class MutationValidator {
  private readonly constraints: ValidationConstraints;
  private readonly mutationHistory: Map<string, Mutation[]> = new Map();
  
  constructor(customConstraints: Partial<ValidationConstraints> = {}) {
    this.constraints = { ...DEFAULT_CONSTRAINTS, ...customConstraints };
  }

  /**
   * Validate a single mutation
   */
  async validateMutation(
    mutation: Mutation,
    dna?: CodeDNA,
    context?: ProjectContext
  ): Promise<ValidationResult> {
    const risks: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];
    const constraintViolations: string[] = [];
    
    let confidence = 0.8; // Base confidence
    let safetyScore = 0.8; // Base safety score
    
    // Basic constraint validation
    const basicValidation = this.validateBasicConstraints(mutation);
    if (!basicValidation.isValid) {
      constraintViolations.push(...basicValidation.violations);
      confidence *= 0.5;
      safetyScore *= 0.6;
    }
    
    // Gene-specific validation
    const geneValidation = this.validateGeneSpecificRules(mutation, dna);
    risks.push(...geneValidation.risks);
    warnings.push(...geneValidation.warnings);
    confidence *= geneValidation.confidenceMultiplier;
    safetyScore *= geneValidation.safetyMultiplier;
    
    // Context-specific validation if context provided
    if (context && dna) {
      const contextValidation = this.validateContextualRules(mutation, dna, context);
      risks.push(...contextValidation.risks);
      warnings.push(...contextValidation.warnings);
      recommendations.push(...contextValidation.recommendations);
      confidence *= contextValidation.confidenceMultiplier;
      safetyScore *= contextValidation.safetyMultiplier;
    }
    
    // History-based validation
    if (dna) {
      const historyValidation = this.validateMutationHistory(mutation, dna);
      risks.push(...historyValidation.risks);
      warnings.push(...historyValidation.warnings);
      confidence *= historyValidation.confidenceMultiplier;
    }
    
    // Interaction validation (check for gene interactions)
    if (dna) {
      const interactionValidation = this.validateGeneInteractions(mutation, dna);
      risks.push(...interactionValidation.risks);
      warnings.push(...interactionValidation.warnings);
      confidence *= interactionValidation.confidenceMultiplier;
      safetyScore *= interactionValidation.safetyMultiplier;
    }
    
    // Generate rollback plan
    const rollbackPlan = dna ? this.generateRollbackPlan(mutation, dna) : undefined;
    
    // Generate recommendations based on validation results
    if (risks.length > 0) {
      recommendations.push('Consider reducing mutation intensity');
    }
    if (warnings.length > 2) {
      recommendations.push('Review mutation strategy for this gene');
    }
    if (safetyScore < 0.5) {
      recommendations.push('Implement gradual mutation approach');
    }
    
    const success = constraintViolations.length === 0 && 
                   risks.length < 3 && 
                   confidence > 0.3 && 
                   safetyScore > 0.3;
    
    return {
      success,
      confidence: Math.max(0.1, Math.min(1.0, confidence)),
      risks: [...new Set(risks)], // Remove duplicates
      warnings: [...new Set(warnings)],
      recommendations: [...new Set(recommendations)],
      safetyScore: Math.max(0.1, Math.min(1.0, safetyScore)),
      rollbackPlan,
      constraintViolations,
    };
  }

  /**
   * Validate basic constraints
   */
  private validateBasicConstraints(mutation: Mutation): {
    isValid: boolean;
    violations: string[];
  } {
    const violations: string[] = [];
    
    // Check change magnitude
    if (Math.abs(mutation.delta) > this.constraints.maxChangePerMutation) {
      violations.push(`Mutation change (${Math.abs(mutation.delta).toFixed(3)}) exceeds maximum allowed (${this.constraints.maxChangePerMutation})`);
    }
    
    // Check gene value bounds
    if (mutation.newValue < this.constraints.minGeneValue) {
      violations.push(`New gene value (${mutation.newValue.toFixed(3)}) below minimum (${this.constraints.minGeneValue})`);
    }
    
    if (mutation.newValue > this.constraints.maxGeneValue) {
      violations.push(`New gene value (${mutation.newValue.toFixed(3)}) above maximum (${this.constraints.maxGeneValue})`);
    }
    
    // Check forbidden genes
    if (this.constraints.forbiddenGenes.includes(mutation.targetGene)) {
      violations.push(`Gene ${mutation.targetGene} is forbidden from mutation`);
    }
    
    return {
      isValid: violations.length === 0,
      violations,
    };
  }

  /**
   * Validate gene-specific rules
   */
  private validateGeneSpecificRules(
    mutation: Mutation,
    dna?: CodeDNA
  ): {
    risks: string[];
    warnings: string[];
    confidenceMultiplier: number;
    safetyMultiplier: number;
  } {
    const risks: string[] = [];
    const warnings: string[] = [];
    let confidenceMultiplier = 1.0;
    let safetyMultiplier = 1.0;
    
    const gene = mutation.targetGene;
    const delta = mutation.delta;
    
    switch (gene) {
      case 'stability':
        if (delta < -0.1) {
          risks.push('Reducing stability may cause performance issues');
          confidenceMultiplier *= 0.8;
          safetyMultiplier *= 0.7;
        }
        if (mutation.newValue < this.constraints.stabilityRequirements.minStability) {
          risks.push(`Stability below minimum requirement (${this.constraints.stabilityRequirements.minStability})`);
          confidenceMultiplier *= 0.6;
          safetyMultiplier *= 0.5;
        }
        break;
        
      case 'successRate':
        if (delta < 0) {
          risks.push('Reducing success rate is inherently risky');
          confidenceMultiplier *= 0.7;
        }
        if (mutation.newValue < 0.3) {
          risks.push('Very low success rate may indicate systematic issues');
          safetyMultiplier *= 0.6;
        }
        break;
        
      case 'errorRecovery':
        if (delta < -0.15) {
          risks.push('Large reduction in error recovery capability');
          confidenceMultiplier *= 0.8;
          safetyMultiplier *= 0.8;
        }
        break;
        
      case 'complexity':
        if (mutation.newValue > 0.9) {
          warnings.push('Very high complexity may hurt maintainability');
          confidenceMultiplier *= 0.9;
        }
        if (mutation.newValue < 0.1) {
          warnings.push('Very low complexity may result in naive solutions');
          confidenceMultiplier *= 0.9;
        }
        break;
        
      case 'riskTolerance':
        if (mutation.newValue > 0.85) {
          risks.push('Extremely high risk tolerance may lead to unstable behavior');
          confidenceMultiplier *= 0.7;
          safetyMultiplier *= 0.8;
        }
        break;
        
      case 'thoroughness':
        if (delta < -0.2 && dna?.performance?.codeQualityScore && dna.performance.codeQualityScore < 0.7) {
          risks.push('Reducing thoroughness when quality is already low');
          confidenceMultiplier *= 0.7;
        }
        break;
        
      case 'communicationClarity':
        if (delta < 0 && dna?.performance?.teamIntegration && dna.performance.teamIntegration < 0.6) {
          warnings.push('Reducing communication clarity when team integration is poor');
          confidenceMultiplier *= 0.85;
        }
        break;
        
      case 'adaptability':
        if (delta > 0.3) {
          warnings.push('Large increase in adaptability may reduce stability');
          confidenceMultiplier *= 0.9;
        }
        break;
        
      case 'novelty':
        if (mutation.newValue > 0.9) {
          warnings.push('Extremely high novelty may conflict with practical requirements');
          confidenceMultiplier *= 0.85;
        }
        break;
    }
    
    return {
      risks,
      warnings,
      confidenceMultiplier,
      safetyMultiplier,
    };
  }

  /**
   * Validate contextual rules based on project context
   */
  private validateContextualRules(
    mutation: Mutation,
    dna: CodeDNA,
    context: ProjectContext
  ): {
    risks: string[];
    warnings: string[];
    recommendations: string[];
    confidenceMultiplier: number;
    safetyMultiplier: number;
  } {
    const risks: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];
    let confidenceMultiplier = 1.0;
    let safetyMultiplier = 1.0;
    
    // Project type specific validations
    switch (context.projectType) {
      case 'infrastructure':
        if (mutation.targetGene === 'stability' && mutation.delta < 0) {
          risks.push('Reducing stability in infrastructure projects is high risk');
          confidenceMultiplier *= 0.6;
          safetyMultiplier *= 0.5;
        }
        if (mutation.targetGene === 'novelty' && mutation.newValue > 0.7) {
          warnings.push('High novelty may not be suitable for infrastructure');
          confidenceMultiplier *= 0.8;
        }
        break;
        
      case 'ai-ml':
        if (mutation.targetGene === 'learningVelocity' && mutation.delta < -0.1) {
          warnings.push('Reducing learning velocity in AI/ML projects may hurt performance');
          confidenceMultiplier *= 0.85;
        }
        if (mutation.targetGene === 'novelty' && mutation.delta < -0.15) {
          warnings.push('Reducing novelty may limit AI innovation potential');
          confidenceMultiplier *= 0.9;
        }
        break;
        
      case 'web-app':
        if (mutation.targetGene === 'empathy' && mutation.delta < 0) {
          warnings.push('Reducing empathy may hurt user experience in web applications');
          confidenceMultiplier *= 0.9;
        }
        break;
    }
    
    // Complexity level validations
    switch (context.complexity) {
      case 'enterprise':
      case 'research':
        if (mutation.targetGene === 'thoroughness' && mutation.delta < -0.1) {
          risks.push('Reducing thoroughness in complex projects is risky');
          confidenceMultiplier *= 0.8;
          safetyMultiplier *= 0.8;
        }
        break;
        
      case 'low':
        if (mutation.targetGene === 'complexity' && mutation.newValue > 0.6) {
          warnings.push('High complexity may be over-engineering for simple projects');
          recommendations.push('Consider simplification approach');
          confidenceMultiplier *= 0.9;
        }
        break;
    }
    
    // Team size validations
    if (context.teamSize > 10) {
      if (mutation.targetGene === 'collaborationAffinity' && mutation.delta < 0) {
        risks.push('Reducing collaboration in large teams is problematic');
        confidenceMultiplier *= 0.7;
      }
    } else if (context.teamSize <= 2) {
      if (mutation.targetGene === 'collaborationAffinity' && mutation.newValue > 0.8) {
        warnings.push('Very high collaboration may be unnecessary for small teams');
        confidenceMultiplier *= 0.95;
      }
    }
    
    // Performance requirements validations
    if (context.performanceRequirements.maxResponseTime < 1000) {
      if (mutation.targetGene === 'thoroughness' && mutation.delta > 0.1) {
        warnings.push('Increasing thoroughness may conflict with strict performance requirements');
        recommendations.push('Balance thoroughness with performance needs');
        confidenceMultiplier *= 0.85;
      }
    }
    
    // Security requirements validations
    if (context.securityRequirements.dataPrivacyLevel === 'restricted') {
      if (mutation.targetGene === 'riskTolerance' && mutation.delta > 0.1) {
        risks.push('Increasing risk tolerance conflicts with strict security requirements');
        confidenceMultiplier *= 0.7;
        safetyMultiplier *= 0.8;
      }
    }
    
    return {
      risks,
      warnings,
      recommendations,
      confidenceMultiplier,
      safetyMultiplier,
    };
  }

  /**
   * Validate based on mutation history
   */
  private validateMutationHistory(
    mutation: Mutation,
    dna: CodeDNA
  ): {
    risks: string[];
    warnings: string[];
    confidenceMultiplier: number;
  } {
    const risks: string[] = [];
    const warnings: string[] = [];
    let confidenceMultiplier = 1.0;
    
    const recentMutations = dna.mutations.slice(-5); // Last 5 mutations
    const sameGeneMutations = recentMutations.filter(m => m.targetGene === mutation.targetGene);
    
    // Check for excessive mutations on same gene
    if (sameGeneMutations.length >= 3) {
      risks.push(`Gene ${mutation.targetGene} has been mutated ${sameGeneMutations.length} times recently`);
      confidenceMultiplier *= 0.8;
    }
    
    // Check for oscillating mutations (back and forth)
    if (sameGeneMutations.length >= 2) {
      const lastMutation = sameGeneMutations[sameGeneMutations.length - 1];
      if ((lastMutation.delta > 0 && mutation.delta < 0) || (lastMutation.delta < 0 && mutation.delta > 0)) {
        warnings.push('Mutation may be oscillating on this gene');
        confidenceMultiplier *= 0.9;
      }
    }
    
    // Check evolution history for degradation patterns
    const recentEvolutionHistory = dna.evolutionHistory.slice(-3);
    const degradationCount = recentEvolutionHistory.filter(step => step.outcome === 'degradation').length;
    
    if (degradationCount >= 2) {
      risks.push('Recent evolution history shows degradation pattern');
      confidenceMultiplier *= 0.7;
    }
    
    return {
      risks,
      warnings,
      confidenceMultiplier,
    };
  }

  /**
   * Validate gene interactions and dependencies
   */
  private validateGeneInteractions(
    mutation: Mutation,
    dna: CodeDNA
  ): {
    risks: string[];
    warnings: string[];
    confidenceMultiplier: number;
    safetyMultiplier: number;
  } {
    const risks: string[] = [];
    const warnings: string[] = [];
    let confidenceMultiplier = 1.0;
    let safetyMultiplier = 1.0;
    
    // Check preserve ratio constraints
    for (const ratioConstraint of this.constraints.preserveRatios) {
      if (mutation.targetGene === ratioConstraint.gene1) {
        const gene2Value = dna.genetics[ratioConstraint.gene2];
        const ratio = Math.abs(mutation.newValue - gene2Value);
        
        if (ratio > ratioConstraint.maxRatioDifference) {
          warnings.push(`Mutation may violate ratio constraint between ${ratioConstraint.gene1} and ${ratioConstraint.gene2}`);
          confidenceMultiplier *= 0.85;
        }
      }
    }
    
    // Specific gene interaction validations
    const gene = mutation.targetGene;
    const newValue = mutation.newValue;
    
    // Complexity-Pragmatism interaction
    if (gene === 'complexity') {
      const pragmatismValue = dna.genetics.pragmatism;
      if (newValue > 0.8 && pragmatismValue < 0.3) {
        risks.push('High complexity with low pragmatism may cause implementation issues');
        confidenceMultiplier *= 0.8;
        safetyMultiplier *= 0.8;
      }
    }
    
    // Stability-Adaptability balance
    if (gene === 'stability') {
      const adaptabilityValue = dna.genetics.adaptability;
      if (newValue < 0.3 && adaptabilityValue > 0.8) {
        warnings.push('Low stability with high adaptability may cause inconsistent behavior');
        confidenceMultiplier *= 0.85;
      }
    }
    
    // Risk-Stability interaction
    if (gene === 'riskTolerance') {
      const stabilityValue = dna.genetics.stability;
      if (newValue > 0.8 && stabilityValue < 0.4) {
        risks.push('High risk tolerance with low stability is dangerous combination');
        confidenceMultiplier *= 0.7;
        safetyMultiplier *= 0.7;
      }
    }
    
    // Thoroughness-Speed interaction (via resourceEfficiency)
    if (gene === 'thoroughness') {
      const resourceEfficiency = dna.genetics.resourceEfficiency;
      if (newValue > 0.9 && resourceEfficiency > 0.8) {
        warnings.push('Very high thoroughness may conflict with resource efficiency goals');
        confidenceMultiplier *= 0.9;
      }
    }
    
    return {
      risks,
      warnings,
      confidenceMultiplier,
      safetyMultiplier,
    };
  }

  /**
   * Generate rollback plan for mutation
   */
  private generateRollbackPlan(mutation: Mutation, dna: CodeDNA): RollbackPlan {
    const rollbackSteps: string[] = [];
    
    // Basic rollback: revert to previous value
    rollbackSteps.push(`Revert ${mutation.targetGene} from ${mutation.newValue.toFixed(3)} to ${mutation.previousValue.toFixed(3)}`);
    
    // Additional steps based on mutation type and impact
    if (Math.abs(mutation.delta) > 0.2) {
      rollbackSteps.push('Monitor performance metrics for 24 hours after rollback');
      rollbackSteps.push('Validate gene interactions after rollback');
    }
    
    if (mutation.targetGene === 'stability' || mutation.targetGene === 'errorRecovery') {
      rollbackSteps.push('Run stability tests after rollback');
      rollbackSteps.push('Check error handling capabilities');
    }
    
    // Calculate rollback risk based on various factors
    let rollbackRisk = 0.1; // Base risk
    
    if (dna.activationCount > 100) {
      rollbackRisk += 0.1; // More usage makes rollback riskier
    }
    
    if (dna.generation > 10) {
      rollbackRisk += 0.05; // Older DNA is riskier to rollback
    }
    
    if (Math.abs(mutation.delta) > 0.25) {
      rollbackRisk += 0.15; // Large changes are riskier to rollback
    }
    
    return {
      canRollback: true,
      originalValue: mutation.previousValue,
      rollbackSteps,
      rollbackRisk: Math.min(0.8, rollbackRisk),
    };
  }

  /**
   * Validate a batch of mutations together
   */
  async validateMutationBatch(
    mutations: readonly Mutation[],
    dna: CodeDNA,
    context?: ProjectContext
  ): Promise<{
    overallResult: ValidationResult;
    individualResults: readonly ValidationResult[];
    batchRisks: readonly string[];
    batchRecommendations: readonly string[];
  }> {
    // Validate each mutation individually
    const individualResults = await Promise.all(
      mutations.map(mutation => this.validateMutation(mutation, dna, context))
    );
    
    // Analyze batch-specific risks
    const batchRisks: string[] = [];
    const batchRecommendations: string[] = [];
    
    // Check for too many mutations
    if (mutations.length > this.constraints.maxMutationsPerCycle) {
      batchRisks.push(`Batch contains ${mutations.length} mutations, exceeding limit of ${this.constraints.maxMutationsPerCycle}`);
    }
    
    // Check for conflicting mutations
    const genesMutated = new Set(mutations.map(m => m.targetGene));
    if (genesMutated.has('stability') && genesMutated.has('adaptability')) {
      const stabilityMutation = mutations.find(m => m.targetGene === 'stability');
      const adaptabilityMutation = mutations.find(m => m.targetGene === 'adaptability');
      
      if (stabilityMutation && adaptabilityMutation) {
        if ((stabilityMutation.delta < 0 && adaptabilityMutation.delta > 0.2) ||
            (stabilityMutation.delta > 0.2 && adaptabilityMutation.delta < 0)) {
          batchRisks.push('Conflicting mutations on stability and adaptability');
        }
      }
    }
    
    // Check cumulative change impact
    const totalAbsoluteChange = mutations.reduce((sum, mutation) => sum + Math.abs(mutation.delta), 0);
    if (totalAbsoluteChange > 1.0) {
      batchRisks.push('Cumulative mutation change is very large');
      batchRecommendations.push('Consider reducing mutation intensity or splitting into multiple cycles');
    }
    
    // Generate overall result
    const avgConfidence = individualResults.reduce((sum, result) => sum + result.confidence, 0) / individualResults.length;
    const avgSafetyScore = individualResults.reduce((sum, result) => sum + result.safetyScore, 0) / individualResults.length;
    const allRisks = [
      ...batchRisks,
      ...individualResults.flatMap(result => result.risks)
    ];
    const allWarnings = individualResults.flatMap(result => result.warnings);
    const allRecommendations = [
      ...batchRecommendations,
      ...individualResults.flatMap(result => result.recommendations)
    ];
    const allConstraintViolations = individualResults.flatMap(result => result.constraintViolations);
    
    const overallSuccess = individualResults.every(result => result.success) && 
                          batchRisks.length === 0 && 
                          avgConfidence > 0.4;
    
    const overallResult: ValidationResult = {
      success: overallSuccess,
      confidence: avgConfidence * (batchRisks.length > 0 ? 0.8 : 1.0),
      risks: [...new Set(allRisks)],
      warnings: [...new Set(allWarnings)],
      recommendations: [...new Set(allRecommendations)],
      safetyScore: avgSafetyScore * (batchRisks.length > 0 ? 0.8 : 1.0),
      constraintViolations: [...new Set(allConstraintViolations)],
    };
    
    return {
      overallResult,
      individualResults,
      batchRisks,
      batchRecommendations,
    };
  }

  /**
   * Update validation constraints
   */
  updateConstraints(newConstraints: Partial<ValidationConstraints>): void {
    Object.assign(this.constraints, newConstraints);
  }

  /**
   * Get current validation constraints
   */
  getConstraints(): ValidationConstraints {
    return { ...this.constraints };
  }

  /**
   * Clear mutation history (for testing or reset)
   */
  clearHistory(): void {
    this.mutationHistory.clear();
  }
}

export default MutationValidator;