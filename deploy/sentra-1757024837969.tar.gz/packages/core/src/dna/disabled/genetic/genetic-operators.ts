/**
 * Genetic Operators - Implementation of crossover, mutation, and selection operations
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 * 
 * This module implements:
 * - Tournament selection
 * - Uniform and arithmetic crossover
 * - Population-level genetic operations
 * - Diversity preservation mechanisms
 */

import {
  CodeDNA,
  EvolutionResult,
  GeneticMarkers,
  ProjectContext,
  MutationType,
  PatternType,
  FitnessScore,
  EvolutionDnaId,
  Mutation,
  MutationId
} from '../../types';
import type { Brand } from '@sentra/types';

/**
 * Crossover method types
 */
export type CrossoverMethod = 'uniform' | 'arithmetic' | 'blend' | 'simulated_binary';

/**
 * Selection method types
 */
export type SelectionMethod = 'tournament' | 'roulette' | 'rank' | 'stochastic_universal';

/**
 * Crossover configuration
 */
export interface CrossoverConfig {
  readonly method: CrossoverMethod;
  readonly crossoverRate: number;
  readonly blendAlpha?: number;          // For blend crossover
  readonly tournamentSize?: number;      // For tournament-based parent selection
  readonly preserveElite?: boolean;      // Whether to preserve best traits
}

/**
 * Selection configuration
 */
export interface SelectionConfig {
  readonly method: SelectionMethod;
  readonly selectionPressure: number;   // Higher values favor better individuals
  readonly tournamentSize?: number;     // For tournament selection
  readonly eliteRatio?: number;         // Proportion of elite individuals to preserve
}

/**
 * Population evaluation result
 */
export interface PopulationEvaluation {
  readonly individual: CodeDNA;
  readonly fitness: FitnessScore;
  readonly rank: number;
  readonly selectionProbability: number;
}

/**
 * Genetic operators for evolutionary algorithms
 */
export class GeneticOperators {
  /**
   * Perform crossover between two parent DNA patterns
   */
  async crossover(
    parent1: CodeDNA,
    parent2: CodeDNA,
    context: ProjectContext,
    config: CrossoverConfig = {
      method: 'uniform',
      crossoverRate: 0.7,
      preserveElite: true
    }
  ): Promise<EvolutionResult> {
    try {
      const offspring = await this.performCrossover(parent1, parent2, context, config);
      
      if (!offspring) {
        return {
          success: false,
          parentDna: [parent1, parent2],
          evolutionType: MutationType.CROSSOVER,
          improvementScore: 0,
          confidence: 0,
          reasoning: 'Crossover operation failed to produce viable offspring',
          metadata: { config, crossoverMethod: config.method }
        };
      }
      
      // Calculate improvement score
      const avgParentFitness = (parent1.fitnessScore + parent2.fitnessScore) / 2;
      const improvementScore = (offspring.fitnessScore - avgParentFitness) / avgParentFitness;
      
      return {
        success: true,
        newDna: offspring,
        parentDna: [parent1, parent2],
        evolutionType: MutationType.CROSSOVER,
        improvementScore,
        confidence: this.calculateCrossoverConfidence(parent1, parent2, offspring),
        reasoning: `Crossover using ${config.method} method combined beneficial traits from both parents`,
        metadata: {
          config,
          crossoverMethod: config.method,
          geneticSimilarity: this.calculateGeneticSimilarity(parent1, parent2),
          inheritanceRatio: this.calculateInheritanceRatio(parent1, parent2, offspring)
        }
      };
      
    } catch (error) {
      return {
        success: false,
        parentDna: [parent1, parent2],
        evolutionType: MutationType.CROSSOVER,
        improvementScore: -1,
        confidence: 0,
        reasoning: `Crossover failed with error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        metadata: { config, error: error instanceof Error ? error.message : 'Unknown error' }
      };
    }
  }

  /**
   * Perform the actual crossover operation
   */
  private async performCrossover(
    parent1: CodeDNA,
    parent2: CodeDNA,
    context: ProjectContext,
    config: CrossoverConfig
  ): Promise<CodeDNA | null> {
    // Check if crossover should occur
    if (Math.random() > config.crossoverRate) {
      return null; // No crossover, return null
    }
    
    let childGenetics: GeneticMarkers;
    
    switch (config.method) {
      case 'uniform':
        childGenetics = this.uniformCrossover(parent1.genetics, parent2.genetics);
        break;
      case 'arithmetic':
        childGenetics = this.arithmeticCrossover(parent1.genetics, parent2.genetics);
        break;
      case 'blend':
        childGenetics = this.blendCrossover(parent1.genetics, parent2.genetics, config.blendAlpha ?? 0.3);
        break;
      case 'simulated_binary':
        childGenetics = this.simulatedBinaryCrossover(parent1.genetics, parent2.genetics);
        break;
      default:
        childGenetics = this.uniformCrossover(parent1.genetics, parent2.genetics);
    }
    
    // Determine child's pattern type (inherit from fitter parent)
    const fitterParent = parent1.fitnessScore > parent2.fitnessScore ? parent1 : parent2;
    
    // Create child DNA
    const childDNA: CodeDNA = {
      id: this.generateOffspringId(parent1.id, parent2.id),
      patternType: fitterParent.patternType,
      context,
      genetics: childGenetics,
      performance: this.interpolatePerformanceMetrics(parent1.performance, parent2.performance),
      mutations: [],
      embedding: this.blendEmbeddings(parent1.embedding, parent2.embedding),
      timestamp: new Date(),
      generation: Math.max(parent1.generation, parent2.generation) + 1,
      parentId: fitterParent.id,
      birthContext: {
        trigger: 'crossover',
        sourceAgentId: undefined,
        sourceTaskId: undefined,
        creationReason: `Crossover between ${parent1.patternType} and ${parent2.patternType} patterns`,
        initialPerformance: this.interpolatePerformanceMetrics(parent1.performance, parent2.performance),
      },
      evolutionHistory: [],
      activationCount: 0,
      lastActivation: new Date(),
      fitnessScore: this.estimateOffspringFitness(parent1.fitnessScore, parent2.fitnessScore),
      viabilityAssessment: {
        overallScore: (parent1.viabilityAssessment.overallScore + parent2.viabilityAssessment.overallScore) / 2,
        strengths: [...parent1.viabilityAssessment.strengths, ...parent2.viabilityAssessment.strengths],
        weaknesses: this.mergeWeaknesses(parent1.viabilityAssessment.weaknesses, parent2.viabilityAssessment.weaknesses),
        recommendedContexts: [...new Set([...parent1.viabilityAssessment.recommendedContexts, ...parent2.viabilityAssessment.recommendedContexts])],
        avoidContexts: [...new Set([...parent1.viabilityAssessment.avoidContexts, ...parent2.viabilityAssessment.avoidContexts])],
        lastAssessment: new Date(),
        confidenceLevel: Math.min(parent1.viabilityAssessment.confidenceLevel, parent2.viabilityAssessment.confidenceLevel),
      },
      reproductionPotential: (parent1.reproductionPotential + parent2.reproductionPotential) / 2,
      tags: [...new Set([...parent1.tags, ...parent2.tags])],
      notes: `Crossover offspring of ${parent1.id} and ${parent2.id}`,
      isArchived: false,
    };
    
    return childDNA;
  }

  /**
   * Uniform crossover - randomly select genes from either parent
   */
  private uniformCrossover(genetics1: GeneticMarkers, genetics2: GeneticMarkers): GeneticMarkers {
    const result: Partial<GeneticMarkers> = {};
    
    for (const [gene, value1] of Object.entries(genetics1) as [keyof GeneticMarkers, number][]) {
      const value2 = genetics2[gene];
      
      // Randomly choose from either parent, with slight bias toward better values
      const useParent1 = value1 > value2 ? Math.random() < 0.6 : Math.random() < 0.4;
      result[gene] = useParent1 ? value1 : value2;
    }
    
    return result as GeneticMarkers;
  }

  /**
   * Arithmetic crossover - blend genes using weighted averages
   */
  private arithmeticCrossover(genetics1: GeneticMarkers, genetics2: GeneticMarkers): GeneticMarkers {
    const result: Partial<GeneticMarkers> = {};
    const alpha = Math.random(); // Random blending coefficient
    
    for (const [gene, value1] of Object.entries(genetics1) as [keyof GeneticMarkers, number][]) {
      const value2 = genetics2[gene];
      result[gene] = alpha * value1 + (1 - alpha) * value2;
    }
    
    return result as GeneticMarkers;
  }

  /**
   * Blend crossover - extends arithmetic crossover with random variation
   */
  private blendCrossover(genetics1: GeneticMarkers, genetics2: GeneticMarkers, alpha: number): GeneticMarkers {
    const result: Partial<GeneticMarkers> = {};
    
    for (const [gene, value1] of Object.entries(genetics1) as [keyof GeneticMarkers, number][]) {
      const value2 = genetics2[gene];
      const min = Math.min(value1, value2);
      const max = Math.max(value1, value2);
      const range = max - min;
      
      // Extend range by alpha on both sides
      const extendedMin = Math.max(0, min - alpha * range);
      const extendedMax = Math.min(1, max + alpha * range);
      
      result[gene] = extendedMin + Math.random() * (extendedMax - extendedMin);
    }
    
    return result as GeneticMarkers;
  }

  /**
   * Simulated binary crossover - simulates crossover of binary-encoded values
   */
  private simulatedBinaryCrossover(genetics1: GeneticMarkers, genetics2: GeneticMarkers): GeneticMarkers {
    const result: Partial<GeneticMarkers> = {};
    const eta = 2; // Distribution index (higher values produce offspring closer to parents)
    
    for (const [gene, value1] of Object.entries(genetics1) as [keyof GeneticMarkers, number][]) {
      const value2 = genetics2[gene];
      
      const u = Math.random();
      const beta = u <= 0.5 
        ? Math.pow(2 * u, 1 / (eta + 1))
        : Math.pow(1 / (2 * (1 - u)), 1 / (eta + 1));
      
      const child1 = 0.5 * ((1 + beta) * value1 + (1 - beta) * value2);
      const child2 = 0.5 * ((1 - beta) * value1 + (1 + beta) * value2);
      
      // Randomly select one of the children
      result[gene] = Math.max(0, Math.min(1, Math.random() < 0.5 ? child1 : child2));
    }
    
    return result as GeneticMarkers;
  }

  /**
   * Tournament selection - select individual through tournament competition
   */
  tournamentSelection(
    population: readonly PopulationEvaluation[],
    tournamentSize: number = 3
  ): PopulationEvaluation {
    const tournament = [];
    
    // Randomly select individuals for tournament
    for (let i = 0; i < tournamentSize; i++) {
      const randomIndex = Math.floor(Math.random() * population.length);
      tournament.push(population[randomIndex]);
    }
    
    // Return the fittest individual from tournament
    return tournament.reduce((best, individual) => 
      individual.fitness > best.fitness ? individual : best
    );
  }

  /**
   * Roulette wheel selection - probability-based selection
   */
  rouletteWheelSelection(population: readonly PopulationEvaluation[]): PopulationEvaluation {
    const totalFitness = population.reduce((sum, individual) => sum + individual.fitness, 0);
    const selectionPoint = Math.random() * totalFitness;
    
    let cumulativeFitness = 0;
    for (const individual of population) {
      cumulativeFitness += individual.fitness;
      if (cumulativeFitness >= selectionPoint) {
        return individual;
      }
    }
    
    // Fallback to last individual
    return population[population.length - 1];
  }

  /**
   * Rank-based selection - selection based on rank rather than raw fitness
   */
  rankBasedSelection(population: readonly PopulationEvaluation[]): PopulationEvaluation {
    // Population should already be sorted by fitness (rank)
    const totalRanks = (population.length * (population.length + 1)) / 2;
    const selectionPoint = Math.random() * totalRanks;
    
    let cumulativeRank = 0;
    for (let i = 0; i < population.length; i++) {
      const rank = population.length - i; // Higher rank for better fitness
      cumulativeRank += rank;
      
      if (cumulativeRank >= selectionPoint) {
        return population[i];
      }
    }
    
    return population[0]; // Return best individual as fallback
  }

  /**
   * Stochastic universal sampling - ensures more uniform selection
   */
  stochasticUniversalSampling(
    population: readonly PopulationEvaluation[],
    numSelections: number
  ): PopulationEvaluation[] {
    const totalFitness = population.reduce((sum, individual) => sum + individual.fitness, 0);
    const selectionDistance = totalFitness / numSelections;
    const startingPoint = Math.random() * selectionDistance;
    
    const selected: PopulationEvaluation[] = [];
    let cumulativeFitness = 0;
    let currentSelection = startingPoint;
    let populationIndex = 0;
    
    for (let selectionIndex = 0; selectionIndex < numSelections; selectionIndex++) {
      while (cumulativeFitness < currentSelection && populationIndex < population.length) {
        cumulativeFitness += population[populationIndex].fitness;
        if (cumulativeFitness >= currentSelection) {
          selected.push(population[populationIndex]);
          break;
        }
        populationIndex++;
      }
      currentSelection += selectionDistance;
    }
    
    return selected;
  }

  /**
   * Blend genetic markers from multiple parents
   */
  blendGenetics(parentGenetics: readonly GeneticMarkers[]): GeneticMarkers {
    if (parentGenetics.length === 0) {
      throw new Error('Cannot blend genetics from empty array');
    }
    
    if (parentGenetics.length === 1) {
      return { ...parentGenetics[0] };
    }
    
    const result: Partial<GeneticMarkers> = {};
    const geneKeys = Object.keys(parentGenetics[0]) as (keyof GeneticMarkers)[];
    
    for (const gene of geneKeys) {
      // Calculate weighted average, with slight preference for higher values
      const values = parentGenetics.map(genetics => genetics[gene]);
      const sortedValues = [...values].sort((a, b) => b - a);
      
      // Weighted average with bias toward better values
      let weightedSum = 0;
      let totalWeight = 0;
      
      for (let i = 0; i < sortedValues.length; i++) {
        const weight = sortedValues.length - i; // Higher weight for better values
        weightedSum += sortedValues[i] * weight;
        totalWeight += weight;
      }
      
      const blendedValue = weightedSum / totalWeight;
      
      // Add small random variation
      const variation = (Math.random() - 0.5) * 0.1;
      result[gene] = Math.max(0, Math.min(1, blendedValue + variation));
    }
    
    return result as GeneticMarkers;
  }

  /**
   * Calculate genetic similarity between two DNA patterns
   */
  calculateGeneticSimilarity(dna1: CodeDNA, dna2: CodeDNA): number {
    const genes = Object.keys(dna1.genetics) as (keyof GeneticMarkers)[];
    
    let totalSimilarity = 0;
    for (const gene of genes) {
      const value1 = dna1.genetics[gene];
      const value2 = dna2.genetics[gene];
      const similarity = 1 - Math.abs(value1 - value2);
      totalSimilarity += similarity;
    }
    
    return totalSimilarity / genes.length;
  }

  /**
   * Calculate inheritance ratios for offspring
   */
  private calculateInheritanceRatio(
    parent1: CodeDNA,
    parent2: CodeDNA,
    offspring: CodeDNA
  ): { parent1: number; parent2: number } {
    const genes = Object.keys(offspring.genetics) as (keyof GeneticMarkers)[];
    
    let parent1Influence = 0;
    let parent2Influence = 0;
    
    for (const gene of genes) {
      const childValue = offspring.genetics[gene];
      const parent1Value = parent1.genetics[gene];
      const parent2Value = parent2.genetics[gene];
      
      // Calculate which parent the child's gene is closer to
      const distanceToParent1 = Math.abs(childValue - parent1Value);
      const distanceToParent2 = Math.abs(childValue - parent2Value);
      
      if (distanceToParent1 < distanceToParent2) {
        parent1Influence++;
      } else if (distanceToParent2 < distanceToParent1) {
        parent2Influence++;
      }
      // Equal distance contributes to neither parent
    }
    
    const totalInfluence = parent1Influence + parent2Influence;
    if (totalInfluence === 0) {
      return { parent1: 0.5, parent2: 0.5 };
    }
    
    return {
      parent1: parent1Influence / totalInfluence,
      parent2: parent2Influence / totalInfluence,
    };
  }

  /**
   * Calculate crossover confidence
   */
  private calculateCrossoverConfidence(
    parent1: CodeDNA,
    parent2: CodeDNA,
    offspring: CodeDNA
  ): number {
    let confidence = 0.5; // Base confidence
    
    // Higher confidence if parents have good fitness
    const avgParentFitness = (parent1.fitnessScore + parent2.fitnessScore) / 2;
    confidence += avgParentFitness * 0.3;
    
    // Higher confidence if parents are not too similar (diversity is good)
    const similarity = this.calculateGeneticSimilarity(parent1, parent2);
    if (similarity < 0.8) { // Not too similar
      confidence += 0.1;
    }
    
    // Higher confidence if offspring inherits good traits
    if (offspring.fitnessScore > avgParentFitness) {
      confidence += 0.2;
    }
    
    // Consider generation - not too many generations
    if (offspring.generation < 15) {
      confidence += 0.1;
    }
    
    return Math.max(0.2, Math.min(0.9, confidence));
  }

  /**
   * Generate unique ID for offspring
   */
  private generateOffspringId(parent1Id: EvolutionDnaId, parent2Id: EvolutionDnaId): EvolutionDnaId {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 9);
    return `offspring_${timestamp}_${random}` as EvolutionDnaId;
  }

  /**
   * Interpolate performance metrics between parents
   */
  private interpolatePerformanceMetrics(perf1: any, perf2: any): any {
    const result: any = {};
    
    for (const [metric, value1] of Object.entries(perf1)) {
      const value2 = perf2[metric];
      
      if (typeof value1 === 'number' && typeof value2 === 'number') {
        // For performance metrics, use conservative estimate (slightly pessimistic)
        result[metric] = (value1 + value2) / 2 * 0.95;
      } else {
        result[metric] = value1; // Use parent1's value for non-numeric metrics
      }
    }
    
    return result;
  }

  /**
   * Blend embeddings from two parents
   */
  private blendEmbeddings(embedding1: readonly number[], embedding2: readonly number[]): readonly number[] {
    if (embedding1.length !== embedding2.length) {
      // Return the longer embedding if lengths differ
      return embedding1.length > embedding2.length ? embedding1 : embedding2;
    }
    
    const blended: number[] = [];
    for (let i = 0; i < embedding1.length; i++) {
      // Simple average with slight random variation
      const avg = (embedding1[i] + embedding2[i]) / 2;
      const variation = (Math.random() - 0.5) * 0.1;
      blended[i] = avg + variation;
    }
    
    return blended;
  }

  /**
   * Estimate offspring fitness based on parents
   */
  private estimateOffspringFitness(fitness1: FitnessScore, fitness2: FitnessScore): FitnessScore {
    // Conservative estimate: average of parents with slight variation
    const avgFitness = (fitness1 + fitness2) / 2;
    const variation = (Math.random() - 0.5) * 0.1; // ±5% variation
    
    return Math.max(0, Math.min(1, avgFitness + variation)) as FitnessScore;
  }

  /**
   * Merge weaknesses from two parents, removing duplicates
   */
  private mergeWeaknesses(
    weaknesses1: readonly string[],
    weaknesses2: readonly string[]
  ): readonly string[] {
    const merged = [...weaknesses1, ...weaknesses2];
    return [...new Set(merged)]; // Remove duplicates
  }

  /**
   * Maintain population diversity by selecting diverse individuals
   */
  maintainDiversity(
    population: readonly CodeDNA[],
    diversityThreshold: number = 0.3
  ): readonly CodeDNA[] {
    if (population.length <= 2) return population;
    
    const diverse: CodeDNA[] = [population[0]]; // Always keep the best
    
    for (let i = 1; i < population.length; i++) {
      const candidate = population[i];
      
      // Check if candidate is sufficiently different from existing diverse individuals
      let isDiverse = true;
      for (const existing of diverse) {
        const similarity = this.calculateGeneticSimilarity(candidate, existing);
        if (similarity > (1 - diversityThreshold)) {
          isDiverse = false;
          break;
        }
      }
      
      if (isDiverse) {
        diverse.push(candidate);
      }
    }
    
    return diverse;
  }

  /**
   * Calculate population statistics
   */
  calculatePopulationStats(population: readonly PopulationEvaluation[]): {
    averageFitness: number;
    maxFitness: number;
    minFitness: number;
    diversityScore: number;
    convergenceRate: number;
  } {
    if (population.length === 0) {
      return {
        averageFitness: 0,
        maxFitness: 0,
        minFitness: 0,
        diversityScore: 0,
        convergenceRate: 0,
      };
    }
    
    const fitnessValues = population.map(individual => individual.fitness);
    
    const averageFitness = fitnessValues.reduce((sum, fitness) => sum + fitness, 0) / population.length;
    const maxFitness = Math.max(...fitnessValues);
    const minFitness = Math.min(...fitnessValues);
    
    // Calculate diversity as average pairwise genetic distance
    let totalDistance = 0;
    let pairCount = 0;
    
    for (let i = 0; i < population.length; i++) {
      for (let j = i + 1; j < population.length; j++) {
        const similarity = this.calculateGeneticSimilarity(population[i].individual, population[j].individual);
        totalDistance += (1 - similarity); // Distance is complement of similarity
        pairCount++;
      }
    }
    
    const diversityScore = pairCount > 0 ? totalDistance / pairCount : 0;
    
    // Calculate convergence rate (higher when population is converging)
    const fitnessVariance = this.calculateVariance(fitnessValues);
    const convergenceRate = Math.max(0, 1 - fitnessVariance); // Lower variance = higher convergence
    
    return {
      averageFitness,
      maxFitness,
      minFitness,
      diversityScore,
      convergenceRate,
    };
  }

  /**
   * Calculate variance of fitness values
   */
  private calculateVariance(values: number[]): number {
    if (values.length === 0) return 0;
    
    const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
    const squaredDifferences = values.map(value => Math.pow(value - mean, 2));
    
    return squaredDifferences.reduce((sum, diff) => sum + diff, 0) / values.length;
  }
}

export default GeneticOperators;