/**
 * Evolution Metrics - Comprehensive metrics collection for DNA evolution operations
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 * 
 * This module provides:
 * - Real-time performance monitoring
 * - Evolution analytics and insights
 * - Trend analysis and forecasting
 * - Performance bottleneck identification
 */

import {
  EvolutionResult,
  CodeDNA,
  FitnessScore,
  EvolutionDnaId,
  MutationType
} from '../../types';

/**
 * Evolution performance metrics
 */
export interface EvolutionPerformanceMetrics {
  readonly totalEvolutions: number;
  readonly successfulEvolutions: number;
  readonly failedEvolutions: number;
  readonly averageEvolutionTime: number;     // milliseconds
  readonly averageFitnessImprovement: number;
  readonly averageConfidence: number;
  readonly evolutionThroughput: number;      // evolutions per hour
  readonly lastEvolutionTime: Date;
}

/**
 * Fitness evaluation metrics
 */
export interface FitnessEvaluationMetrics {
  readonly totalEvaluations: number;
  readonly averageEvaluationTime: number;   // milliseconds
  readonly averageFitnessScore: number;
  readonly fitnessDistribution: readonly {
    readonly range: string;
    readonly count: number;
    readonly percentage: number;
  }[];
  readonly trendDirection: 'improving' | 'declining' | 'stable';
  readonly lastEvaluationTime: Date;
}

/**
 * Mutation strategy metrics
 */
export interface MutationStrategyMetrics {
  readonly strategyName: string;
  readonly usageCount: number;
  readonly successRate: number;
  readonly averageImprovementScore: number;
  readonly averageConfidence: number;
  readonly preferredGenes: readonly string[];
  readonly riskProfile: 'low' | 'medium' | 'high';
}

/**
 * Gene mutation analysis
 */
export interface GeneMutationAnalysis {
  readonly geneName: string;
  readonly mutationCount: number;
  readonly averageChange: number;
  readonly successRate: number;
  readonly impactScore: number;            // How much this gene affects overall fitness
  readonly stabilityScore: number;         // How stable mutations on this gene are
  readonly lastMutationTime: Date;
}

/**
 * Performance trend data point
 */
export interface TrendDataPoint {
  readonly timestamp: Date;
  readonly value: number;
  readonly label?: string;
  readonly metadata?: Record<string, unknown>;
}

/**
 * Evolution analytics insights
 */
export interface EvolutionInsights {
  readonly topPerformingStrategies: readonly MutationStrategyMetrics[];
  readonly mostImpactfulGenes: readonly GeneMutationAnalysis[];
  readonly performanceTrends: {
    readonly fitness: readonly TrendDataPoint[];
    readonly evolutionSpeed: readonly TrendDataPoint[];
    readonly successRate: readonly TrendDataPoint[];
  };
  readonly recommendations: readonly string[];
  readonly anomalies: readonly {
    readonly type: string;
    readonly description: string;
    readonly severity: 'low' | 'medium' | 'high';
    readonly timestamp: Date;
  }[];
}

/**
 * Real-time performance snapshot
 */
export interface PerformanceSnapshot {
  readonly timestamp: Date;
  readonly evolutionMetrics: EvolutionPerformanceMetrics;
  readonly fitnessMetrics: FitnessEvaluationMetrics;
  readonly mutationMetrics: readonly MutationStrategyMetrics[];
  readonly geneAnalysis: readonly GeneMutationAnalysis[];
  readonly systemHealth: {
    readonly overallScore: number;
    readonly bottlenecks: readonly string[];
    readonly recommendations: readonly string[];
  };
}

/**
 * Comprehensive evolution metrics collector and analyzer
 */
export class EvolutionMetrics {
  private evolutionHistory: EvolutionResult[] = [];
  private fitnessHistory: Array<{ dnaId: EvolutionDnaId; score: FitnessScore; timestamp: Date; metrics: any }> = [];
  private mutationStrategyStats: Map<string, {
    count: number;
    totalImprovement: number;
    totalConfidence: number;
    successes: number;
    geneCounts: Map<string, number>;
  }> = new Map();
  private geneStats: Map<string, {
    mutationCount: number;
    totalChange: number;
    successes: number;
    totalImpact: number;
    lastMutation: Date;
  }> = new Map();
  
  private readonly startTime: Date = new Date();
  private readonly maxHistorySize: number = 10000;

  /**
   * Record an evolution result
   */
  recordEvolution(result: EvolutionResult, durationMs: number): void {
    // Add duration to result metadata
    const resultWithDuration = {
      ...result,
      metadata: {
        ...result.metadata,
        durationMs,
        timestamp: new Date(),
      }
    };
    
    this.evolutionHistory.push(resultWithDuration);
    
    // Update mutation strategy stats if successful
    if (result.success) {
      this.updateMutationStrategyStats(result);
      
      // Update gene stats if DNA has mutations
      if (result.newDna?.mutations) {
        for (const mutation of result.newDna.mutations) {
          this.updateGeneStats(mutation.targetGene, mutation.delta, true, Math.abs(result.improvementScore));
        }
      }
    }
    
    // Maintain history size
    if (this.evolutionHistory.length > this.maxHistorySize) {
      this.evolutionHistory = this.evolutionHistory.slice(-this.maxHistorySize);
    }
  }

  /**
   * Record fitness evaluation
   */
  recordFitnessEvaluation(dnaId: EvolutionDnaId, score: FitnessScore, metrics: any): void {
    this.fitnessHistory.push({
      dnaId,
      score,
      timestamp: new Date(),
      metrics,
    });
    
    // Maintain history size
    if (this.fitnessHistory.length > this.maxHistorySize) {
      this.fitnessHistory = this.fitnessHistory.slice(-this.maxHistorySize);
    }
  }

  /**
   * Get current performance snapshot
   */
  getPerformanceSnapshot(): PerformanceSnapshot {
    return {
      timestamp: new Date(),
      evolutionMetrics: this.calculateEvolutionMetrics(),
      fitnessMetrics: this.calculateFitnessMetrics(),
      mutationMetrics: this.calculateMutationStrategyMetrics(),
      geneAnalysis: this.calculateGeneAnalysis(),
      systemHealth: this.assessSystemHealth(),
    };
  }

  /**
   * Get evolution insights and analytics
   */
  getEvolutionInsights(): EvolutionInsights {
    const mutationMetrics = this.calculateMutationStrategyMetrics();
    const geneAnalysis = this.calculateGeneAnalysis();
    
    return {
      topPerformingStrategies: mutationMetrics
        .sort((a, b) => b.successRate - a.successRate)
        .slice(0, 5),
      mostImpactfulGenes: geneAnalysis
        .sort((a, b) => b.impactScore - a.impactScore)
        .slice(0, 10),
      performanceTrends: {
        fitness: this.calculateFitnessTrend(),
        evolutionSpeed: this.calculateEvolutionSpeedTrend(),
        successRate: this.calculateSuccessRateTrend(),
      },
      recommendations: this.generateRecommendations(),
      anomalies: this.detectAnomalies(),
    };
  }

  /**
   * Calculate evolution performance metrics
   */
  private calculateEvolutionMetrics(): EvolutionPerformanceMetrics {
    if (this.evolutionHistory.length === 0) {
      return {
        totalEvolutions: 0,
        successfulEvolutions: 0,
        failedEvolutions: 0,
        averageEvolutionTime: 0,
        averageFitnessImprovement: 0,
        averageConfidence: 0,
        evolutionThroughput: 0,
        lastEvolutionTime: this.startTime,
      };
    }
    
    const totalEvolutions = this.evolutionHistory.length;
    const successfulEvolutions = this.evolutionHistory.filter(r => r.success).length;
    const failedEvolutions = totalEvolutions - successfulEvolutions;
    
    // Calculate averages from metadata
    const evolutionsWithDuration = this.evolutionHistory.filter(r => r.metadata?.durationMs);
    const averageEvolutionTime = evolutionsWithDuration.length > 0
      ? evolutionsWithDuration.reduce((sum, r) => sum + (r.metadata?.durationMs as number), 0) / evolutionsWithDuration.length
      : 0;
    
    const successfulResults = this.evolutionHistory.filter(r => r.success);
    const averageFitnessImprovement = successfulResults.length > 0
      ? successfulResults.reduce((sum, r) => sum + r.improvementScore, 0) / successfulResults.length
      : 0;
    
    const averageConfidence = this.evolutionHistory.reduce((sum, r) => sum + r.confidence, 0) / totalEvolutions;
    
    // Calculate throughput (evolutions per hour)
    const timeSpan = Date.now() - this.startTime.getTime();
    const hoursElapsed = timeSpan / (1000 * 60 * 60);
    const evolutionThroughput = hoursElapsed > 0 ? totalEvolutions / hoursElapsed : 0;
    
    const lastEvolutionTime = this.evolutionHistory.length > 0
      ? (this.evolutionHistory[this.evolutionHistory.length - 1].metadata?.timestamp as Date) || new Date()
      : this.startTime;
    
    return {
      totalEvolutions,
      successfulEvolutions,
      failedEvolutions,
      averageEvolutionTime,
      averageFitnessImprovement,
      averageConfidence,
      evolutionThroughput,
      lastEvolutionTime,
    };
  }

  /**
   * Calculate fitness evaluation metrics
   */
  private calculateFitnessMetrics(): FitnessEvaluationMetrics {
    if (this.fitnessHistory.length === 0) {
      return {
        totalEvaluations: 0,
        averageEvaluationTime: 0,
        averageFitnessScore: 0,
        fitnessDistribution: [],
        trendDirection: 'stable',
        lastEvaluationTime: this.startTime,
      };
    }
    
    const totalEvaluations = this.fitnessHistory.length;
    const averageFitnessScore = this.fitnessHistory.reduce((sum, entry) => sum + entry.score, 0) / totalEvaluations;
    
    // Calculate fitness distribution
    const fitnessDistribution = this.calculateFitnessDistribution();
    
    // Determine trend direction
    const trendDirection = this.calculateFitnessTrendDirection();
    
    const lastEvaluationTime = this.fitnessHistory[this.fitnessHistory.length - 1].timestamp;
    
    return {
      totalEvaluations,
      averageEvaluationTime: 50, // Placeholder - would need to track actual evaluation times
      averageFitnessScore,
      fitnessDistribution,
      trendDirection,
      lastEvaluationTime,
    };
  }

  /**
   * Calculate mutation strategy metrics
   */
  private calculateMutationStrategyMetrics(): readonly MutationStrategyMetrics[] {
    const strategies: MutationStrategyMetrics[] = [];
    
    for (const [strategyName, stats] of this.mutationStrategyStats) {
      const successRate = stats.count > 0 ? stats.successes / stats.count : 0;
      const averageImprovementScore = stats.count > 0 ? stats.totalImprovement / stats.count : 0;
      const averageConfidence = stats.count > 0 ? stats.totalConfidence / stats.count : 0;
      
      // Get preferred genes (most frequently mutated)
      const preferredGenes = Array.from(stats.geneCounts.entries())
        .sort(([, countA], [, countB]) => countB - countA)
        .slice(0, 3)
        .map(([gene]) => gene);
      
      // Determine risk profile based on success rate and confidence
      let riskProfile: 'low' | 'medium' | 'high';
      if (successRate > 0.8 && averageConfidence > 0.7) {
        riskProfile = 'low';
      } else if (successRate > 0.6 && averageConfidence > 0.5) {
        riskProfile = 'medium';
      } else {
        riskProfile = 'high';
      }
      
      strategies.push({
        strategyName,
        usageCount: stats.count,
        successRate,
        averageImprovementScore,
        averageConfidence,
        preferredGenes,
        riskProfile,
      });
    }
    
    return strategies.sort((a, b) => b.usageCount - a.usageCount);
  }

  /**
   * Calculate gene analysis
   */
  private calculateGeneAnalysis(): readonly GeneMutationAnalysis[] {
    const analyses: GeneMutationAnalysis[] = [];
    
    for (const [geneName, stats] of this.geneStats) {
      const successRate = stats.mutationCount > 0 ? stats.successes / stats.mutationCount : 0;
      const averageChange = stats.mutationCount > 0 ? Math.abs(stats.totalChange) / stats.mutationCount : 0;
      const impactScore = stats.mutationCount > 0 ? stats.totalImpact / stats.mutationCount : 0;
      
      // Calculate stability score (inverse of change variance)
      const stabilityScore = Math.max(0, 1 - (averageChange * 2)); // Higher stability for smaller changes
      
      analyses.push({
        geneName,
        mutationCount: stats.mutationCount,
        averageChange,
        successRate,
        impactScore,
        stabilityScore,
        lastMutationTime: stats.lastMutation,
      });
    }
    
    return analyses.sort((a, b) => b.mutationCount - a.mutationCount);
  }

  /**
   * Assess overall system health
   */
  private assessSystemHealth(): {
    overallScore: number;
    bottlenecks: readonly string[];
    recommendations: readonly string[];
  } {
    const bottlenecks: string[] = [];
    const recommendations: string[] = [];
    let overallScore = 1.0;
    
    const evolutionMetrics = this.calculateEvolutionMetrics();
    const fitnessMetrics = this.calculateFitnessMetrics();
    
    // Check evolution success rate
    const successRate = evolutionMetrics.totalEvolutions > 0
      ? evolutionMetrics.successfulEvolutions / evolutionMetrics.totalEvolutions
      : 1;
    
    if (successRate < 0.6) {
      bottlenecks.push('Low evolution success rate');
      recommendations.push('Review mutation strategies and validation rules');
      overallScore *= 0.8;
    }
    
    // Check average evolution time
    if (evolutionMetrics.averageEvolutionTime > 300) { // More than 300ms
      bottlenecks.push('Slow evolution performance');
      recommendations.push('Optimize fitness evaluation or mutation algorithms');
      overallScore *= 0.9;
    }
    
    // Check fitness improvement trend
    if (fitnessMetrics.trendDirection === 'declining') {
      bottlenecks.push('Declining fitness trend');
      recommendations.push('Adjust evolution parameters or mutation strategies');
      overallScore *= 0.7;
    }
    
    // Check confidence levels
    if (evolutionMetrics.averageConfidence < 0.5) {
      bottlenecks.push('Low confidence in mutations');
      recommendations.push('Review validation criteria and mutation generation');
      overallScore *= 0.85;
    }
    
    // Check throughput
    if (evolutionMetrics.evolutionThroughput < 10) { // Less than 10 per hour
      bottlenecks.push('Low evolution throughput');
      recommendations.push('Consider parallel processing or algorithm optimization');
      overallScore *= 0.9;
    }
    
    return {
      overallScore: Math.max(0.1, overallScore),
      bottlenecks,
      recommendations,
    };
  }

  /**
   * Update mutation strategy statistics
   */
  private updateMutationStrategyStats(result: EvolutionResult): void {
    const strategyName = MutationType[result.evolutionType] || 'unknown';
    
    if (!this.mutationStrategyStats.has(strategyName)) {
      this.mutationStrategyStats.set(strategyName, {
        count: 0,
        totalImprovement: 0,
        totalConfidence: 0,
        successes: 0,
        geneCounts: new Map(),
      });
    }
    
    const stats = this.mutationStrategyStats.get(strategyName)!;
    stats.count++;
    stats.totalImprovement += result.improvementScore;
    stats.totalConfidence += result.confidence;
    
    if (result.improvementScore > 0) {
      stats.successes++;
    }
    
    // Update gene counts if mutations are available
    if (result.newDna?.mutations) {
      for (const mutation of result.newDNA.mutations) {
        const currentCount = stats.geneCounts.get(mutation.targetGene) || 0;
        stats.geneCounts.set(mutation.targetGene, currentCount + 1);
      }
    }
  }

  /**
   * Update gene statistics
   */
  private updateGeneStats(
    geneName: string,
    change: number,
    success: boolean,
    impact: number
  ): void {
    if (!this.geneStats.has(geneName)) {
      this.geneStats.set(geneName, {
        mutationCount: 0,
        totalChange: 0,
        successes: 0,
        totalImpact: 0,
        lastMutation: new Date(),
      });
    }
    
    const stats = this.geneStats.get(geneName)!;
    stats.mutationCount++;
    stats.totalChange += change;
    stats.totalImpact += impact;
    stats.lastMutation = new Date();
    
    if (success) {
      stats.successes++;
    }
  }

  /**
   * Calculate fitness distribution
   */
  private calculateFitnessDistribution(): readonly {
    readonly range: string;
    readonly count: number;
    readonly percentage: number;
  }[] {
    if (this.fitnessHistory.length === 0) return [];
    
    const ranges = [
      { min: 0.0, max: 0.2, label: '0.0-0.2' },
      { min: 0.2, max: 0.4, label: '0.2-0.4' },
      { min: 0.4, max: 0.6, label: '0.4-0.6' },
      { min: 0.6, max: 0.8, label: '0.6-0.8' },
      { min: 0.8, max: 1.0, label: '0.8-1.0' },
    ];
    
    const distribution = ranges.map(range => {
      const count = this.fitnessHistory.filter(entry => 
        entry.score >= range.min && entry.score < range.max
      ).length;
      
      return {
        range: range.label,
        count,
        percentage: (count / this.fitnessHistory.length) * 100,
      };
    });
    
    return distribution;
  }

  /**
   * Calculate fitness trend direction
   */
  private calculateFitnessTrendDirection(): 'improving' | 'declining' | 'stable' {
    if (this.fitnessHistory.length < 10) return 'stable';
    
    const recentEntries = this.fitnessHistory.slice(-10);
    const firstHalf = recentEntries.slice(0, 5);
    const secondHalf = recentEntries.slice(5);
    
    const firstHalfAvg = firstHalf.reduce((sum, entry) => sum + entry.score, 0) / firstHalf.length;
    const secondHalfAvg = secondHalf.reduce((sum, entry) => sum + entry.score, 0) / secondHalf.length;
    
    const difference = secondHalfAvg - firstHalfAvg;
    
    if (difference > 0.05) return 'improving';
    if (difference < -0.05) return 'declining';
    return 'stable';
  }

  /**
   * Calculate fitness trend data
   */
  private calculateFitnessTrend(): readonly TrendDataPoint[] {
    // Group by time windows and calculate averages
    const timeWindows = this.groupByTimeWindows(this.fitnessHistory, 60 * 60 * 1000); // 1 hour windows
    
    return timeWindows.map(window => ({
      timestamp: new Date(window.timestamp),
      value: window.averageFitness,
      label: `Fitness`,
      metadata: { count: window.count }
    }));
  }

  /**
   * Calculate evolution speed trend
   */
  private calculateEvolutionSpeedTrend(): readonly TrendDataPoint[] {
    const evolutionsWithDuration = this.evolutionHistory.filter(r => r.metadata?.durationMs);
    const timeWindows = this.groupByTimeWindows(
      evolutionsWithDuration.map(r => ({
        timestamp: r.metadata?.timestamp as Date,
        value: r.metadata?.durationMs as number
      })),
      60 * 60 * 1000 // 1 hour windows
    );
    
    return timeWindows.map(window => ({
      timestamp: new Date(window.timestamp),
      value: window.averageValue,
      label: `Speed (ms)`,
      metadata: { count: window.count }
    }));
  }

  /**
   * Calculate success rate trend
   */
  private calculateSuccessRateTrend(): readonly TrendDataPoint[] {
    const timeWindows = this.groupByTimeWindows(
      this.evolutionHistory.map(r => ({
        timestamp: r.metadata?.timestamp as Date || new Date(),
        value: r.success ? 1 : 0
      })),
      60 * 60 * 1000 // 1 hour windows
    );
    
    return timeWindows.map(window => ({
      timestamp: new Date(window.timestamp),
      value: window.averageValue,
      label: `Success Rate`,
      metadata: { count: window.count }
    }));
  }

  /**
   * Group data points by time windows
   */
  private groupByTimeWindows(
    data: { timestamp: Date; value: number }[],
    windowSize: number
  ): Array<{ timestamp: number; averageValue: number; averageFitness?: number; count: number }> {
    if (data.length === 0) return [];
    
    const windows: Map<number, { values: number[]; fitnessValues?: number[] }> = new Map();
    
    for (const point of data) {
      const windowStart = Math.floor(point.timestamp.getTime() / windowSize) * windowSize;
      
      if (!windows.has(windowStart)) {
        windows.set(windowStart, { values: [] });
      }
      
      windows.get(windowStart)!.values.push(point.value);
    }
    
    return Array.from(windows.entries()).map(([timestamp, window]) => ({
      timestamp,
      averageValue: window.values.reduce((sum, val) => sum + val, 0) / window.values.length,
      count: window.values.length,
    }));
  }

  /**
   * Generate insights and recommendations
   */
  private generateRecommendations(): readonly string[] {
    const recommendations: string[] = [];
    const evolutionMetrics = this.calculateEvolutionMetrics();
    const mutationMetrics = this.calculateMutationStrategyMetrics();
    
    // Success rate recommendations
    const successRate = evolutionMetrics.totalEvolutions > 0
      ? evolutionMetrics.successfulEvolutions / evolutionMetrics.totalEvolutions
      : 1;
    
    if (successRate < 0.7) {
      recommendations.push('Success rate is below optimal. Consider adjusting mutation parameters or validation rules.');
    }
    
    // Performance recommendations
    if (evolutionMetrics.averageEvolutionTime > 200) {
      recommendations.push('Evolution time is above target. Consider optimizing fitness evaluation or using parallel processing.');
    }
    
    // Strategy recommendations
    const bestStrategy = mutationMetrics.find(s => s.successRate > 0.8 && s.usageCount > 5);
    if (bestStrategy) {
      recommendations.push(`${bestStrategy.strategyName} shows high success rate. Consider increasing its usage.`);
    }
    
    const worstStrategy = mutationMetrics.find(s => s.successRate < 0.4 && s.usageCount > 5);
    if (worstStrategy) {
      recommendations.push(`${worstStrategy.strategyName} has low success rate. Review its implementation or reduce usage.`);
    }
    
    return recommendations;
  }

  /**
   * Detect performance anomalies
   */
  private detectAnomalies(): readonly {
    readonly type: string;
    readonly description: string;
    readonly severity: 'low' | 'medium' | 'high';
    readonly timestamp: Date;
  }[] {
    const anomalies: Array<{
      readonly type: string;
      readonly description: string;
      readonly severity: 'low' | 'medium' | 'high';
      readonly timestamp: Date;
    }> = [];
    
    // Check for sudden drops in success rate
    const recentEvolutions = this.evolutionHistory.slice(-20);
    if (recentEvolutions.length >= 10) {
      const recentSuccessRate = recentEvolutions.filter(r => r.success).length / recentEvolutions.length;
      if (recentSuccessRate < 0.3) {
        anomalies.push({
          type: 'performance_degradation',
          description: `Success rate dropped to ${(recentSuccessRate * 100).toFixed(1)}% in recent evolutions`,
          severity: 'high',
          timestamp: new Date(),
        });
      }
    }
    
    // Check for fitness stagnation
    const recentFitness = this.fitnessHistory.slice(-50);
    if (recentFitness.length >= 20) {
      const fitnessVariance = this.calculateVariance(recentFitness.map(f => f.score));
      if (fitnessVariance < 0.01) {
        anomalies.push({
          type: 'fitness_stagnation',
          description: 'Fitness scores showing little variation, possible local optimum',
          severity: 'medium',
          timestamp: new Date(),
        });
      }
    }
    
    return anomalies;
  }

  /**
   * Calculate variance for anomaly detection
   */
  private calculateVariance(values: number[]): number {
    if (values.length === 0) return 0;
    
    const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
    const squaredDifferences = values.map(val => Math.pow(val - mean, 2));
    
    return squaredDifferences.reduce((sum, diff) => sum + diff, 0) / values.length;
  }

  /**
   * Export metrics data for external analysis
   */
  exportMetrics(): {
    evolutionHistory: readonly EvolutionResult[];
    fitnessHistory: readonly any[];
    performanceSnapshot: PerformanceSnapshot;
    insights: EvolutionInsights;
  } {
    return {
      evolutionHistory: [...this.evolutionHistory],
      fitnessHistory: [...this.fitnessHistory],
      performanceSnapshot: this.getPerformanceSnapshot(),
      insights: this.getEvolutionInsights(),
    };
  }

  /**
   * Reset all metrics (for testing)
   */
  reset(): void {
    this.evolutionHistory = [];
    this.fitnessHistory = [];
    this.mutationStrategyStats.clear();
    this.geneStats.clear();
  }
}

export default EvolutionMetrics;