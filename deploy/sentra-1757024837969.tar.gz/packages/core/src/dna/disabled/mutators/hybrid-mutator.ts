/**
 * Hybrid Mutator - Advanced multi-strategy mutation combining multiple approaches
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 * 
 * This mutator focuses on:
 * - Combining optimization and adaptation strategies
 * - Balancing competing objectives
 * - Cross-pollination from similar DNA patterns
 * - Emergent behavior development
 */

import { BaseMutator, MutationOptions, MutationValidation } from './base-mutator';
import {
  CodeDNA,
  Mutation,
  MutationType,
  ProjectContext,
  GeneticMarkers
} from '../../types';
import { OptimizationMutator } from './optimization-mutator';
import { AdaptationMutator } from './adaptation-mutator';
import { SimplificationMutator } from './simplification-mutator';

/**
 * Hybrid-specific mutation options
 */
export interface HybridMutationOptions extends MutationOptions {
  readonly hybridStrategy?: 'balanced' | 'optimization-focused' | 'adaptation-focused' | 'innovation-focused';
  readonly crossPollination?: readonly CodeDNA[];  // Similar DNA patterns for cross-pollination
  readonly emergentBehavior?: boolean;             // Whether to encourage emergent behaviors
  readonly balanceWeight?: number;                 // How much to balance competing objectives
}

/**
 * Strategy weights for hybrid mutations
 */
interface StrategyWeights {
  readonly optimization: number;
  readonly adaptation: number;
  readonly simplification: number;
  readonly innovation: number;
}

/**
 * Hybrid pattern generation mutation strategy
 */
export class HybridMutator extends BaseMutator {
  private readonly optimizationMutator: OptimizationMutator;
  private readonly adaptationMutator: AdaptationMutator;
  private readonly simplificationMutator: SimplificationMutator;

  constructor() {
    super('CROSSOVER');
    
    // Initialize sub-mutators for hybrid strategies
    this.optimizationMutator = new OptimizationMutator();
    this.adaptationMutator = new AdaptationMutator();
    this.simplificationMutator = new SimplificationMutator();
  }

  /**
   * Generate hybrid mutations combining multiple strategies
   */
  async generateMutations(
    dna: CodeDNA,
    context: ProjectContext,
    options: HybridMutationOptions = {}
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    // Calculate hybrid intensity and strategy weights
    const intensity = this.calculateHybridIntensity(dna, context, options);
    const strategyWeights = this.calculateStrategyWeights(dna, context, options);
    
    // Generate cross-pollination mutations if similar DNA provided
    if (options.crossPollination && options.crossPollination.length > 0) {
      const crossPollinationMutations = await this.generateCrossPollinationMutations(
        dna,
        options.crossPollination,
        intensity,
        options
      );
      mutations.push(...crossPollinationMutations);
    }
    
    // Generate balanced multi-objective mutations
    const balancedMutations = await this.generateBalancedMutations(
      dna,
      context,
      strategyWeights,
      intensity,
      options
    );
    mutations.push(...balancedMutations);
    
    // Generate emergent behavior mutations if enabled
    if (options.emergentBehavior) {
      const emergentMutations = await this.generateEmergentMutations(
        dna,
        context,
        intensity,
        options
      );
      mutations.push(...emergentMutations);
    }
    
    // Generate synergistic mutations (genes that work well together)
    const synergisticMutations = await this.generateSynergisticMutations(
      dna,
      context,
      intensity,
      options
    );
    mutations.push(...synergisticMutations);
    
    // Limit mutations based on options and prioritize by confidence
    const maxMutations = options.maxMutations ?? 5;
    return mutations
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, maxMutations);
  }

  /**
   * Validate hybrid mutation
   */
  async validateMutation(mutation: Mutation): Promise<MutationValidation> {
    const risks: string[] = [];
    let confidence = mutation.confidence;
    
    // Check for hybrid-specific risks
    if (Math.abs(mutation.delta) > 0.4) {
      risks.push('Large hybrid mutation may cause unpredictable interactions');
      confidence *= 0.8;
    }
    
    // Validate gene interactions for hybrid mutations
    const interactionRisks = this.assessGeneInteractionRisks(mutation);
    risks.push(...interactionRisks);
    confidence *= Math.max(0.5, 1 - interactionRisks.length * 0.1);
    
    // Check for over-optimization in hybrid context
    if (mutation.newValue > 0.95 || mutation.newValue < 0.05) {
      risks.push('Extreme value may reduce hybrid flexibility');
      confidence *= 0.7;
    }
    
    const expectedImpact = this.estimateMutationImpact(
      { genetics: { [mutation.targetGene]: mutation.previousValue } } as CodeDNA,
      mutation.targetGene,
      mutation.newValue
    );
    
    return {
      isValid: confidence > 0.4 && risks.length < 3,
      confidence: Math.max(0.2, confidence),
      reasoning: `Hybrid mutation combining multiple strategies for ${mutation.targetGene}`,
      risks,
      expectedImpact,
    };
  }

  /**
   * Calculate hybrid mutation intensity
   */
  private calculateHybridIntensity(
    dna: CodeDNA,
    context: ProjectContext,
    options: HybridMutationOptions
  ): number {
    let intensity = options.intensity ?? 0.45;
    
    // Adjust intensity based on DNA's hybrid potential
    const hybridPotential = this.calculateHybridPotential(dna);
    intensity *= hybridPotential;
    
    // Consider context complexity for hybrid approaches
    const complexityMap: Record<string, number> = {
      'low': 0.8,      // Simple contexts don't need complex hybrid strategies
      'medium': 1.0,   // Ideal for hybrid approaches
      'high': 1.2,     // Complex contexts benefit from hybrid strategies
      'enterprise': 1.3,
      'research': 1.4,
    };
    
    intensity *= complexityMap[context.complexity] ?? 1.0;
    
    // Adjust for balance weight
    if (options.balanceWeight) {
      intensity *= (0.7 + options.balanceWeight * 0.6);
    }
    
    return Math.max(0.15, Math.min(0.7, intensity));
  }

  /**
   * Calculate DNA's potential for hybrid strategies
   */
  private calculateHybridPotential(dna: CodeDNA): number {
    // Genes that indicate good hybrid potential
    const hybridFriendlyGenes = [
      'adaptability',
      'transferability',
      'learningVelocity',
      'creativity',
      'novelty'
    ];
    
    const avgHybridScore = hybridFriendlyGenes
      .reduce((sum, gene) => sum + dna.genetics[gene], 0) / hybridFriendlyGenes.length;
    
    // DNA with diverse evolution history has better hybrid potential
    const evolutionDiversity = this.calculateEvolutionDiversity(dna.evolutionHistory);
    
    return (avgHybridScore * 0.7) + (evolutionDiversity * 0.3);
  }

  /**
   * Calculate diversity of evolution history
   */
  private calculateEvolutionDiversity(evolutionHistory: readonly any[]): number {
    if (evolutionHistory.length < 2) return 0.5;
    
    const recentSteps = evolutionHistory.slice(-5);
    const uniqueOutcomes = new Set(recentSteps.map(step => step.outcome));
    
    // More diverse outcomes indicate better hybrid potential
    return Math.min(1, uniqueOutcomes.size / 3);
  }

  /**
   * Calculate strategy weights for hybrid approach
   */
  private calculateStrategyWeights(
    dna: CodeDNA,
    context: ProjectContext,
    options: HybridMutationOptions
  ): StrategyWeights {
    const baseWeights: StrategyWeights = {
      optimization: 0.25,
      adaptation: 0.25,
      simplification: 0.25,
      innovation: 0.25,
    };
    
    // Adjust weights based on hybrid strategy
    switch (options.hybridStrategy) {
      case 'optimization-focused':
        return {
          optimization: 0.4,
          adaptation: 0.3,
          simplification: 0.2,
          innovation: 0.1,
        };
        
      case 'adaptation-focused':
        return {
          optimization: 0.2,
          adaptation: 0.4,
          simplification: 0.25,
          innovation: 0.15,
        };
        
      case 'innovation-focused':
        return {
          optimization: 0.15,
          adaptation: 0.25,
          simplification: 0.2,
          innovation: 0.4,
        };
        
      case 'balanced':
      default:
        // Adjust balanced weights based on current needs
        let weights = { ...baseWeights };
        
        // Increase optimization if performance is poor
        if (dna.performance.successRate < 0.6) {
          weights.optimization += 0.1;
          weights.innovation -= 0.05;
          weights.simplification -= 0.05;
        }
        
        // Increase adaptation if context mismatch is high
        if (dna.context.projectType !== context.projectType) {
          weights.adaptation += 0.15;
          weights.optimization -= 0.05;
          weights.innovation -= 0.1;
        }
        
        // Increase simplification if complexity is high
        if (dna.genetics.complexity > 0.7) {
          weights.simplification += 0.1;
          weights.innovation -= 0.1;
        }
        
        return weights;
    }
  }

  /**
   * Generate cross-pollination mutations from similar DNA patterns
   */
  private async generateCrossPollinationMutations(
    dna: CodeDNA,
    similarDNA: readonly CodeDNA[],
    intensity: number,
    options: HybridMutationOptions
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    // Select best performing similar DNA for cross-pollination
    const bestSimilar = similarDNA
      .filter(similar => similar.fitnessScore > dna.fitnessScore)
      .sort((a, b) => b.fitnessScore - a.fitnessScore)
      .slice(0, 3);
    
    if (bestSimilar.length === 0) return mutations;
    
    // For each similar DNA, identify beneficial genes to cross-pollinate
    for (const similar of bestSimilar) {
      const crossPollinationCandidates = this.identifyBeneficialGenes(dna, similar);
      
      for (const gene of crossPollinationCandidates) {
        const mutation = this.createCrossPollinationMutation(
          dna,
          similar,
          gene,
          intensity,
          options
        );
        if (mutation) {
          mutations.push(mutation);
        }
      }
    }
    
    return mutations;
  }

  /**
   * Identify genes that would be beneficial to cross-pollinate
   */
  private identifyBeneficialGenes(
    dna: CodeDNA,
    similarDNA: CodeDNA
  ): (keyof GeneticMarkers)[] {
    const beneficialGenes: (keyof GeneticMarkers)[] = [];
    
    // Find genes where similar DNA significantly outperforms current DNA
    const geneKeys = Object.keys(dna.genetics) as (keyof GeneticMarkers)[];
    
    for (const gene of geneKeys) {
      const currentValue = dna.genetics[gene];
      const similarValue = similarDNA.genetics[gene];
      const difference = similarValue - currentValue;
      
      // Only consider significant improvements
      if (difference > 0.1 && similarValue > 0.6) {
        beneficialGenes.push(gene);
      }
    }
    
    // Prioritize genes based on their importance for performance
    return beneficialGenes
      .sort((a, b) => this.getGeneImportanceWeight(b) - this.getGeneImportanceWeight(a))
      .slice(0, 3);
  }

  /**
   * Get importance weight for gene prioritization
   */
  private getGeneImportanceWeight(gene: keyof GeneticMarkers): number {
    const weights: Partial<Record<keyof GeneticMarkers, number>> = {
      successRate: 1.0,
      adaptability: 0.9,
      stability: 0.9,
      learningVelocity: 0.8,
      resourceEfficiency: 0.8,
      errorRecovery: 0.8,
      transferability: 0.7,
      thoroughness: 0.7,
      communicationClarity: 0.6,
      collaborationAffinity: 0.6,
      patternRecognition: 0.5,
      complexity: 0.4,
      novelty: 0.4,
      creativity: 0.3,
      empathy: 0.3,
      pragmatism: 0.3,
      persistence: 0.3,
      riskTolerance: 0.2,
    };
    
    return weights[gene] ?? 0.5;
  }

  /**
   * Create cross-pollination mutation
   */
  private createCrossPollinationMutation(
    dna: CodeDNA,
    similarDNA: CodeDNA,
    gene: keyof GeneticMarkers,
    intensity: number,
    options: HybridMutationOptions
  ): Mutation | null {
    const currentValue = dna.genetics[gene];
    const targetValue = similarDNA.genetics[gene];
    
    // Interpolate between current and target based on intensity
    const newValue = currentValue + (targetValue - currentValue) * intensity * 0.7;
    
    // Only create mutation if change is meaningful
    if (Math.abs(newValue - currentValue) < 0.04) {
      return null;
    }
    
    const confidence = this.calculateCrossPollinationConfidence(
      dna,
      similarDNA,
      gene,
      newValue
    );
    
    return this.createMutation(
      gene,
      currentValue,
      newValue,
      {
        type: 'cross_pollination',
        details: `Cross-pollination from similar DNA with fitness ${similarDNA.fitnessScore}`,
        sourceAgentId: undefined, // Would be set if we had agent ID from similar DNA
      },
      {
        confidence,
        ...options,
      }
    );
  }

  /**
   * Calculate confidence for cross-pollination mutation
   */
  private calculateCrossPollinationConfidence(
    dna: CodeDNA,
    similarDNA: CodeDNA,
    gene: keyof GeneticMarkers,
    newValue: number
  ): number {
    let confidence = 0.6; // Base confidence for cross-pollination
    
    // Higher confidence if similar DNA has much higher fitness
    const fitnessGap = similarDNA.fitnessScore - dna.fitnessScore;
    confidence += fitnessGap * 0.3;
    
    // Higher confidence for genes with proven track record
    if (gene === 'successRate' || gene === 'adaptability') {
      confidence += 0.1;
    }
    
    // Consider the magnitude of change
    const changeSize = Math.abs(newValue - dna.genetics[gene]);
    if (changeSize > 0.3) {
      confidence *= 0.8; // Reduce confidence for large changes
    }
    
    return Math.max(0.3, Math.min(0.9, confidence));
  }

  /**
   * Generate balanced mutations that optimize multiple objectives
   */
  private async generateBalancedMutations(
    dna: CodeDNA,
    context: ProjectContext,
    weights: StrategyWeights,
    intensity: number,
    options: HybridMutationOptions
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    // Identify genes that affect multiple objectives
    const multiObjectiveGenes = this.identifyMultiObjectiveGenes(dna, context);
    
    for (const geneInfo of multiObjectiveGenes) {
      const mutation = this.createBalancedMutation(
        dna,
        context,
        geneInfo,
        weights,
        intensity,
        options
      );
      if (mutation) {
        mutations.push(mutation);
      }
    }
    
    return mutations;
  }

  /**
   * Identify genes that affect multiple objectives
   */
  private identifyMultiObjectiveGenes(
    dna: CodeDNA,
    context: ProjectContext
  ): Array<{
    gene: keyof GeneticMarkers;
    objectives: string[];
    conflictLevel: number;
  }> {
    const multiObjectiveGenes: Array<{
      gene: keyof GeneticMarkers;
      objectives: string[];
      conflictLevel: number;
    }> = [];
    
    // Complexity affects performance, maintainability, and innovation
    multiObjectiveGenes.push({
      gene: 'complexity',
      objectives: ['performance', 'maintainability', 'innovation'],
      conflictLevel: 0.7,
    });
    
    // Thoroughness affects quality and speed
    multiObjectiveGenes.push({
      gene: 'thoroughness',
      objectives: ['quality', 'speed'],
      conflictLevel: 0.6,
    });
    
    // Risk tolerance affects innovation and stability
    multiObjectiveGenes.push({
      gene: 'riskTolerance',
      objectives: ['innovation', 'stability'],
      conflictLevel: 0.8,
    });
    
    // Adaptability affects learning and stability
    multiObjectiveGenes.push({
      gene: 'adaptability',
      objectives: ['learning', 'stability'],
      conflictLevel: 0.4,
    });
    
    // Resource efficiency affects performance and quality
    multiObjectiveGenes.push({
      gene: 'resourceEfficiency',
      objectives: ['performance', 'quality'],
      conflictLevel: 0.3,
    });
    
    return multiObjectiveGenes;
  }

  /**
   * Create balanced mutation considering multiple objectives
   */
  private createBalancedMutation(
    dna: CodeDNA,
    context: ProjectContext,
    geneInfo: { gene: keyof GeneticMarkers; objectives: string[]; conflictLevel: number },
    weights: StrategyWeights,
    intensity: number,
    options: HybridMutationOptions
  ): Mutation | null {
    const currentValue = dna.genetics[geneInfo.gene];
    
    // Calculate optimal value considering all objectives
    const optimalValue = this.calculateOptimalValueForObjectives(
      dna,
      context,
      geneInfo,
      weights
    );
    
    // Apply balance weight to reduce conflicts
    const balanceWeight = options.balanceWeight ?? 0.5;
    const conflictReduction = geneInfo.conflictLevel * balanceWeight;
    
    // Interpolate toward optimal value with conflict reduction
    let newValue = currentValue + (optimalValue - currentValue) * intensity * (1 - conflictReduction * 0.3);
    
    // Ensure value stays within reasonable bounds
    newValue = Math.max(0.1, Math.min(0.9, newValue));
    
    // Only create mutation if change is meaningful
    if (Math.abs(newValue - currentValue) < 0.04) {
      return null;
    }
    
    const confidence = this.calculateBalancedMutationConfidence(
      dna,
      geneInfo,
      newValue,
      conflictReduction
    );
    
    return this.createMutation(
      geneInfo.gene,
      currentValue,
      newValue,
      {
        type: 'targeted_improvement',
        details: `Balanced mutation for ${geneInfo.gene} optimizing: ${geneInfo.objectives.join(', ')}`,
      },
      {
        confidence,
        ...options,
      }
    );
  }

  /**
   * Calculate optimal value considering multiple objectives
   */
  private calculateOptimalValueForObjectives(
    dna: CodeDNA,
    context: ProjectContext,
    geneInfo: { gene: keyof GeneticMarkers; objectives: string[]; conflictLevel: number },
    weights: StrategyWeights
  ): number {
    // This is a simplified optimization - in practice, this could use more sophisticated
    // multi-objective optimization algorithms
    
    const currentValue = dna.genetics[geneInfo.gene];
    let optimalValue = currentValue;
    
    // Adjust based on objective weights and current performance
    for (const objective of geneInfo.objectives) {
      const adjustment = this.getObjectiveAdjustment(dna, context, geneInfo.gene, objective, weights);
      optimalValue += adjustment;
    }
    
    // Average the adjustments to balance objectives
    optimalValue /= geneInfo.objectives.length;
    
    return Math.max(0.1, Math.min(0.9, optimalValue));
  }

  /**
   * Get adjustment for specific objective
   */
  private getObjectiveAdjustment(
    dna: CodeDNA,
    context: ProjectContext,
    gene: keyof GeneticMarkers,
    objective: string,
    weights: StrategyWeights
  ): number {
    const currentValue = dna.genetics[gene];
    let targetValue = currentValue;
    
    switch (objective) {
      case 'performance':
        if (gene === 'complexity' && dna.performance.responseLatency > 2000) {
          targetValue = Math.max(0.3, currentValue - 0.2); // Reduce complexity for speed
        } else if (gene === 'resourceEfficiency') {
          targetValue = Math.min(0.9, currentValue + 0.2);
        }
        break;
        
      case 'quality':
        if (gene === 'thoroughness' && dna.performance.codeQualityScore < 0.7) {
          targetValue = Math.min(0.9, currentValue + 0.2);
        }
        break;
        
      case 'stability':
        if (gene === 'riskTolerance' && dna.performance.errorRecoveryRate < 0.6) {
          targetValue = Math.max(0.2, currentValue - 0.2);
        }
        break;
        
      case 'innovation':
        if (gene === 'complexity' || gene === 'riskTolerance') {
          targetValue = Math.min(0.8, currentValue + 0.1);
        }
        break;
    }
    
    // Weight the adjustment based on strategy weights
    const objectiveWeight = this.getObjectiveWeight(objective, weights);
    return (targetValue - currentValue) * objectiveWeight;
  }

  /**
   * Get weight for objective based on strategy weights
   */
  private getObjectiveWeight(objective: string, weights: StrategyWeights): number {
    switch (objective) {
      case 'performance': return weights.optimization;
      case 'adaptation': return weights.adaptation;
      case 'simplicity': return weights.simplification;
      case 'innovation': return weights.innovation;
      default: return 0.25;
    }
  }

  /**
   * Calculate confidence for balanced mutation
   */
  private calculateBalancedMutationConfidence(
    dna: CodeDNA,
    geneInfo: { gene: keyof GeneticMarkers; conflictLevel: number },
    newValue: number,
    conflictReduction: number
  ): number {
    let confidence = this.calculateMutationConfidence(dna, geneInfo.gene, newValue - dna.genetics[geneInfo.gene]);
    
    // Reduce confidence for high-conflict mutations
    confidence *= (1 - geneInfo.conflictLevel * 0.3);
    
    // Boost confidence if we're reducing conflicts
    confidence += conflictReduction * 0.2;
    
    return Math.max(0.3, Math.min(0.9, confidence));
  }

  /**
   * Generate emergent behavior mutations
   */
  private async generateEmergentMutations(
    dna: CodeDNA,
    context: ProjectContext,
    intensity: number,
    options: HybridMutationOptions
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    // Identify potential emergent behaviors
    const emergentOpportunities = this.identifyEmergentOpportunities(dna, context);
    
    for (const opportunity of emergentOpportunities) {
      const mutation = this.createEmergentMutation(dna, opportunity, intensity, options);
      if (mutation) {
        mutations.push(mutation);
      }
    }
    
    return mutations;
  }

  /**
   * Identify opportunities for emergent behaviors
   */
  private identifyEmergentOpportunities(
    dna: CodeDNA,
    context: ProjectContext
  ): Array<{
    type: string;
    targetGenes: (keyof GeneticMarkers)[];
    description: string;
  }> {
    const opportunities: Array<{
      type: string;
      targetGenes: (keyof GeneticMarkers)[];
      description: string;
    }> = [];
    
    // Creative problem-solving emergence
    if (dna.genetics.creativity > 0.6 && dna.genetics.patternRecognition > 0.7) {
      opportunities.push({
        type: 'creative-pattern-synthesis',
        targetGenes: ['creativity', 'patternRecognition', 'novelty'],
        description: 'Emergent creative pattern synthesis capability',
      });
    }
    
    // Adaptive learning emergence
    if (dna.genetics.adaptability > 0.7 && dna.genetics.learningVelocity > 0.6) {
      opportunities.push({
        type: 'adaptive-learning-acceleration',
        targetGenes: ['adaptability', 'learningVelocity', 'transferability'],
        description: 'Emergent rapid adaptation learning',
      });
    }
    
    // Collaborative intelligence emergence
    if (dna.genetics.collaborationAffinity > 0.7 && dna.genetics.empathy > 0.6) {
      opportunities.push({
        type: 'collaborative-intelligence',
        targetGenes: ['collaborationAffinity', 'empathy', 'communicationClarity'],
        description: 'Emergent collaborative intelligence',
      });
    }
    
    return opportunities.slice(0, 2); // Limit emergent behaviors
  }

  /**
   * Create emergent behavior mutation
   */
  private createEmergentMutation(
    dna: CodeDNA,
    opportunity: { type: string; targetGenes: (keyof GeneticMarkers)[]; description: string },
    intensity: number,
    options: HybridMutationOptions
  ): Mutation | null {
    // Select the gene with the highest current value as the primary target
    const primaryGene = opportunity.targetGenes
      .reduce((best, gene) => 
        dna.genetics[gene] > dna.genetics[best] ? gene : best
      );
    
    const currentValue = dna.genetics[primaryGene];
    
    // Boost the primary gene to encourage emergence
    const newValue = Math.min(0.95, currentValue + intensity * 0.3);
    
    // Only create mutation if change is meaningful
    if (Math.abs(newValue - currentValue) < 0.03) {
      return null;
    }
    
    return this.createMutation(
      primaryGene,
      currentValue,
      newValue,
      {
        type: 'innovation',
        details: `Emergent behavior development: ${opportunity.description}`,
      },
      {
        confidence: 0.5, // Emergent behaviors are inherently uncertain
        ...options,
      }
    );
  }

  /**
   * Generate synergistic mutations (genes that work well together)
   */
  private async generateSynergisticMutations(
    dna: CodeDNA,
    context: ProjectContext,
    intensity: number,
    options: HybridMutationOptions
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    // Define gene synergies
    const synergies = this.getGeneSynergies();
    
    for (const synergy of synergies) {
      if (this.shouldActivateSynergy(dna, synergy)) {
        const mutation = this.createSynergisticMutation(dna, synergy, intensity, options);
        if (mutation) {
          mutations.push(mutation);
        }
      }
    }
    
    return mutations;
  }

  /**
   * Get predefined gene synergies
   */
  private getGeneSynergies(): Array<{
    genes: (keyof GeneticMarkers)[];
    description: string;
    condition: (dna: CodeDNA) => boolean;
  }> {
    return [
      {
        genes: ['adaptability', 'learningVelocity'],
        description: 'Learning adaptability synergy',
        condition: (dna) => dna.genetics.adaptability > 0.6 || dna.genetics.learningVelocity > 0.6,
      },
      {
        genes: ['stability', 'errorRecovery'],
        description: 'Reliability synergy',
        condition: (dna) => dna.performance.errorRecoveryRate < 0.7,
      },
      {
        genes: ['creativity', 'novelty'],
        description: 'Innovation synergy',
        condition: (dna) => dna.genetics.creativity > 0.5 && dna.genetics.novelty > 0.5,
      },
      {
        genes: ['communicationClarity', 'empathy'],
        description: 'Interpersonal synergy',
        condition: (dna) => dna.performance.teamIntegration < 0.7,
      },
    ];
  }

  /**
   * Check if synergy should be activated
   */
  private shouldActivateSynergy(
    dna: CodeDNA,
    synergy: { condition: (dna: CodeDNA) => boolean }
  ): boolean {
    return synergy.condition(dna);
  }

  /**
   * Create synergistic mutation
   */
  private createSynergisticMutation(
    dna: CodeDNA,
    synergy: { genes: (keyof GeneticMarkers)[]; description: string },
    intensity: number,
    options: HybridMutationOptions
  ): Mutation | null {
    // Select the gene with the lowest value for improvement
    const targetGene = synergy.genes
      .reduce((weakest, gene) => 
        dna.genetics[gene] < dna.genetics[weakest] ? gene : weakest
      );
    
    const currentValue = dna.genetics[targetGene];
    const newValue = Math.min(0.9, currentValue + intensity * 0.25);
    
    // Only create mutation if change is meaningful
    if (Math.abs(newValue - currentValue) < 0.03) {
      return null;
    }
    
    return this.createMutation(
      targetGene,
      currentValue,
      newValue,
      {
        type: 'targeted_improvement',
        details: `Synergistic improvement: ${synergy.description}`,
      },
      {
        confidence: 0.7, // Synergistic mutations are generally safe
        ...options,
      }
    );
  }

  /**
   * Assess gene interaction risks
   */
  private assessGeneInteractionRisks(mutation: Mutation): string[] {
    const risks: string[] = [];
    
    // Check for problematic gene interactions
    if (mutation.targetGene === 'complexity' && mutation.newValue > 0.8) {
      risks.push('High complexity may interact poorly with other optimizations');
    }
    
    if (mutation.targetGene === 'riskTolerance' && mutation.newValue > 0.8) {
      risks.push('High risk tolerance may destabilize other traits');
    }
    
    if (mutation.targetGene === 'novelty' && mutation.newValue > 0.9) {
      risks.push('Extreme novelty seeking may conflict with stability requirements');
    }
    
    return risks;
  }
}

export default HybridMutator;