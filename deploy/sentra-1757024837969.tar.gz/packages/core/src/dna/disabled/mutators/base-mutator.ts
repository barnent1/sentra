/**
 * Base Mutator - Abstract base class for all mutation strategies
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 */

import {
  CodeDNA,
  Mutation,
  MutationId,
  MutationType,
  MutationTrigger,
  GeneticMarkers,
  PerformanceFeedback,
  ProjectContext
} from '../../types';
import type { Brand } from '@sentra/types';

/**
 * Mutation generation options
 */
export interface MutationOptions {
  readonly intensity?: number;      // 0-1: How aggressive the mutation should be
  readonly targetGenes?: readonly (keyof GeneticMarkers)[];
  readonly preserveTraits?: readonly string[];
  readonly maxMutations?: number;
  readonly confidence?: number;     // 0-1: Confidence in mutation success
}

/**
 * Mutation validation result
 */
export interface MutationValidation {
  readonly isValid: boolean;
  readonly confidence: number;
  readonly reasoning: string;
  readonly risks: readonly string[];
  readonly expectedImpact: number; // -1 to 1: Expected impact on fitness
}

/**
 * Abstract base class for mutation strategies
 */
export abstract class BaseMutator {
  protected readonly mutationType: keyof typeof MutationType;
  
  constructor(mutationType: keyof typeof MutationType) {
    this.mutationType = mutationType;
  }

  /**
   * Generate mutations for a DNA pattern
   */
  abstract generateMutations(
    dna: CodeDNA,
    ...args: any[]
  ): Promise<Mutation[]>;

  /**
   * Validate a proposed mutation
   */
  abstract validateMutation(mutation: Mutation): Promise<MutationValidation>;

  /**
   * Create a base mutation structure
   */
  protected createMutation(
    targetGene: keyof GeneticMarkers,
    currentValue: number,
    newValue: number,
    trigger: MutationTrigger,
    options: MutationOptions = {}
  ): Mutation {
    const delta = newValue - currentValue;
    
    return {
      id: this.generateMutationId(),
      type: MutationType[this.mutationType],
      targetGene,
      previousValue: currentValue,
      newValue: Math.max(0, Math.min(1, newValue)), // Clamp to valid range
      delta,
      trigger,
      confidence: options.confidence ?? 0.7,
      timestamp: new Date(),
      context: this.createMutationContext(),
    };
  }

  /**
   * Generate unique mutation ID
   */
  protected generateMutationId(): MutationId {
    return `mut_${this.mutationType}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}` as MutationId;
  }

  /**
   * Create mutation context
   */
  protected createMutationContext() {
    return {
      projectType: 'unknown',
      taskComplexity: 'medium' as const,
      teamDynamics: 'small_team' as const,
      pressureLevel: 'moderate' as const,
      environmentFactors: [this.mutationType.toLowerCase()],
    };
  }

  /**
   * Calculate mutation intensity based on various factors
   */
  protected calculateMutationIntensity(
    dna: CodeDNA,
    targetPerformance?: number,
    contextPressure?: number
  ): number {
    let intensity = 0.3; // Base intensity
    
    // Increase intensity for poor performance
    if (dna.performance.successRate < 0.6) {
      intensity += 0.2;
    }
    
    // Increase intensity based on generation (older DNA needs more change)
    const generationFactor = Math.min(0.3, dna.generation * 0.02);
    intensity += generationFactor;
    
    // Adjust for context pressure
    if (contextPressure) {
      intensity += contextPressure * 0.2;
    }
    
    // Adjust for target performance
    if (targetPerformance && dna.fitnessScore < targetPerformance) {
      const gap = targetPerformance - dna.fitnessScore;
      intensity += gap * 0.5;
    }
    
    // Apply novelty factor (more novel DNA can handle more intensity)
    const noveltyFactor = dna.genetics.novelty * 0.1;
    intensity += noveltyFactor;
    
    // Apply risk tolerance (higher risk tolerance allows more intensity)
    const riskFactor = dna.genetics.riskTolerance * 0.15;
    intensity += riskFactor;
    
    return Math.max(0.1, Math.min(0.8, intensity));
  }

  /**
   * Select genes for mutation based on strategy and current performance
   */
  protected selectTargetGenes(
    dna: CodeDNA,
    maxGenes: number = 3,
    strategy: 'random' | 'performance-based' | 'weak-points' = 'performance-based'
  ): (keyof GeneticMarkers)[] {
    const allGenes: (keyof GeneticMarkers)[] = [
      'complexity', 'adaptability', 'successRate', 'transferability',
      'stability', 'novelty', 'patternRecognition', 'errorRecovery',
      'communicationClarity', 'learningVelocity', 'resourceEfficiency',
      'collaborationAffinity', 'riskTolerance', 'thoroughness',
      'creativity', 'persistence', 'empathy', 'pragmatism'
    ];
    
    switch (strategy) {
      case 'random':
        return this.shuffleArray([...allGenes]).slice(0, maxGenes);
        
      case 'weak-points':
        // Target genes with lowest values
        return allGenes
          .sort((a, b) => dna.genetics[a] - dna.genetics[b])
          .slice(0, maxGenes);
          
      case 'performance-based':
      default:
        // Target genes based on performance needs
        return this.selectPerformanceBasedGenes(dna, maxGenes);
    }
  }

  /**
   * Select genes based on performance analysis
   */
  private selectPerformanceBasedGenes(
    dna: CodeDNA,
    maxGenes: number
  ): (keyof GeneticMarkers)[] {
    const candidates: Array<{ gene: keyof GeneticMarkers; priority: number }> = [];
    
    // Analyze performance metrics to determine gene priorities
    if (dna.performance.successRate < 0.7) {
      candidates.push(
        { gene: 'successRate', priority: 0.9 },
        { gene: 'thoroughness', priority: 0.8 },
        { gene: 'persistence', priority: 0.7 }
      );
    }
    
    if (dna.performance.responseLatency > 2000) {
      candidates.push(
        { gene: 'resourceEfficiency', priority: 0.9 },
        { gene: 'pragmatism', priority: 0.7 }
      );
    }
    
    if (dna.performance.adaptationSpeed < 0.6) {
      candidates.push(
        { gene: 'adaptability', priority: 0.9 },
        { gene: 'learningVelocity', priority: 0.8 }
      );
    }
    
    if (dna.performance.errorRecoveryRate < 0.7) {
      candidates.push(
        { gene: 'errorRecovery', priority: 0.9 },
        { gene: 'stability', priority: 0.7 }
      );
    }
    
    if (dna.performance.teamIntegration < 0.7) {
      candidates.push(
        { gene: 'collaborationAffinity', priority: 0.8 },
        { gene: 'communicationClarity', priority: 0.8 },
        { gene: 'empathy', priority: 0.6 }
      );
    }
    
    if (dna.performance.codeQualityScore < 0.8) {
      candidates.push(
        { gene: 'thoroughness', priority: 0.8 },
        { gene: 'complexity', priority: 0.6 }
      );
    }
    
    // If no specific issues, focus on general improvement
    if (candidates.length === 0) {
      candidates.push(
        { gene: 'adaptability', priority: 0.6 },
        { gene: 'learningVelocity', priority: 0.6 },
        { gene: 'novelty', priority: 0.5 }
      );
    }
    
    // Sort by priority and return top genes
    return candidates
      .sort((a, b) => b.priority - a.priority)
      .slice(0, maxGenes)
      .map(c => c.gene);
  }

  /**
   * Fisher-Yates shuffle algorithm
   */
  private shuffleArray<T>(array: T[]): T[] {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  /**
   * Apply Gaussian noise to a value
   */
  protected applyGaussianNoise(value: number, stdDev: number = 0.1): number {
    // Box-Muller transformation for Gaussian noise
    let u = 0, v = 0;
    while (u === 0) u = Math.random(); // Converting [0,1) to (0,1)
    while (v === 0) v = Math.random();
    
    const noise = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    
    return Math.max(0, Math.min(1, value + (noise * stdDev)));
  }

  /**
   * Calculate mutation confidence based on historical success
   */
  protected calculateMutationConfidence(
    dna: CodeDNA,
    targetGene: keyof GeneticMarkers,
    proposedChange: number
  ): number {
    let confidence = 0.5; // Base confidence
    
    // Higher confidence for smaller changes
    const changeSize = Math.abs(proposedChange);
    confidence += (1 - changeSize) * 0.2;
    
    // Higher confidence for genes with good historical performance
    if (dna.genetics[targetGene] > 0.7) {
      confidence += 0.1;
    }
    
    // Higher confidence if DNA has good overall performance
    if (dna.performance.successRate > 0.8) {
      confidence += 0.1;
    }
    
    // Higher confidence if DNA has stable evolution history
    const recentHistory = dna.evolutionHistory.slice(-3);
    const improvementCount = recentHistory.filter(step => step.outcome === 'improvement').length;
    if (improvementCount >= 2) {
      confidence += 0.1;
    }
    
    return Math.max(0.1, Math.min(0.9, confidence));
  }

  /**
   * Estimate mutation impact
   */
  protected estimateMutationImpact(
    dna: CodeDNA,
    targetGene: keyof GeneticMarkers,
    newValue: number
  ): number {
    const currentValue = dna.genetics[targetGene];
    const change = newValue - currentValue;
    
    // Base impact is proportional to change size
    let impact = change * 0.5;
    
    // Adjust impact based on gene importance
    const geneImportance = this.getGeneImportance(targetGene, dna);
    impact *= geneImportance;
    
    // Consider current performance
    if (dna.performance.successRate < 0.6) {
      impact *= 1.2; // Changes have more impact when performance is poor
    }
    
    // Consider gene-specific factors
    if (targetGene === 'successRate' && change > 0) {
      impact *= 1.5; // Improving success rate has high impact
    }
    
    if (targetGene === 'stability' && change < 0) {
      impact *= 1.3; // Reducing stability has high negative impact
    }
    
    return Math.max(-1, Math.min(1, impact));
  }

  /**
   * Get importance weight for a specific gene
   */
  private getGeneImportance(gene: keyof GeneticMarkers, dna: CodeDNA): number {
    // Base importance weights
    const importanceWeights: Partial<Record<keyof GeneticMarkers, number>> = {
      successRate: 0.9,
      adaptability: 0.8,
      stability: 0.8,
      errorRecovery: 0.7,
      learningVelocity: 0.7,
      resourceEfficiency: 0.6,
      thoroughness: 0.6,
      communicationClarity: 0.6,
      transferability: 0.5,
      collaborationAffinity: 0.5,
      complexity: 0.4,
      novelty: 0.4,
      patternRecognition: 0.4,
      creativity: 0.3,
      empathy: 0.3,
      pragmatism: 0.3,
      persistence: 0.3,
      riskTolerance: 0.2,
    };
    
    return importanceWeights[gene] ?? 0.5;
  }
}

export default BaseMutator;