/**
 * Adaptation Mutator - Context-specific adaptation strategy
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 * 
 * This mutator focuses on:
 * - Project context alignment
 * - Technology stack adaptation
 * - Team dynamics optimization
 * - Domain-specific improvements
 */

import { BaseMutator, MutationOptions, MutationValidation } from './base-mutator';
import {
  CodeDNA,
  Mutation,
  MutationType,
  ProjectContext,
  GeneticMarkers
} from '../../types';

/**
 * Adaptation-specific mutation options
 */
export interface AdaptationMutationOptions extends MutationOptions {
  readonly adaptationArea?: 'tech-stack' | 'team-dynamics' | 'domain' | 'complexity' | 'all';
  readonly contextWeight?: number;     // How much to weight context factors
  readonly preserveCore?: boolean;     // Whether to preserve core traits during adaptation
}

/**
 * Context adaptation mutation strategy
 */
export class AdaptationMutator extends BaseMutator {
  constructor() {
    super('ADAPTATION');
  }

  /**
   * Generate context adaptation mutations
   */
  async generateMutations(
    dna: CodeDNA,
    context: ProjectContext,
    options: AdaptationMutationOptions = {}
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    // Calculate adaptation intensity based on context mismatch
    const intensity = this.calculateAdaptationIntensity(dna, context, options);
    
    // Identify adaptation opportunities
    const adaptationTargets = this.identifyAdaptationTargets(dna, context);
    
    // Generate mutations for each adaptation target
    for (const target of adaptationTargets) {
      const targetMutations = await this.generateAdaptationMutations(
        dna,
        context,
        target,
        intensity,
        options
      );
      mutations.push(...targetMutations);
    }
    
    // Limit mutations based on options
    const maxMutations = options.maxMutations ?? 4;
    return mutations
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, maxMutations);
  }

  /**
   * Validate adaptation mutation
   */
  async validateMutation(mutation: Mutation): Promise<MutationValidation> {
    const risks: string[] = [];
    let confidence = mutation.confidence;
    
    // Check for context-specific risks
    if (mutation.targetGene === 'stability' && mutation.delta < -0.2) {
      risks.push('Large stability reduction during adaptation may cause issues');
      confidence *= 0.7;
    }
    
    if (mutation.targetGene === 'successRate' && mutation.delta < 0) {
      risks.push('Reducing success rate during adaptation is risky');
      confidence *= 0.6;
    }
    
    // Validate adaptation makes sense
    if (Math.abs(mutation.delta) < 0.03) {
      risks.push('Adaptation change too small to be meaningful');
      confidence *= 0.8;
    }
    
    const expectedImpact = this.estimateMutationImpact(
      { genetics: { [mutation.targetGene]: mutation.previousValue } } as CodeDNA,
      mutation.targetGene,
      mutation.newValue
    );
    
    return {
      isValid: confidence > 0.4 && risks.length < 2,
      confidence: Math.max(0.2, confidence),
      reasoning: `Adaptation mutation for ${mutation.targetGene} to better fit project context`,
      risks,
      expectedImpact,
    };
  }

  /**
   * Calculate adaptation intensity based on context mismatch
   */
  private calculateAdaptationIntensity(
    dna: CodeDNA,
    context: ProjectContext,
    options: AdaptationMutationOptions
  ): number {
    let intensity = options.intensity ?? 0.35;
    
    // Analyze context mismatch
    const mismatchScore = this.calculateContextMismatch(dna, context);
    intensity += mismatchScore * 0.4;
    
    // Consider adaptability traits
    const adaptabilityFactor = dna.genetics.adaptability;
    intensity *= (0.5 + adaptabilityFactor * 0.5); // Scale by adaptability
    
    // Apply context weight
    if (options.contextWeight) {
      intensity *= options.contextWeight;
    }
    
    // Reduce intensity if preserving core traits
    if (options.preserveCore) {
      intensity *= 0.7;
    }
    
    return Math.max(0.1, Math.min(0.7, intensity));
  }

  /**
   * Calculate how much DNA mismatches the current context
   */
  private calculateContextMismatch(dna: CodeDNA, context: ProjectContext): number {
    let mismatch = 0;
    
    // Project type mismatch
    if (dna.context.projectType !== context.projectType) {
      mismatch += 0.3;
    }
    
    // Complexity mismatch
    const complexityMismatch = this.calculateComplexityMismatch(dna, context);
    mismatch += complexityMismatch * 0.2;
    
    // Team size mismatch
    const teamMismatch = this.calculateTeamSizeMismatch(dna, context);
    mismatch += teamMismatch * 0.15;
    
    // Tech stack mismatch
    const techMismatch = this.calculateTechStackMismatch(dna, context);
    mismatch += techMismatch * 0.2;
    
    // Domain mismatch
    if (dna.context.industryDomain !== context.industryDomain) {
      mismatch += 0.15;
    }
    
    return Math.min(1, mismatch);
  }

  /**
   * Calculate complexity mismatch
   */
  private calculateComplexityMismatch(dna: CodeDNA, context: ProjectContext): number {
    const complexityMap: Record<string, number> = {
      'low': 0.2,
      'medium': 0.5,
      'high': 0.7,
      'enterprise': 0.9,
      'research': 1.0,
    };
    
    const currentComplexity = dna.genetics.complexity;
    const targetComplexity = complexityMap[context.complexity] ?? 0.5;
    
    return Math.abs(currentComplexity - targetComplexity);
  }

  /**
   * Calculate team size mismatch
   */
  private calculateTeamSizeMismatch(dna: CodeDNA, context: ProjectContext): number {
    const currentCollaboration = dna.genetics.collaborationAffinity;
    let optimalCollaboration: number;
    
    if (context.teamSize <= 2) {
      optimalCollaboration = 0.4;
    } else if (context.teamSize <= 5) {
      optimalCollaboration = 0.7;
    } else if (context.teamSize <= 10) {
      optimalCollaboration = 0.8;
    } else {
      optimalCollaboration = 0.9;
    }
    
    return Math.abs(currentCollaboration - optimalCollaboration);
  }

  /**
   * Calculate tech stack mismatch (simplified)
   */
  private calculateTechStackMismatch(dna: CodeDNA, context: ProjectContext): number {
    // This would be more sophisticated with actual tech stack analysis
    // For now, estimate based on project type transition
    const typeTransitions: Record<string, Record<string, number>> = {
      'web-app': { 'api': 0.2, 'cli': 0.6, 'library': 0.5, 'ai-ml': 0.7, 'infrastructure': 0.8 },
      'api': { 'web-app': 0.2, 'cli': 0.4, 'library': 0.3, 'ai-ml': 0.5, 'infrastructure': 0.6 },
      'cli': { 'web-app': 0.6, 'api': 0.4, 'library': 0.3, 'ai-ml': 0.4, 'infrastructure': 0.3 },
      'library': { 'web-app': 0.5, 'api': 0.3, 'cli': 0.3, 'ai-ml': 0.4, 'infrastructure': 0.4 },
      'ai-ml': { 'web-app': 0.7, 'api': 0.5, 'cli': 0.4, 'library': 0.4, 'infrastructure': 0.5 },
      'infrastructure': { 'web-app': 0.8, 'api': 0.6, 'cli': 0.3, 'library': 0.4, 'ai-ml': 0.5 },
    };
    
    return typeTransitions[dna.context.projectType]?.[context.projectType] ?? 0.5;
  }

  /**
   * Identify specific adaptation targets
   */
  private identifyAdaptationTargets(
    dna: CodeDNA,
    context: ProjectContext
  ): Array<{
    area: string;
    targetGenes: (keyof GeneticMarkers)[];
    priority: number;
    adaptationStrategy: string;
  }> {
    const targets: Array<{
      area: string;
      targetGenes: (keyof GeneticMarkers)[];
      priority: number;
      adaptationStrategy: string;
    }> = [];
    
    // Project type adaptation
    const projectTypeTarget = this.getProjectTypeAdaptation(dna.context.projectType, context.projectType);
    if (projectTypeTarget) {
      targets.push(projectTypeTarget);
    }
    
    // Complexity adaptation
    const complexityMismatch = this.calculateComplexityMismatch(dna, context);
    if (complexityMismatch > 0.2) {
      targets.push({
        area: 'complexity',
        targetGenes: ['complexity', 'thoroughness', 'pragmatism'],
        priority: 0.8,
        adaptationStrategy: 'adjust_complexity_level',
      });
    }
    
    // Team size adaptation
    const teamMismatch = this.calculateTeamSizeMismatch(dna, context);
    if (teamMismatch > 0.2) {
      targets.push({
        area: 'team-dynamics',
        targetGenes: ['collaborationAffinity', 'communicationClarity', 'empathy'],
        priority: 0.7,
        adaptationStrategy: 'optimize_team_collaboration',
      });
    }
    
    // Performance requirements adaptation
    if (context.performanceRequirements.maxResponseTime < 1000) {
      targets.push({
        area: 'performance',
        targetGenes: ['resourceEfficiency', 'pragmatism', 'complexity'],
        priority: 0.75,
        adaptationStrategy: 'optimize_for_speed',
      });
    }
    
    // Scalability requirements adaptation
    if (context.scalabilityNeeds.expectedGrowthRate > 2) {
      targets.push({
        area: 'scalability',
        targetGenes: ['adaptability', 'transferability', 'learningVelocity'],
        priority: 0.65,
        adaptationStrategy: 'enhance_scalability',
      });
    }
    
    // Security requirements adaptation
    if (context.securityRequirements.dataPrivacyLevel === 'restricted') {
      targets.push({
        area: 'security',
        targetGenes: ['thoroughness', 'stability', 'patternRecognition'],
        priority: 0.6,
        adaptationStrategy: 'increase_security_awareness',
      });
    }
    
    return targets.sort((a, b) => b.priority - a.priority);
  }

  /**
   * Get project type adaptation strategy
   */
  private getProjectTypeAdaptation(
    fromType: string,
    toType: string
  ): { area: string; targetGenes: (keyof GeneticMarkers)[]; priority: number; adaptationStrategy: string } | null {
    
    if (fromType === toType) return null;
    
    const adaptationMap: Record<string, Record<string, {
      genes: (keyof GeneticMarkers)[];
      strategy: string;
      priority: number;
    }>> = {
      'web-app': {
        'api': {
          genes: ['pragmatism', 'thoroughness', 'patternRecognition'],
          strategy: 'focus_on_systematic_api_design',
          priority: 0.85,
        },
        'ai-ml': {
          genes: ['learningVelocity', 'novelty', 'adaptability'],
          strategy: 'enhance_learning_and_innovation',
          priority: 0.9,
        },
        'infrastructure': {
          genes: ['stability', 'errorRecovery', 'thoroughness'],
          strategy: 'prioritize_reliability_and_stability',
          priority: 0.9,
        },
      },
      'api': {
        'web-app': {
          genes: ['creativity', 'empathy', 'collaborationAffinity'],
          strategy: 'develop_user_experience_focus',
          priority: 0.8,
        },
        'ai-ml': {
          genes: ['learningVelocity', 'adaptability', 'novelty'],
          strategy: 'build_learning_capabilities',
          priority: 0.85,
        },
      },
      'cli': {
        'web-app': {
          genes: ['empathy', 'creativity', 'communicationClarity'],
          strategy: 'transition_to_interactive_design',
          priority: 0.8,
        },
        'infrastructure': {
          genes: ['stability', 'thoroughness', 'errorRecovery'],
          strategy: 'enhance_system_reliability',
          priority: 0.75,
        },
      },
    };
    
    const adaptation = adaptationMap[fromType]?.[toType];
    if (!adaptation) return null;
    
    return {
      area: 'project-type',
      targetGenes: adaptation.genes,
      priority: adaptation.priority,
      adaptationStrategy: adaptation.strategy,
    };
  }

  /**
   * Generate mutations for specific adaptation targets
   */
  private async generateAdaptationMutations(
    dna: CodeDNA,
    context: ProjectContext,
    target: { area: string; targetGenes: (keyof GeneticMarkers)[]; adaptationStrategy: string },
    intensity: number,
    options: AdaptationMutationOptions
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    for (const gene of target.targetGenes) {
      const mutation = this.createAdaptationMutation(
        dna,
        context,
        gene,
        target,
        intensity,
        options
      );
      if (mutation) {
        mutations.push(mutation);
      }
    }
    
    return mutations;
  }

  /**
   * Create adaptation mutation for specific gene
   */
  private createAdaptationMutation(
    dna: CodeDNA,
    context: ProjectContext,
    gene: keyof GeneticMarkers,
    target: { area: string; adaptationStrategy: string },
    intensity: number,
    options: AdaptationMutationOptions
  ): Mutation | null {
    const currentValue = dna.genetics[gene];
    let targetValue = currentValue;
    
    // Apply adaptation strategy
    switch (target.adaptationStrategy) {
      case 'adjust_complexity_level':
        if (gene === 'complexity') {
          const complexityMap: Record<string, number> = {
            'low': 0.3,
            'medium': 0.5,
            'high': 0.7,
            'enterprise': 0.85,
            'research': 0.95,
          };
          const optimalComplexity = complexityMap[context.complexity] ?? 0.5;
          targetValue = this.interpolateValue(currentValue, optimalComplexity, intensity);
        } else if (gene === 'thoroughness') {
          // Increase thoroughness for higher complexity projects
          if (context.complexity === 'high' || context.complexity === 'enterprise') {
            targetValue = this.interpolateValue(currentValue, 0.8, intensity);
          }
        }
        break;
        
      case 'optimize_team_collaboration':
        if (gene === 'collaborationAffinity') {
          let optimalCollaboration = 0.7;
          if (context.teamSize > 10) optimalCollaboration = 0.9;
          else if (context.teamSize <= 2) optimalCollaboration = 0.5;
          
          targetValue = this.interpolateValue(currentValue, optimalCollaboration, intensity);
        } else if (gene === 'communicationClarity' || gene === 'empathy') {
          const boost = context.teamSize > 5 ? 0.8 : 0.7;
          targetValue = this.interpolateValue(currentValue, boost, intensity);
        }
        break;
        
      case 'optimize_for_speed':
        if (gene === 'resourceEfficiency' || gene === 'pragmatism') {
          targetValue = this.interpolateValue(currentValue, 0.85, intensity);
        } else if (gene === 'complexity') {
          // Reduce complexity for speed
          targetValue = this.interpolateValue(currentValue, 0.4, intensity);
        }
        break;
        
      case 'enhance_scalability':
        if (gene === 'adaptability' || gene === 'learningVelocity') {
          targetValue = this.interpolateValue(currentValue, 0.8, intensity);
        } else if (gene === 'transferability') {
          targetValue = this.interpolateValue(currentValue, 0.75, intensity);
        }
        break;
        
      case 'increase_security_awareness':
        if (gene === 'thoroughness' || gene === 'stability') {
          targetValue = this.interpolateValue(currentValue, 0.85, intensity);
        } else if (gene === 'patternRecognition') {
          targetValue = this.interpolateValue(currentValue, 0.75, intensity);
        }
        break;
        
      case 'focus_on_systematic_api_design':
        if (gene === 'pragmatism' || gene === 'thoroughness') {
          targetValue = this.interpolateValue(currentValue, 0.8, intensity);
        } else if (gene === 'patternRecognition') {
          targetValue = this.interpolateValue(currentValue, 0.75, intensity);
        }
        break;
        
      case 'enhance_learning_and_innovation':
        if (gene === 'learningVelocity' || gene === 'adaptability') {
          targetValue = this.interpolateValue(currentValue, 0.85, intensity);
        } else if (gene === 'novelty') {
          targetValue = this.interpolateValue(currentValue, 0.7, intensity);
        }
        break;
        
      case 'prioritize_reliability_and_stability':
        if (gene === 'stability' || gene === 'errorRecovery') {
          targetValue = this.interpolateValue(currentValue, 0.9, intensity);
        } else if (gene === 'thoroughness') {
          targetValue = this.interpolateValue(currentValue, 0.85, intensity);
        }
        break;
        
      default:
        // Generic adaptation toward optimal value
        const optimalValue = this.getOptimalValueForContext(gene, context);
        targetValue = this.interpolateValue(currentValue, optimalValue, intensity);
    }
    
    // Only create mutation if there's meaningful change
    if (Math.abs(targetValue - currentValue) < 0.04) {
      return null;
    }
    
    const confidence = this.calculateAdaptationConfidence(dna, gene, targetValue, target.area);
    
    return this.createMutation(
      gene,
      currentValue,
      targetValue,
      {
        type: 'pattern_recognition',
        details: `Adapting ${gene} for ${context.projectType} context using ${target.adaptationStrategy}`,
      },
      {
        confidence,
        ...options,
      }
    );
  }

  /**
   * Interpolate between current and target value based on intensity
   */
  private interpolateValue(current: number, target: number, intensity: number): number {
    const change = (target - current) * intensity;
    return Math.max(0, Math.min(1, current + change));
  }

  /**
   * Get optimal value for gene based on context
   */
  private getOptimalValueForContext(gene: keyof GeneticMarkers, context: ProjectContext): number {
    // Context-specific optimal values
    const contextOptimalValues: Partial<Record<keyof GeneticMarkers, Record<string, number>>> = {
      complexity: {
        'web-app': 0.6,
        'api': 0.5,
        'cli': 0.4,
        'library': 0.6,
        'ai-ml': 0.8,
        'infrastructure': 0.7,
        'blockchain': 0.8,
        'embedded': 0.6,
      },
      collaborationAffinity: {
        'web-app': 0.8,
        'api': 0.7,
        'cli': 0.5,
        'library': 0.6,
        'ai-ml': 0.7,
        'infrastructure': 0.8,
      },
      stability: {
        'infrastructure': 0.9,
        'api': 0.8,
        'web-app': 0.7,
        'cli': 0.6,
        'library': 0.8,
        'ai-ml': 0.6,
      },
      learningVelocity: {
        'ai-ml': 0.9,
        'web-app': 0.7,
        'api': 0.6,
        'cli': 0.5,
        'library': 0.6,
        'infrastructure': 0.5,
      },
    };
    
    return contextOptimalValues[gene]?.[context.projectType] ?? 0.6;
  }

  /**
   * Calculate confidence for adaptation mutation
   */
  private calculateAdaptationConfidence(
    dna: CodeDNA,
    gene: keyof GeneticMarkers,
    targetValue: number,
    adaptationArea: string
  ): number {
    let confidence = this.calculateMutationConfidence(dna, gene, targetValue - dna.genetics[gene]);
    
    // Boost confidence for well-understood adaptations
    if (adaptationArea === 'project-type' && dna.genetics.adaptability > 0.7) {
      confidence += 0.1;
    }
    
    if (adaptationArea === 'complexity' && gene === 'complexity') {
      confidence += 0.15; // Direct complexity adjustment is usually safe
    }
    
    // Reduce confidence for risky adaptations
    if (gene === 'stability' && targetValue < dna.genetics[gene]) {
      confidence *= 0.8; // Reducing stability is risky
    }
    
    return Math.max(0.3, Math.min(0.9, confidence));
  }
}

export default AdaptationMutator;