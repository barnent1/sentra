/**
 * Simplification Mutator - Code simplification and complexity reduction strategy
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 * 
 * This mutator focuses on:
 * - Complexity reduction
 * - Code clarity improvement
 * - Pragmatic simplifications
 * - Technical debt reduction
 */

import { BaseMutator, MutationOptions, MutationValidation } from './base-mutator';
import {
  CodeDNA,
  Mutation,
  MutationType,
  GeneticMarkers
} from '../../types';

/**
 * Simplification-specific mutation options
 */
export interface SimplificationMutationOptions extends MutationOptions {
  readonly simplificationArea?: 'complexity' | 'communication' | 'process' | 'architecture' | 'all';
  readonly aggressiveness?: number;    // How aggressive the simplification should be
  readonly maintainQuality?: boolean;  // Whether to maintain quality during simplification
}

/**
 * Code simplification mutation strategy
 */
export class SimplificationMutator extends BaseMutator {
  constructor() {
    super('REGRESSION'); // Using regression as simplification often means stepping back
  }

  /**
   * Generate simplification mutations
   */
  async generateMutations(
    dna: CodeDNA,
    options: SimplificationMutationOptions = {}
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    // Calculate simplification intensity based on complexity analysis
    const intensity = this.calculateSimplificationIntensity(dna, options);
    
    // Identify simplification opportunities
    const simplificationTargets = this.identifySimplificationTargets(dna);
    
    // Generate mutations for each simplification target
    for (const target of simplificationTargets) {
      const targetMutations = await this.generateSimplificationMutations(
        dna,
        target,
        intensity,
        options
      );
      mutations.push(...targetMutations);
    }
    
    // Limit mutations based on options
    const maxMutations = options.maxMutations ?? 3;
    return mutations
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, maxMutations);
  }

  /**
   * Validate simplification mutation
   */
  async validateMutation(mutation: Mutation): Promise<MutationValidation> {
    const risks: string[] = [];
    let confidence = mutation.confidence;
    
    // Check for risks specific to simplification
    if (mutation.targetGene === 'thoroughness' && mutation.delta < -0.2) {
      risks.push('Large reduction in thoroughness may hurt quality');
      confidence *= 0.7;
    }
    
    if (mutation.targetGene === 'patternRecognition' && mutation.delta < -0.15) {
      risks.push('Reducing pattern recognition may miss important details');
      confidence *= 0.8;
    }
    
    if (mutation.targetGene === 'complexity' && mutation.newValue < 0.2) {
      risks.push('Over-simplification may result in naive solutions');
      confidence *= 0.6;
    }
    
    // Simplification should generally reduce values (except for clarity/pragmatism)
    const isAppropriateDirection = this.isAppropriateSimplificationDirection(mutation);
    if (!isAppropriateDirection) {
      risks.push('Mutation direction inconsistent with simplification goals');
      confidence *= 0.5;
    }
    
    const expectedImpact = this.estimateMutationImpact(
      { genetics: { [mutation.targetGene]: mutation.previousValue } } as CodeDNA,
      mutation.targetGene,
      mutation.newValue
    );
    
    return {
      isValid: confidence > 0.3 && risks.length < 3,
      confidence: Math.max(0.2, confidence),
      reasoning: `Simplification mutation targeting ${mutation.targetGene} to reduce complexity`,
      risks,
      expectedImpact,
    };
  }

  /**
   * Check if mutation direction is appropriate for simplification
   */
  private isAppropriateSimplificationDirection(mutation: Mutation): boolean {
    const gene = mutation.targetGene;
    const delta = mutation.delta;
    
    // These genes should generally increase during simplification
    const shouldIncrease = [
      'pragmatism',
      'communicationClarity',
      'resourceEfficiency'
    ];
    
    // These genes should generally decrease during simplification
    const shouldDecrease = [
      'complexity',
      'novelty',
      'riskTolerance'
    ];
    
    // These can go either way depending on context
    const flexible = [
      'adaptability',
      'creativity',
      'thoroughness',
      'persistence'
    ];
    
    if (shouldIncrease.includes(gene)) {
      return delta > 0;
    }
    
    if (shouldDecrease.includes(gene)) {
      return delta < 0;
    }
    
    // For flexible genes, allow any reasonable change
    return Math.abs(delta) > 0.02;
  }

  /**
   * Calculate simplification intensity based on complexity analysis
   */
  private calculateSimplificationIntensity(
    dna: CodeDNA,
    options: SimplificationMutationOptions
  ): number {
    let intensity = options.intensity ?? 0.4;
    
    // Increase intensity based on current complexity
    if (dna.genetics.complexity > 0.7) {
      intensity += 0.2;
    } else if (dna.genetics.complexity > 0.5) {
      intensity += 0.1;
    }
    
    // Consider performance issues that might benefit from simplification
    if (dna.performance.responseLatency > 3000) {
      intensity += 0.15; // Slow performance might benefit from simplification
    }
    
    if (dna.performance.bugIntroductionRate > 0.15) {
      intensity += 0.1; // High bug rate suggests over-complexity
    }
    
    if (dna.performance.maintainabilityScore < 0.6) {
      intensity += 0.2; // Poor maintainability suggests need for simplification
    }
    
    // Consider communication clarity issues
    if (dna.performance.communicationEffectiveness < 0.6) {
      intensity += 0.1;
    }
    
    // Apply aggressiveness factor
    if (options.aggressiveness) {
      intensity *= (1 + options.aggressiveness * 0.5);
    }
    
    // Reduce intensity if trying to maintain quality
    if (options.maintainQuality && dna.performance.codeQualityScore > 0.7) {
      intensity *= 0.8;
    }
    
    return Math.max(0.1, Math.min(0.6, intensity));
  }

  /**
   * Identify opportunities for simplification
   */
  private identifySimplificationTargets(
    dna: CodeDNA
  ): Array<{
    area: string;
    targetGenes: (keyof GeneticMarkers)[];
    priority: number;
    simplificationStrategy: string;
  }> {
    const targets: Array<{
      area: string;
      targetGenes: (keyof GeneticMarkers)[];
      priority: number;
      simplificationStrategy: string;
    }> = [];
    
    // Complexity reduction (highest priority if complexity is high)
    if (dna.genetics.complexity > 0.6) {
      targets.push({
        area: 'complexity',
        targetGenes: ['complexity', 'pragmatism'],
        priority: 0.9,
        simplificationStrategy: 'reduce_cognitive_complexity',
      });
    }
    
    // Communication simplification
    if (dna.performance.communicationEffectiveness < 0.7) {
      targets.push({
        area: 'communication',
        targetGenes: ['communicationClarity', 'empathy', 'pragmatism'],
        priority: 0.8,
        simplificationStrategy: 'improve_communication_clarity',
      });
    }
    
    // Process simplification (if over-engineered)
    if (dna.genetics.thoroughness > 0.8 && dna.performance.responseLatency > 2000) {
      targets.push({
        area: 'process',
        targetGenes: ['thoroughness', 'pragmatism', 'resourceEfficiency'],
        priority: 0.75,
        simplificationStrategy: 'streamline_processes',
      });
    }
    
    // Architecture simplification
    if (dna.performance.maintainabilityScore < 0.6) {
      targets.push({
        area: 'architecture',
        targetGenes: ['complexity', 'patternRecognition', 'pragmatism'],
        priority: 0.7,
        simplificationStrategy: 'simplify_architecture',
      });
    }
    
    // Over-optimization simplification
    if (dna.genetics.resourceEfficiency > 0.9 && dna.performance.maintainabilityScore < 0.7) {
      targets.push({
        area: 'optimization',
        targetGenes: ['resourceEfficiency', 'pragmatism', 'complexity'],
        priority: 0.65,
        simplificationStrategy: 'reduce_over_optimization',
      });
    }
    
    // Risk simplification (reduce unnecessary risk-taking)
    if (dna.genetics.riskTolerance > 0.7 && dna.performance.errorRecoveryRate < 0.6) {
      targets.push({
        area: 'risk',
        targetGenes: ['riskTolerance', 'stability', 'pragmatism'],
        priority: 0.6,
        simplificationStrategy: 'reduce_unnecessary_risks',
      });
    }
    
    // Innovation simplification (focus on proven solutions)
    if (dna.genetics.novelty > 0.8 && dna.performance.successRate < 0.7) {
      targets.push({
        area: 'innovation',
        targetGenes: ['novelty', 'pragmatism', 'patternRecognition'],
        priority: 0.6,
        simplificationStrategy: 'focus_on_proven_solutions',
      });
    }
    
    return targets.sort((a, b) => b.priority - a.priority);
  }

  /**
   * Generate mutations for specific simplification targets
   */
  private async generateSimplificationMutations(
    dna: CodeDNA,
    target: { area: string; targetGenes: (keyof GeneticMarkers)[]; simplificationStrategy: string },
    intensity: number,
    options: SimplificationMutationOptions
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    for (const gene of target.targetGenes) {
      const mutation = this.createSimplificationMutation(
        dna,
        gene,
        target,
        intensity,
        options
      );
      if (mutation) {
        mutations.push(mutation);
      }
    }
    
    return mutations;
  }

  /**
   * Create simplification mutation for specific gene
   */
  private createSimplificationMutation(
    dna: CodeDNA,
    gene: keyof GeneticMarkers,
    target: { area: string; simplificationStrategy: string },
    intensity: number,
    options: SimplificationMutationOptions
  ): Mutation | null {
    const currentValue = dna.genetics[gene];
    let targetValue = currentValue;
    
    // Apply simplification strategy
    switch (target.simplificationStrategy) {
      case 'reduce_cognitive_complexity':
        if (gene === 'complexity') {
          // Reduce complexity, but not below a reasonable minimum
          const minComplexity = options.maintainQuality ? 0.3 : 0.2;
          targetValue = Math.max(minComplexity, currentValue - intensity * 0.4);
        } else if (gene === 'pragmatism') {
          // Increase pragmatism to balance complexity reduction
          targetValue = Math.min(1.0, currentValue + intensity * 0.3);
        }
        break;
        
      case 'improve_communication_clarity':
        if (gene === 'communicationClarity') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.4);
        } else if (gene === 'empathy') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.2);
        } else if (gene === 'pragmatism') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.3);
        }
        break;
        
      case 'streamline_processes':
        if (gene === 'thoroughness') {
          // Reduce thoroughness but maintain minimum quality
          const minThoroughness = options.maintainQuality ? 0.6 : 0.4;
          targetValue = Math.max(minThoroughness, currentValue - intensity * 0.3);
        } else if (gene === 'pragmatism' || gene === 'resourceEfficiency') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.3);
        }
        break;
        
      case 'simplify_architecture':
        if (gene === 'complexity') {
          targetValue = Math.max(0.25, currentValue - intensity * 0.35);
        } else if (gene === 'patternRecognition') {
          // Slightly reduce pattern recognition to avoid over-engineering
          targetValue = Math.max(0.4, currentValue - intensity * 0.2);
        } else if (gene === 'pragmatism') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.4);
        }
        break;
        
      case 'reduce_over_optimization':
        if (gene === 'resourceEfficiency') {
          // Reduce from extreme optimization to reasonable level
          targetValue = Math.max(0.7, Math.min(0.85, currentValue - intensity * 0.2));
        } else if (gene === 'complexity') {
          targetValue = Math.max(0.3, currentValue - intensity * 0.25);
        } else if (gene === 'pragmatism') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.3);
        }
        break;
        
      case 'reduce_unnecessary_risks':
        if (gene === 'riskTolerance') {
          targetValue = Math.max(0.3, currentValue - intensity * 0.3);
        } else if (gene === 'stability') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.2);
        } else if (gene === 'pragmatism') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.25);
        }
        break;
        
      case 'focus_on_proven_solutions':
        if (gene === 'novelty') {
          // Reduce novelty to focus on proven approaches
          targetValue = Math.max(0.3, currentValue - intensity * 0.3);
        } else if (gene === 'pragmatism') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.4);
        } else if (gene === 'patternRecognition') {
          // Increase pattern recognition to leverage existing solutions
          targetValue = Math.min(1.0, currentValue + intensity * 0.2);
        }
        break;
        
      default:
        // Generic simplification
        if (this.isComplexityRelatedGene(gene)) {
          targetValue = Math.max(0.25, currentValue - intensity * 0.25);
        } else if (this.isClarityRelatedGene(gene)) {
          targetValue = Math.min(1.0, currentValue + intensity * 0.25);
        }
    }
    
    // Only create mutation if there's meaningful change
    if (Math.abs(targetValue - currentValue) < 0.03) {
      return null;
    }
    
    const confidence = this.calculateSimplificationConfidence(
      dna,
      gene,
      targetValue,
      target.area,
      options
    );
    
    return this.createMutation(
      gene,
      currentValue,
      targetValue,
      {
        type: 'pattern_recognition',
        details: `Simplifying ${gene} using ${target.simplificationStrategy} strategy`,
      },
      {
        confidence,
        ...options,
      }
    );
  }

  /**
   * Check if gene is complexity-related (should generally decrease during simplification)
   */
  private isComplexityRelatedGene(gene: keyof GeneticMarkers): boolean {
    return ['complexity', 'novelty', 'riskTolerance'].includes(gene);
  }

  /**
   * Check if gene is clarity-related (should generally increase during simplification)
   */
  private isClarityRelatedGene(gene: keyof GeneticMarkers): boolean {
    return ['pragmatism', 'communicationClarity', 'resourceEfficiency'].includes(gene);
  }

  /**
   * Calculate confidence for simplification mutation
   */
  private calculateSimplificationConfidence(
    dna: CodeDNA,
    gene: keyof GeneticMarkers,
    targetValue: number,
    simplificationArea: string,
    options: SimplificationMutationOptions
  ): number {
    let confidence = this.calculateMutationConfidence(dna, gene, targetValue - dna.genetics[gene]);
    
    // Boost confidence for well-understood simplifications
    if (simplificationArea === 'complexity' && gene === 'complexity') {
      confidence += 0.2; // Complexity reduction is generally safe
    }
    
    if (simplificationArea === 'communication' && gene === 'communicationClarity') {
      confidence += 0.15; // Improving communication clarity is usually beneficial
    }
    
    // Boost confidence if current performance suggests over-complexity
    if (dna.performance.maintainabilityScore < 0.6) {
      confidence += 0.1;
    }
    
    if (dna.performance.responseLatency > 3000) {
      confidence += 0.1; // Slow performance suggests need for simplification
    }
    
    // Reduce confidence for aggressive changes that might hurt quality
    if (options.maintainQuality && Math.abs(targetValue - dna.genetics[gene]) > 0.3) {
      confidence *= 0.8;
    }
    
    // Reduce confidence if going too far
    if (gene === 'thoroughness' && targetValue < 0.4) {
      confidence *= 0.7; // Very low thoroughness is risky
    }
    
    if (gene === 'complexity' && targetValue < 0.2) {
      confidence *= 0.6; // Over-simplification risk
    }
    
    return Math.max(0.3, Math.min(0.9, confidence));
  }
}

export default SimplificationMutator;