/**
 * Optimization Mutator - Performance-focused mutation strategy
 * Following SENTRA project standards: strict TypeScript with branded types and readonly interfaces
 * 
 * This mutator focuses on:
 * - Performance metric improvements
 * - Resource efficiency optimization
 * - Speed and throughput enhancements
 * - Quality metric improvements
 */

import { BaseMutator, MutationOptions, MutationValidation } from './base-mutator';
import {
  CodeDNA,
  Mutation,
  MutationType,
  PerformanceFeedback,
  GeneticMarkers
} from '../../types';

/**
 * Optimization-specific mutation options
 */
export interface OptimizationMutationOptions extends MutationOptions {
  readonly focusArea?: 'speed' | 'quality' | 'efficiency' | 'reliability' | 'all';
  readonly performanceTarget?: number; // Target performance improvement
  readonly aggressiveness?: number;    // How aggressive the optimization should be
}

/**
 * Performance optimization mutation strategy
 */
export class OptimizationMutator extends BaseMutator {
  constructor() {
    super('TARGETED_IMPROVEMENT');
  }

  /**
   * Generate performance optimization mutations
   */
  async generateMutations(
    dna: CodeDNA,
    feedback: PerformanceFeedback,
    options: OptimizationMutationOptions = {}
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    const intensity = this.calculateOptimizationIntensity(dna, feedback, options);
    
    // Analyze performance feedback to identify optimization opportunities
    const optimizationTargets = this.identifyOptimizationTargets(dna, feedback);
    
    // Generate mutations for each optimization target
    for (const target of optimizationTargets) {
      const targetMutations = await this.generateTargetSpecificMutations(
        dna,
        target,
        intensity,
        options
      );
      mutations.push(...targetMutations);
    }
    
    // Limit mutations based on options
    const maxMutations = options.maxMutations ?? 3;
    return mutations
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, maxMutations);
  }

  /**
   * Validate optimization mutation
   */
  async validateMutation(mutation: Mutation): Promise<MutationValidation> {
    const risks: string[] = [];
    let confidence = mutation.confidence;
    
    // Check for potential risks
    if (Math.abs(mutation.delta) > 0.3) {
      risks.push('Large change may cause instability');
      confidence *= 0.8;
    }
    
    // Check gene-specific risks
    if (mutation.targetGene === 'stability' && mutation.delta < 0) {
      risks.push('Reducing stability is risky for optimization');
      confidence *= 0.6;
    }
    
    if (mutation.targetGene === 'thoroughness' && mutation.delta < 0) {
      risks.push('Reducing thoroughness may hurt quality');
      confidence *= 0.7;
    }
    
    const expectedImpact = this.estimateMutationImpact(
      { genetics: { [mutation.targetGene]: mutation.previousValue } } as CodeDNA,
      mutation.targetGene,
      mutation.newValue
    );
    
    return {
      isValid: confidence > 0.3 && risks.length < 3,
      confidence: Math.max(0.1, confidence),
      reasoning: `Optimization mutation targeting ${mutation.targetGene} for performance improvement`,
      risks,
      expectedImpact,
    };
  }

  /**
   * Calculate optimization intensity based on performance gaps
   */
  private calculateOptimizationIntensity(
    dna: CodeDNA,
    feedback: PerformanceFeedback,
    options: OptimizationMutationOptions
  ): number {
    let intensity = options.intensity ?? 0.4;
    
    // Increase intensity based on performance gaps
    const performanceGaps = this.analyzePerformanceGaps(dna.performance);
    const maxGap = Math.max(...Object.values(performanceGaps));
    
    intensity += maxGap * 0.3;
    
    // Adjust based on feedback outcome
    if (feedback.outcome === 'failure') {
      intensity += 0.2;
    } else if (feedback.outcome === 'partial') {
      intensity += 0.1;
    }
    
    // Consider regression count
    if (feedback.regressions.length > feedback.improvements.length) {
      intensity += 0.15;
    }
    
    // Apply aggressiveness factor
    if (options.aggressiveness) {
      intensity *= (1 + options.aggressiveness * 0.5);
    }
    
    return Math.max(0.1, Math.min(0.8, intensity));
  }

  /**
   * Analyze performance gaps to identify improvement opportunities
   */
  private analyzePerformanceGaps(performance: any) {
    const gaps: Record<string, number> = {};
    
    // Define optimal thresholds
    const thresholds = {
      successRate: 0.9,
      codeQualityScore: 0.85,
      userSatisfactionRating: 0.85,
      adaptationSpeed: 0.8,
      errorRecoveryRate: 0.85,
      computationalEfficiency: 0.8,
      resourceUtilization: 0.75,
      testCoverage: 0.9,
      maintainabilityScore: 0.8,
      communicationEffectiveness: 0.8,
    };
    
    // Calculate gaps
    for (const [metric, threshold] of Object.entries(thresholds)) {
      const currentValue = performance[metric] ?? 0.5;
      gaps[metric] = Math.max(0, threshold - currentValue);
    }
    
    return gaps;
  }

  /**
   * Identify specific optimization targets
   */
  private identifyOptimizationTargets(
    dna: CodeDNA,
    feedback: PerformanceFeedback
  ): Array<{
    area: string;
    targetGenes: (keyof GeneticMarkers)[];
    priority: number;
    strategy: string;
  }> {
    const targets: Array<{
      area: string;
      targetGenes: (keyof GeneticMarkers)[];
      priority: number;
      strategy: string;
    }> = [];
    
    // Speed optimization
    if (dna.performance.responseLatency > 2000 || feedback.regressions.includes('speed')) {
      targets.push({
        area: 'speed',
        targetGenes: ['resourceEfficiency', 'pragmatism', 'complexity'],
        priority: 0.9,
        strategy: 'reduce_complexity_increase_efficiency',
      });
    }
    
    // Quality optimization
    if (dna.performance.codeQualityScore < 0.8 || feedback.regressions.includes('quality')) {
      targets.push({
        area: 'quality',
        targetGenes: ['thoroughness', 'patternRecognition', 'complexity'],
        priority: 0.85,
        strategy: 'increase_thoroughness_and_patterns',
      });
    }
    
    // Reliability optimization
    if (dna.performance.errorRecoveryRate < 0.7 || feedback.regressions.includes('reliability')) {
      targets.push({
        area: 'reliability',
        targetGenes: ['stability', 'errorRecovery', 'thoroughness'],
        priority: 0.8,
        strategy: 'enhance_stability_and_recovery',
      });
    }
    
    // Success rate optimization
    if (dna.performance.successRate < 0.8 || feedback.outcome === 'failure') {
      targets.push({
        area: 'success',
        targetGenes: ['successRate', 'persistence', 'adaptability'],
        priority: 0.95,
        strategy: 'boost_success_factors',
      });
    }
    
    // Efficiency optimization
    if (dna.performance.resourceUtilization > 0.8 || feedback.regressions.includes('efficiency')) {
      targets.push({
        area: 'efficiency',
        targetGenes: ['resourceEfficiency', 'pragmatism'],
        priority: 0.7,
        strategy: 'optimize_resource_usage',
      });
    }
    
    // Communication optimization (if team integration is poor)
    if (dna.performance.teamIntegration < 0.7) {
      targets.push({
        area: 'communication',
        targetGenes: ['communicationClarity', 'empathy', 'collaborationAffinity'],
        priority: 0.6,
        strategy: 'improve_team_integration',
      });
    }
    
    // Sort by priority
    return targets.sort((a, b) => b.priority - a.priority);
  }

  /**
   * Generate mutations for specific optimization targets
   */
  private async generateTargetSpecificMutations(
    dna: CodeDNA,
    target: { area: string; targetGenes: (keyof GeneticMarkers)[]; strategy: string },
    intensity: number,
    options: OptimizationMutationOptions
  ): Promise<Mutation[]> {
    const mutations: Mutation[] = [];
    
    for (const gene of target.targetGenes) {
      const mutation = this.createOptimizationMutation(dna, gene, target, intensity, options);
      if (mutation) {
        mutations.push(mutation);
      }
    }
    
    return mutations;
  }

  /**
   * Create optimization mutation for specific gene
   */
  private createOptimizationMutation(
    dna: CodeDNA,
    gene: keyof GeneticMarkers,
    target: { area: string; strategy: string },
    intensity: number,
    options: OptimizationMutationOptions
  ): Mutation | null {
    const currentValue = dna.genetics[gene];
    let targetValue = currentValue;
    
    // Apply optimization strategy
    switch (target.strategy) {
      case 'reduce_complexity_increase_efficiency':
        if (gene === 'complexity') {
          targetValue = Math.max(0.2, currentValue - intensity * 0.3);
        } else if (gene === 'resourceEfficiency' || gene === 'pragmatism') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.4);
        }
        break;
        
      case 'increase_thoroughness_and_patterns':
        if (gene === 'thoroughness' || gene === 'patternRecognition') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.3);
        } else if (gene === 'complexity') {
          // Slightly increase complexity for better pattern recognition
          targetValue = Math.min(0.8, currentValue + intensity * 0.2);
        }
        break;
        
      case 'enhance_stability_and_recovery':
        if (gene === 'stability' || gene === 'errorRecovery' || gene === 'thoroughness') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.35);
        }
        break;
        
      case 'boost_success_factors':
        if (gene === 'successRate') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.4);
        } else if (gene === 'persistence' || gene === 'adaptability') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.3);
        }
        break;
        
      case 'optimize_resource_usage':
        if (gene === 'resourceEfficiency') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.4);
        } else if (gene === 'pragmatism') {
          targetValue = Math.min(1.0, currentValue + intensity * 0.3);
        }
        break;
        
      case 'improve_team_integration':
        targetValue = Math.min(1.0, currentValue + intensity * 0.3);
        break;
        
      default:
        // Generic improvement
        targetValue = Math.min(1.0, currentValue + intensity * 0.25);
    }
    
    // Only create mutation if there's meaningful change
    if (Math.abs(targetValue - currentValue) < 0.05) {
      return null;
    }
    
    const confidence = this.calculateOptimizationConfidence(dna, gene, targetValue, target.area);
    
    return this.createMutation(
      gene,
      currentValue,
      targetValue,
      {
        type: 'performance_decline',
        details: `Optimizing ${target.area} through ${gene} adjustment`,
      },
      {
        confidence,
        ...options,
      }
    );
  }

  /**
   * Calculate confidence for optimization mutation
   */
  private calculateOptimizationConfidence(
    dna: CodeDNA,
    gene: keyof GeneticMarkers,
    targetValue: number,
    optimizationArea: string
  ): number {
    let confidence = this.calculateMutationConfidence(dna, gene, targetValue - dna.genetics[gene]);
    
    // Boost confidence for high-impact optimizations
    if (optimizationArea === 'success' && gene === 'successRate') {
      confidence += 0.1;
    }
    
    if (optimizationArea === 'speed' && gene === 'resourceEfficiency') {
      confidence += 0.1;
    }
    
    if (optimizationArea === 'quality' && gene === 'thoroughness') {
      confidence += 0.1;
    }
    
    // Reduce confidence for risky optimizations
    if (gene === 'complexity' && targetValue > 0.8) {
      confidence *= 0.8; // High complexity can be risky
    }
    
    if (gene === 'riskTolerance' && targetValue > 0.8) {
      confidence *= 0.7; // High risk tolerance can be dangerous
    }
    
    return Math.max(0.2, Math.min(0.9, confidence));
  }
}

export default OptimizationMutator;