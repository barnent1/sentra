from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import text, and_
from typing import List, Optional
from uuid import UUID
import logging

from core.database import get_db
from core.auth import verify_token
from db.models import Task, Project, Agent, Event

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/tasks", tags=["tasks"])

# Pydantic models
from pydantic import BaseModel

class TaskCreate(BaseModel):
    project_name: str  # Will find or create project
    title: str
    spec: str
    priority: Optional[int] = 3  # 1=high, 5=low
    assigned_agent_role: Optional[str] = None  # Role like 'dev', 'analyst', etc.

class TaskResponse(BaseModel):
    id: str
    project_id: str
    project_name: str
    title: str
    spec: str
    status: str
    assigned_agent: Optional[str] = None
    assigned_agent_name: Optional[str] = None
    priority: int
    metadata: dict
    created_at: str
    updated_at: str

@router.post("", response_model=TaskResponse)
async def create_task(
    task_req: TaskCreate,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Create a new task."""
    try:
        # Find or create project
        project = db.query(Project).filter(Project.name == task_req.project_name).first()
        if not project:
            project = Project(
                name=task_req.project_name,
                description=f"Auto-created for task: {task_req.title}"
            )
            db.add(project)
            db.flush()
        
        # Find agent if role specified
        assigned_agent_id = None
        assigned_agent_name = None
        
        if task_req.assigned_agent_role:
            agent = db.query(Agent).filter(
                and_(
                    Agent.role == task_req.assigned_agent_role,
                    Agent.active == True
                )
            ).first()
            
            if agent:
                assigned_agent_id = agent.id
                assigned_agent_name = agent.name
        
        # Create task
        task = Task(
            project_id=project.id,
            title=task_req.title,
            spec=task_req.spec,
            priority=task_req.priority or 3,
            assigned_agent=assigned_agent_id,
            status="queued"
        )
        db.add(task)
        db.flush()
        
        # Create event
        event = Event(
            project_id=project.id,
            task_id=task.id,
            agent_id=assigned_agent_id,
            event_type="task_created",
            event_data={
                "title": task_req.title,
                "priority": task_req.priority or 3,
                "assigned_agent": assigned_agent_name
            }
        )
        db.add(event)
        db.commit()
        
        logger.info(f"Created task: {task_req.title}")
        
        return TaskResponse(
            id=str(task.id),
            project_id=str(project.id),
            project_name=project.name,
            title=task.title,
            spec=task.spec,
            status=task.status,
            assigned_agent=str(assigned_agent_id) if assigned_agent_id else None,
            assigned_agent_name=assigned_agent_name,
            priority=task.priority,
            metadata=task.task_metadata or {},
            created_at=task.created_at.isoformat(),
            updated_at=task.updated_at.isoformat()
        )
        
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create task: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create task"
        )

@router.get("", response_model=List[TaskResponse])
async def list_tasks(
    project_name: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 50,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """List tasks with optional filtering."""
    try:
        query = db.query(Task, Project.name, Agent.name).join(
            Project, Task.project_id == Project.id
        ).outerjoin(
            Agent, Task.assigned_agent == Agent.id
        )
        
        if project_name:
            query = query.filter(Project.name == project_name)
        
        if status:
            query = query.filter(Task.status == status)
        
        results = query.order_by(
            Task.priority.asc(), 
            Task.created_at.desc()
        ).limit(limit).all()
        
        tasks = []
        for task, project_name, agent_name in results:
            tasks.append(TaskResponse(
                id=str(task.id),
                project_id=str(task.project_id),
                project_name=project_name,
                title=task.title,
                spec=task.spec,
                status=task.status,
                assigned_agent=str(task.assigned_agent) if task.assigned_agent else None,
                assigned_agent_name=agent_name,
                priority=task.priority,
                metadata=task.task_metadata or {},
                created_at=task.created_at.isoformat(),
                updated_at=task.updated_at.isoformat()
            ))
        
        return tasks
        
    except Exception as e:
        logger.error(f"Failed to list tasks: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve tasks"
        )