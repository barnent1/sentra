from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List, Optional
from uuid import UUID
import logging

from core.database import get_db
from core.auth import verify_token
from db.models import Agent, Task, SubAgent, Project

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/agents", tags=["agents"])

# Pydantic models
from pydantic import BaseModel

class AgentCreate(BaseModel):
    name: str
    role: str  # analyst, pm, dev, qa, uiux, orchestrator
    prompt: str
    config: Optional[dict] = {}

class AgentResponse(BaseModel):
    id: str
    name: str
    role: str
    prompt: str
    config: dict
    active: bool
    created_at: str
    updated_at: str

class SubAgentSpawnRequest(BaseModel):
    task_id: str
    machine_id: str
    tmux_target: str
    context_summary: Optional[str] = None

class SubAgentResponse(BaseModel):
    id: str
    agent_id: str
    task_id: str
    machine_id: str
    tmux_target: str
    status: str
    context_summary: Optional[str]
    created_at: str
    last_seen: str

# Default agent personas
DEFAULT_AGENTS = [
    {
        "name": "Technical Analyst",
        "role": "analyst",
        "prompt": """You are a Technical Analyst agent specializing in code analysis, architecture review, and technical documentation. Your role is to:

1. Analyze code quality, structure, and adherence to best practices
2. Review system architecture and identify potential improvements
3. Create technical documentation and specifications
4. Identify security vulnerabilities and performance issues
5. Provide technical insights for decision-making

Work methodically, document findings clearly, and communicate technical concepts effectively to both technical and non-technical stakeholders.""",
        "config": {
            "tools": ["code_analysis", "documentation", "architecture_review"],
            "memory_focus": ["technical_decisions", "code_patterns", "architecture_notes"],
            "priority": "accuracy_over_speed"
        }
    },
    {
        "name": "Project Manager",
        "role": "pm",
        "prompt": """You are a Project Manager agent focused on coordination, planning, and ensuring project success. Your responsibilities include:

1. Breaking down complex tasks into manageable sub-tasks
2. Coordinating between different agents and team members
3. Tracking progress and identifying blockers
4. Managing priorities and resource allocation
5. Facilitating communication and decision-making
6. Ensuring deliverables meet requirements and deadlines

Maintain clear project oversight, proactively identify risks, and keep all stakeholders aligned on goals and progress.""",
        "config": {
            "tools": ["task_management", "coordination", "progress_tracking"],
            "memory_focus": ["project_milestones", "team_decisions", "blockers"],
            "priority": "coordination_over_implementation"
        }
    },
    {
        "name": "Software Developer",
        "role": "dev",
        "prompt": """You are a Software Developer agent skilled in writing high-quality code and implementing solutions. Your focus areas are:

1. Writing clean, maintainable, and well-tested code
2. Implementing features according to specifications
3. Debugging and fixing issues efficiently
4. Following coding standards and best practices
5. Optimizing performance and ensuring scalability
6. Integrating with existing systems and APIs

Always prioritize code quality, write comprehensive tests, and document your implementations clearly.""",
        "config": {
            "tools": ["code_implementation", "testing", "debugging"],
            "memory_focus": ["implementation_decisions", "bug_fixes", "code_patterns"],
            "priority": "quality_over_speed"
        }
    },
    {
        "name": "QA Engineer",
        "role": "qa",
        "prompt": """You are a QA Engineer agent dedicated to ensuring quality and reliability. Your responsibilities include:

1. Creating comprehensive test plans and test cases
2. Performing manual and automated testing
3. Identifying bugs and quality issues
4. Validating requirements and user acceptance criteria
5. Ensuring compatibility across different environments
6. Monitoring system performance and reliability

Be thorough in testing, document findings clearly, and advocate for quality standards throughout the development process.""",
        "config": {
            "tools": ["testing", "quality_assurance", "bug_reporting"],
            "memory_focus": ["test_results", "bug_reports", "quality_metrics"],
            "priority": "thoroughness_over_speed"
        }
    },
    {
        "name": "UX/UI Designer",
        "role": "uiux",
        "prompt": """You are a UX/UI Designer agent focused on creating exceptional user experiences. Your expertise includes:

1. Designing intuitive and user-friendly interfaces
2. Creating wireframes, mockups, and prototypes
3. Conducting user research and usability testing
4. Ensuring accessibility and inclusive design
5. Maintaining design consistency and style guides
6. Collaborating with developers on implementation

Always prioritize user needs, create designs that are both beautiful and functional, and ensure the end result delights users.""",
        "config": {
            "tools": ["design", "prototyping", "user_research"],
            "memory_focus": ["user_feedback", "design_decisions", "ui_patterns"],
            "priority": "user_experience_over_features"
        }
    },
    {
        "name": "Master Orchestrator",
        "role": "orchestrator",
        "prompt": """You are the Master Orchestrator agent responsible for high-level coordination and system oversight. Your role encompasses:

1. Coordinating complex multi-agent workflows
2. Making strategic decisions about task allocation
3. Monitoring overall system health and performance
4. Resolving conflicts between agents and priorities
5. Ensuring project goals are met efficiently
6. Managing escalations and critical decisions

Think strategically, balance competing priorities, and ensure the entire system works cohesively toward project success.""",
        "config": {
            "tools": ["orchestration", "decision_making", "system_monitoring"],
            "memory_focus": ["strategic_decisions", "system_patterns", "workflow_optimizations"],
            "priority": "system_optimization_over_individual_tasks"
        }
    }
]

@router.get("", response_model=List[AgentResponse])
async def list_agents(
    active_only: bool = True,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """List all available agents."""
    try:
        query = db.query(Agent)
        if active_only:
            query = query.filter(Agent.active == True)
        
        agents = query.order_by(Agent.name).all()
        
        return [
            AgentResponse(
                id=str(agent.id),
                name=agent.name,
                role=agent.role,
                prompt=agent.prompt,
                config=agent.config,
                active=agent.active,
                created_at=agent.created_at.isoformat(),
                updated_at=agent.updated_at.isoformat()
            )
            for agent in agents
        ]
        
    except Exception as e:
        logger.error(f"Failed to list agents: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve agents"
        )

@router.post("", response_model=AgentResponse)
async def create_agent(
    agent_req: AgentCreate,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Create a new agent."""
    try:
        agent = Agent(
            name=agent_req.name,
            role=agent_req.role,
            prompt=agent_req.prompt,
            config=agent_req.config or {}
        )
        db.add(agent)
        db.commit()
        
        logger.info(f"Created agent: {agent_req.name} ({agent_req.role})")
        
        return AgentResponse(
            id=str(agent.id),
            name=agent.name,
            role=agent.role,
            prompt=agent.prompt,
            config=agent.config,
            active=agent.active,
            created_at=agent.created_at.isoformat(),
            updated_at=agent.updated_at.isoformat()
        )
        
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create agent: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create agent"
        )

@router.post("/seed")
async def seed_default_agents(
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Seed database with default agent personas."""
    try:
        created_count = 0
        
        for agent_data in DEFAULT_AGENTS:
            # Check if agent already exists
            existing = db.query(Agent).filter(Agent.name == agent_data["name"]).first()
            if existing:
                logger.info(f"Agent {agent_data['name']} already exists, skipping")
                continue
            
            agent = Agent(
                name=agent_data["name"],
                role=agent_data["role"],
                prompt=agent_data["prompt"],
                config=agent_data["config"]
            )
            db.add(agent)
            created_count += 1
        
        db.commit()
        
        logger.info(f"Seeded {created_count} default agents")
        return {"message": f"Created {created_count} default agents"}
        
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to seed agents: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to seed default agents"
        )

@router.post("/spawn", response_model=SubAgentResponse)
async def spawn_subagent(
    spawn_req: SubAgentSpawnRequest,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Spawn a subagent for a specific task."""
    try:
        # Validate task exists and get assigned agent
        task = db.query(Task).filter(Task.id == UUID(spawn_req.task_id)).first()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        if not task.assigned_agent:
            raise HTTPException(status_code=400, detail="Task must have an assigned agent")
        
        # Create subagent record
        subagent = SubAgent(
            agent_id=task.assigned_agent,
            task_id=UUID(spawn_req.task_id),
            machine_id=spawn_req.machine_id,
            tmux_target=spawn_req.tmux_target,
            context_summary=spawn_req.context_summary
        )
        db.add(subagent)
        db.commit()
        
        logger.info(f"Spawned subagent {subagent.id} for task {spawn_req.task_id}")
        
        return SubAgentResponse(
            id=str(subagent.id),
            agent_id=str(subagent.agent_id),
            task_id=str(subagent.task_id),
            machine_id=subagent.machine_id,
            tmux_target=subagent.tmux_target,
            status=subagent.status,
            context_summary=subagent.context_summary,
            created_at=subagent.created_at.isoformat(),
            last_seen=subagent.last_seen.isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to spawn subagent: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to spawn subagent"
        )

@router.get("/subagents", response_model=List[SubAgentResponse])
async def list_subagents(
    machine_id: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """List active subagents."""
    try:
        query = db.query(SubAgent)
        
        if machine_id:
            query = query.filter(SubAgent.machine_id == machine_id)
        
        if status:
            query = query.filter(SubAgent.status == status)
        else:
            query = query.filter(SubAgent.status.in_(["active", "idle"]))
        
        subagents = query.order_by(SubAgent.last_seen.desc()).all()
        
        return [
            SubAgentResponse(
                id=str(subagent.id),
                agent_id=str(subagent.agent_id),
                task_id=str(subagent.task_id),
                machine_id=subagent.machine_id,
                tmux_target=subagent.tmux_target,
                status=subagent.status,
                context_summary=subagent.context_summary,
                created_at=subagent.created_at.isoformat(),
                last_seen=subagent.last_seen.isoformat()
            )
            for subagent in subagents
        ]
        
    except Exception as e:
        logger.error(f"Failed to list subagents: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve subagents"
        )

@router.put("/subagents/{subagent_id}/heartbeat")
async def subagent_heartbeat(
    subagent_id: UUID,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Update subagent last_seen timestamp."""
    try:
        subagent = db.query(SubAgent).filter(SubAgent.id == subagent_id).first()
        if not subagent:
            raise HTTPException(status_code=404, detail="Subagent not found")
        
        db.execute(text("""
            UPDATE subagents 
            SET last_seen = now(), status = 'active'
            WHERE id = :subagent_id
        """), {"subagent_id": subagent_id})
        
        db.commit()
        
        return {"ok": True, "last_seen": "updated"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update subagent heartbeat: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update heartbeat"
        )