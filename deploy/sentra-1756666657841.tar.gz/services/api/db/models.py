from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from pgvector.sqlalchemy import Vector
import uuid

from core.database import Base

class Project(Base):
    __tablename__ = "projects"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, unique=True, nullable=False)
    repo_url = Column(String)
    description = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # Relationships
    tasks = relationship("Task", back_populates="project", cascade="all, delete-orphan")
    approvals = relationship("Approval", back_populates="project", cascade="all, delete-orphan")
    events = relationship("Event", back_populates="project", cascade="all, delete-orphan")
    memory_items = relationship("MemoryItem", back_populates="project", cascade="all, delete-orphan")

class Agent(Base):
    __tablename__ = "agents"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False)
    role = Column(String, nullable=False)  # analyst, pm, dev, qa, uiux, orchestrator
    prompt = Column(Text, nullable=False)
    config = Column(JSON, default=dict)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # Relationships
    tasks = relationship("Task", back_populates="assigned_agent_rel")
    events = relationship("Event", back_populates="agent")
    subagents = relationship("SubAgent", back_populates="agent", cascade="all, delete-orphan")

class Task(Base):
    __tablename__ = "tasks"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    title = Column(String, nullable=False)
    spec = Column(Text, nullable=False)
    status = Column(String, nullable=False, default="queued")  # queued|running|waiting_approval|blocked|done|failed
    assigned_agent = Column(UUID(as_uuid=True), ForeignKey("agents.id"))
    parent_task_id = Column(UUID(as_uuid=True), ForeignKey("tasks.id"))
    priority = Column(Integer, default=1)  # 1=high, 5=low
    task_metadata = Column(JSON, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # Relationships
    project = relationship("Project", back_populates="tasks")
    assigned_agent_rel = relationship("Agent", back_populates="tasks")
    parent_task = relationship("Task", remote_side=[id])
    events = relationship("Event", back_populates="task", cascade="all, delete-orphan")
    memory_items = relationship("MemoryItem", back_populates="task", cascade="all, delete-orphan")
    subagents = relationship("SubAgent", back_populates="task", cascade="all, delete-orphan")

class Approval(Base):
    __tablename__ = "approvals"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    machine_id = Column(String, nullable=False)
    tmux_target = Column(String)
    command = Column(Text, nullable=False)
    risk_level = Column(String, default="medium")  # low|medium|high|critical
    status = Column(String, nullable=False, default="pending")  # pending|approved|rejected|expired|completed
    decision_reason = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    decided_at = Column(DateTime(timezone=True))
    expires_at = Column(DateTime(timezone=True), server_default=func.now() + func.interval('1 hour'))
    
    # Relationships
    project = relationship("Project", back_populates="approvals")
    events = relationship("Event", back_populates="approval", cascade="all, delete-orphan")

class Event(Base):
    __tablename__ = "events"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"))
    agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"))
    task_id = Column(UUID(as_uuid=True), ForeignKey("tasks.id"))
    approval_id = Column(UUID(as_uuid=True), ForeignKey("approvals.id"))
    event_type = Column(String, nullable=False)
    event_data = Column(JSON, default=dict)
    machine_id = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    project = relationship("Project", back_populates="events")
    agent = relationship("Agent", back_populates="events")
    task = relationship("Task", back_populates="events")
    approval = relationship("Approval", back_populates="events")

class MemoryItem(Base):
    __tablename__ = "memory_items"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    task_id = Column(UUID(as_uuid=True), ForeignKey("tasks.id"))
    kind = Column(String, nullable=False)  # doc, code, note, decision, log, artifact
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    embedding = Column(Vector(1536))  # text-embedding-3-small
    item_metadata = Column(JSON, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # Relationships
    project = relationship("Project", back_populates="memory_items")
    task = relationship("Task", back_populates="memory_items")

class SubAgent(Base):
    __tablename__ = "subagents"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id = Column(UUID(as_uuid=True), ForeignKey("agents.id"), nullable=False)
    task_id = Column(UUID(as_uuid=True), ForeignKey("tasks.id"), nullable=False)
    machine_id = Column(String, nullable=False)
    tmux_target = Column(String, nullable=False)
    status = Column(String, default="active")  # active|idle|terminated
    context_summary = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_seen = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    agent = relationship("Agent", back_populates="subagents")
    task = relationship("Task", back_populates="subagents")