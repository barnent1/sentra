from sqlalchemy import create_engine, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool
from .config import settings
import logging

logger = logging.getLogger(__name__)

# Create engine with connection pooling
engine = create_engine(
    settings.database_url,
    poolclass=NullPool if settings.debug else None,
    echo=settings.debug
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    """Database dependency for FastAPI."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

async def init_db():
    """Initialize database with schema and seeds if needed."""
    try:
        # Import models to ensure they're registered
        from db.models import Base
        
        with engine.begin() as conn:
            # Create all tables
            Base.metadata.create_all(engine)
            
            # Test pgvector extension
            result = conn.execute(text("SELECT EXISTS(SELECT 1 FROM pg_extension WHERE extname = 'vector')"))
            has_vector = result.scalar()
            
            if not has_vector:
                logger.warning("pgvector extension not found - this may cause issues with memory search")
            else:
                logger.info("pgvector extension found - creating memory search function")
                
                # Create the memory search function
                search_function_sql = text("""
                CREATE OR REPLACE FUNCTION search_memory(
                    p_project_id UUID,
                    p_query_embedding vector(1536),
                    p_kind TEXT DEFAULT NULL,
                    p_limit INTEGER DEFAULT 10
                )
                RETURNS TABLE(
                    id UUID,
                    kind TEXT,
                    title TEXT,
                    content TEXT,
                    item_metadata JSON,
                    similarity FLOAT,
                    created_at TIMESTAMP
                ) AS $$
                BEGIN
                    RETURN QUERY
                    SELECT 
                        mi.id,
                        mi.kind,
                        mi.title,
                        mi.content,
                        mi.item_metadata,
                        1 - (mi.embedding <=> p_query_embedding) AS similarity,
                        mi.created_at
                    FROM memory_items mi
                    WHERE mi.project_id = p_project_id
                    AND (p_kind IS NULL OR mi.kind = p_kind)
                    ORDER BY mi.embedding <=> p_query_embedding
                    LIMIT p_limit;
                END;
                $$ LANGUAGE plpgsql;
                """)
                
                conn.execute(search_function_sql)
                logger.info("Database initialized successfully with pgvector support and search function")
                
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        raise

def test_connection():
    """Test database connectivity."""
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception as e:
        logger.error(f"Database connection test failed: {e}")
        return False