import requests
import os
import logging
from typing import Optional
from ..core.config import settings

logger = logging.getLogger(__name__)

class PushoverClient:
    def __init__(self):
        self.app_token = settings.pushover_app_token
        self.user_key = settings.pushover_user_key
        self.api_url = "https://api.pushover.net/1/messages.json"
        
    def send_push(
        self, 
        title: str, 
        message: str, 
        url: Optional[str] = None, 
        url_title: Optional[str] = None, 
        attachment_path: Optional[str] = None, 
        priority: int = 1
    ) -> bool:
        """Send a push notification via Pushover.
        
        Args:
            title: Notification title
            message: Notification message
            url: Optional URL to attach
            url_title: Optional title for the URL
            attachment_path: Optional path to audio file to attach
            priority: Priority level (-2 to 2, 1=high)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            data = {
                "token": self.app_token,
                "user": self.user_key,
                "title": title,
                "message": message,
                "priority": str(priority),
            }
            
            if url:
                data["url"] = url
            if url_title:
                data["url_title"] = url_title
                
            files = None
            if attachment_path and os.path.exists(attachment_path):
                try:
                    files = {"attachment": open(attachment_path, "rb")}
                except Exception as e:
                    logger.warning(f"Could not attach file {attachment_path}: {e}")
            
            response = requests.post(self.api_url, data=data, files=files, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            if result.get("status") == 1:
                logger.info(f"Push notification sent successfully: {title}")
                return True
            else:
                logger.error(f"Pushover API error: {result}")
                return False
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to send push notification: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error sending push notification: {e}")
            return False
        finally:
            # Clean up file handle
            if files and "attachment" in files:
                try:
                    files["attachment"].close()
                except:
                    pass
    
    def test_connection(self) -> bool:
        """Test Pushover API connectivity with a simple message."""
        return self.send_push(
            "Sentra Test", 
            "Pushover integration is working correctly!", 
            priority=0
        )

# Global instance
pushover = PushoverClient()