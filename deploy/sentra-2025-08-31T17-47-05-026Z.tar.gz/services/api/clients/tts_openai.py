import requests
import json
import tempfile
import logging
from typing import Optional
from ..core.config import settings

logger = logging.getLogger(__name__)

class OpenAITTSClient:
    def __init__(self):
        self.api_key = settings.openai_api_key
        self.api_url = "https://api.openai.com/v1/audio/speech"
        self.temp_dir = settings.temp_audio_dir
        
    def speak_to_mp3(self, text: str, voice: str = "alloy", model: str = "tts-1") -> Optional[str]:
        """Convert text to speech using OpenAI TTS API.
        
        Args:
            text: Text to convert to speech
            voice: Voice to use (alloy, echo, fable, onyx, nova, shimmer)
            model: Model to use (tts-1 or tts-1-hd)
            
        Returns:
            Path to generated MP3 file, or None if failed
        """
        try:
            # Create request body
            body = {
                "model": model,
                "voice": voice,
                "input": text,
                "response_format": "mp3"
            }
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            # Make API request
            response = requests.post(
                self.api_url,
                headers=headers,
                data=json.dumps(body),
                timeout=30
            )
            response.raise_for_status()
            
            # Save audio to temporary file
            with tempfile.NamedTemporaryFile(
                delete=False, 
                suffix=".mp3", 
                dir=self.temp_dir
            ) as f:
                f.write(response.content)
                temp_path = f.name
            
            logger.info(f"Generated TTS audio: {len(text)} characters -> {temp_path}")
            return temp_path
            
        except requests.exceptions.RequestException as e:
            logger.error(f"OpenAI TTS API request failed: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error in TTS generation: {e}")
            return None
    
    def cleanup_temp_file(self, file_path: str) -> bool:
        """Clean up a temporary audio file.
        
        Args:
            file_path: Path to file to delete
            
        Returns:
            True if successful, False otherwise
        """
        try:
            import os
            if os.path.exists(file_path):
                os.remove(file_path)
                logger.debug(f"Cleaned up temp file: {file_path}")
                return True
            return False
        except Exception as e:
            logger.error(f"Failed to cleanup temp file {file_path}: {e}")
            return False
    
    def test_connection(self) -> bool:
        """Test OpenAI TTS API connectivity."""
        test_file = self.speak_to_mp3("Sentra TTS test")
        if test_file:
            self.cleanup_temp_file(test_file)
            return True
        return False

# Global instance
tts = OpenAITTSClient()