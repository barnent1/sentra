import json
import logging
import asyncio
from typing import Dict, Any, Optional, List
from uuid import uuid4, UUID
from fastapi import WebSocket, WebSocketDisconnect
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text

from ..core.database import engine
from ..db.models import Project, Task, Agent, MemoryItem, SubAgent, Event
from ..clients.pushover import pushover
from ..clients.tts_openai import tts
from ..routes.memory import get_embedding
from ..core.config import settings

logger = logging.getLogger(__name__)

# Database session for MCP
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class MCPServer:
    """Model Context Protocol server implementation."""
    
    def __init__(self):
        self.connections: Dict[str, WebSocket] = {}
        self.tools = {
            "notify.push": self._notify_push,
            "approve.queue": self._approve_queue,
            "memory.store": self._memory_store,
            "memory.search": self._memory_search,
            "task.create": self._task_create,
            "task.update": self._task_update,
            "spawn.subagent": self._spawn_subagent,
            "tmux.manage": self._tmux_manage,
        }
    
    async def connect(self, websocket: WebSocket, client_id: str = None):
        """Accept a new WebSocket connection."""
        await websocket.accept()
        if not client_id:
            client_id = str(uuid4())
        
        self.connections[client_id] = websocket
        logger.info(f"MCP client connected: {client_id}")
        
        # Send initial handshake
        await self._send_message(websocket, {
            "jsonrpc": "2.0",
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {
                        "listChanged": False
                    }
                },
                "serverInfo": {
                    "name": "sentra-mcp",
                    "version": "1.0.0"
                }
            }
        })
        
        return client_id
    
    async def disconnect(self, client_id: str):
        """Remove a client connection."""
        if client_id in self.connections:
            del self.connections[client_id]
            logger.info(f"MCP client disconnected: {client_id}")
    
    async def handle_message(self, websocket: WebSocket, message: str, client_id: str):
        """Handle incoming MCP message."""
        try:
            data = json.loads(message)
            method = data.get("method")
            params = data.get("params", {})
            message_id = data.get("id")
            
            if method == "tools/list":
                await self._handle_tools_list(websocket, message_id)
            elif method == "tools/call":
                await self._handle_tool_call(websocket, params, message_id)
            else:
                await self._send_error(websocket, message_id, -32601, f"Method not found: {method}")
                
        except json.JSONDecodeError:
            await self._send_error(websocket, None, -32700, "Parse error")
        except Exception as e:
            logger.error(f"Error handling MCP message: {e}")
            await self._send_error(websocket, None, -32603, "Internal error")
    
    async def _handle_tools_list(self, websocket: WebSocket, message_id: str):
        """Handle tools/list request."""
        tools = [
            {
                "name": "notify.push",
                "description": "Send push notification with optional voice attachment",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "message": {"type": "string"},
                        "url": {"type": "string"},
                        "attachment": {"type": "string", "description": "Text to convert to voice"}
                    },
                    "required": ["title", "message"]
                }
            },
            {
                "name": "approve.queue",
                "description": "Queue a command for approval",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "project": {"type": "string"},
                        "command": {"type": "string"},
                        "machine_id": {"type": "string"},
                        "tmux_target": {"type": "string"},
                        "risk_level": {"type": "string", "enum": ["low", "medium", "high", "critical"]}
                    },
                    "required": ["project", "command", "machine_id"]
                }
            },
            {
                "name": "memory.store",
                "description": "Store content in vector memory",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string"},
                        "kind": {"type": "string", "enum": ["doc", "code", "note", "decision", "log", "artifact"]},
                        "title": {"type": "string"},
                        "content": {"type": "string"},
                        "task_id": {"type": "string"},
                        "metadata": {"type": "object"}
                    },
                    "required": ["project_id", "kind", "title", "content"]
                }
            },
            {
                "name": "memory.search",
                "description": "Search vector memory by semantic similarity",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string"},
                        "query": {"type": "string"},
                        "kind": {"type": "string"},
                        "limit": {"type": "integer", "minimum": 1, "maximum": 50}
                    },
                    "required": ["project_id", "query"]
                }
            },
            {
                "name": "task.create",
                "description": "Create a new task",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string"},
                        "title": {"type": "string"},
                        "spec": {"type": "string"},
                        "role": {"type": "string", "enum": ["analyst", "pm", "dev", "qa", "uiux"]},
                        "priority": {"type": "integer", "minimum": 1, "maximum": 5}
                    },
                    "required": ["project_id", "title", "spec", "role"]
                }
            },
            {
                "name": "task.update",
                "description": "Update an existing task",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "task_id": {"type": "string"},
                        "status": {"type": "string", "enum": ["queued", "running", "waiting_approval", "blocked", "done", "failed"]},
                        "notes": {"type": "string"}
                    },
                    "required": ["task_id"]
                }
            },
            {
                "name": "spawn.subagent",
                "description": "Spawn a new Claude Code subagent for a task",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "role": {"type": "string", "enum": ["analyst", "pm", "dev", "qa", "uiux"]},
                        "task_id": {"type": "string"},
                        "machine_id": {"type": "string"}
                    },
                    "required": ["role", "task_id", "machine_id"]
                }
            },
            {
                "name": "tmux.manage",
                "description": "Manage tmux sessions for subagents",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["new_window", "split_pane", "send_keys"]},
                        "session": {"type": "string"},
                        "target": {"type": "string"},
                        "command": {"type": "string"}
                    },
                    "required": ["action"]
                }
            }
        ]
        
        await self._send_message(websocket, {
            "jsonrpc": "2.0",
            "id": message_id,
            "result": {"tools": tools}
        })
    
    async def _handle_tool_call(self, websocket: WebSocket, params: dict, message_id: str):
        """Handle tools/call request."""
        try:
            tool_name = params.get("name")
            arguments = params.get("arguments", {})
            
            if tool_name not in self.tools:
                await self._send_error(websocket, message_id, -32602, f"Unknown tool: {tool_name}")
                return
            
            # Execute tool
            result = await self.tools[tool_name](arguments)
            
            await self._send_message(websocket, {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(result, indent=2)
                        }
                    ]
                }
            })
            
        except Exception as e:
            logger.error(f"Tool call failed: {e}")
            await self._send_error(websocket, message_id, -32603, f"Tool execution failed: {str(e)}")
    
    async def _send_message(self, websocket: WebSocket, data: dict):
        """Send JSON message to client."""
        message = json.dumps(data)
        await websocket.send_text(message)
    
    async def _send_error(self, websocket: WebSocket, message_id: str, code: int, message: str):
        """Send error response."""
        await self._send_message(websocket, {
            "jsonrpc": "2.0",
            "id": message_id,
            "error": {
                "code": code,
                "message": message
            }
        })
    
    # Tool implementations
    async def _notify_push(self, args: dict) -> dict:
        """Send push notification."""
        title = args["title"]
        message = args["message"]
        url = args.get("url")
        attachment_text = args.get("attachment")
        
        voice_file = None
        if attachment_text:
            voice_file = tts.speak_to_mp3(attachment_text)
        
        success = pushover.send_push(
            title=title,
            message=message,
            url=url,
            attachment_path=voice_file,
            priority=1
        )
        
        if voice_file:
            tts.cleanup_temp_file(voice_file)
        
        return {"success": success}
    
    async def _approve_queue(self, args: dict) -> dict:
        """Queue command for approval."""
        with SessionLocal() as db:
            # Find or create project
            project = db.query(Project).filter(Project.name == args["project"]).first()
            if not project:
                project = Project(name=args["project"])
                db.add(project)
                db.flush()
            
            # Create approval (similar to REST endpoint logic)
            from ..db.models import Approval
            approval = Approval(
                project_id=project.id,
                machine_id=args["machine_id"],
                tmux_target=args.get("tmux_target"),
                command=args["command"],
                risk_level=args.get("risk_level", "medium")
            )
            db.add(approval)
            db.commit()
            
            return {"approval_id": str(approval.id), "status": "queued"}
    
    async def _memory_store(self, args: dict) -> dict:
        """Store content in memory."""
        with SessionLocal() as db:
            # Generate embedding
            combined_text = f"{args['title']}\n\n{args['content']}"
            embedding = get_embedding(combined_text)
            
            memory_item = MemoryItem(
                project_id=UUID(args["project_id"]),
                task_id=UUID(args["task_id"]) if args.get("task_id") else None,
                kind=args["kind"],
                title=args["title"],
                content=args["content"],
                embedding=embedding,
                metadata=args.get("metadata", {})
            )
            db.add(memory_item)
            db.commit()
            
            return {"memory_id": str(memory_item.id), "status": "stored"}
    
    async def _memory_search(self, args: dict) -> dict:
        """Search memory by similarity."""
        with SessionLocal() as db:
            query_embedding = get_embedding(args["query"])
            
            query_sql = text("""
                SELECT * FROM search_memory(
                    :project_id, 
                    :query_embedding, 
                    :kind, 
                    :limit
                )
            """)
            
            result = db.execute(query_sql, {
                "project_id": UUID(args["project_id"]),
                "query_embedding": query_embedding,
                "kind": args.get("kind"),
                "limit": args.get("limit", 10)
            })
            
            items = []
            for row in result.fetchall():
                items.append({
                    "id": str(row.id),
                    "title": row.title,
                    "content": row.content,
                    "kind": row.kind,
                    "similarity": float(row.similarity),
                    "metadata": row.metadata
                })
            
            return {"results": items, "count": len(items)}
    
    async def _task_create(self, args: dict) -> dict:
        """Create a new task."""
        with SessionLocal() as db:
            # Find agent by role
            agent = db.query(Agent).filter(Agent.role == args["role"], Agent.active == True).first()
            
            task = Task(
                project_id=UUID(args["project_id"]),
                title=args["title"],
                spec=args["spec"],
                assigned_agent=agent.id if agent else None,
                priority=args.get("priority", 1)
            )
            db.add(task)
            db.commit()
            
            return {"task_id": str(task.id), "status": "created", "assigned_agent": agent.name if agent else None}
    
    async def _task_update(self, args: dict) -> dict:
        """Update an existing task."""
        with SessionLocal() as db:
            task = db.query(Task).filter(Task.id == UUID(args["task_id"])).first()
            if not task:
                raise ValueError("Task not found")
            
            if "status" in args:
                task.status = args["status"]
            
            if "notes" in args:
                # Store notes in metadata
                if not task.metadata:
                    task.metadata = {}
                task.metadata["notes"] = args["notes"]
            
            db.commit()
            
            return {"task_id": str(task.id), "status": task.status}
    
    async def _spawn_subagent(self, args: dict) -> dict:
        """Spawn a new subagent."""
        with SessionLocal() as db:
            # Find agent and task
            agent = db.query(Agent).filter(Agent.role == args["role"], Agent.active == True).first()
            task = db.query(Task).filter(Task.id == UUID(args["task_id"])).first()
            
            if not agent or not task:
                raise ValueError("Agent or task not found")
            
            # Generate tmux target
            tmux_target = f"sentra:{task.project.name}.{args['role']}"
            
            # Create subagent record
            subagent = SubAgent(
                agent_id=agent.id,
                task_id=task.id,
                machine_id=args["machine_id"],
                tmux_target=tmux_target,
                context_summary=f"Working on: {task.title}"
            )
            db.add(subagent)
            db.commit()
            
            # Return tmux command to spawn the subagent
            spawn_command = f'tmux new-window -t sentra -n {args["role"]} -c {task.project.repo_url or "."}'
            
            return {
                "subagent_id": str(subagent.id),
                "tmux_target": tmux_target,
                "spawn_command": spawn_command,
                "agent_prompt": agent.prompt
            }
    
    async def _tmux_manage(self, args: dict) -> dict:
        """Manage tmux sessions."""
        action = args["action"]
        
        # This would integrate with actual tmux commands
        # For now, return the command that should be executed
        commands = {
            "new_window": f'tmux new-window -t {args.get("session", "sentra")} -n {args.get("target", "new")}',
            "split_pane": f'tmux split-window -t {args.get("target", "sentra")}',
            "send_keys": f'tmux send-keys -t {args.get("target", "sentra")} "{args.get("command", "")}" C-m'
        }
        
        return {"command": commands.get(action, "unknown action"), "action": action}

# Global MCP server instance
mcp_server = MCPServer()