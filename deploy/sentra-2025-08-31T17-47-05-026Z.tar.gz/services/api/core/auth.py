from fastapi import HTTPException, Security, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from .config import settings
import logging

logger = logging.getLogger(__name__)

security = HTTPBearer()

def verify_token(credentials: HTTPAuthorizationCredentials = Security(security)) -> str:
    """Verify API token for authentication."""
    if credentials.credentials != settings.sentra_api_token:
        logger.warning(f"Invalid API token attempt")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return credentials.credentials

def verify_token_optional(credentials: HTTPAuthorizationCredentials = Security(security, auto_error=False)) -> bool:
    """Optional token verification - returns True if valid, False if missing/invalid."""
    if not credentials:
        return False
    return credentials.credentials == settings.sentra_api_token