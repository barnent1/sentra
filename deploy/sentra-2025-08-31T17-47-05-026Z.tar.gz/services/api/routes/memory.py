from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List, Optional
from uuid import UUID
import logging
import openai
from openai import OpenAI

from ..core.database import get_db
from ..core.auth import verify_token
from ..db.models import MemoryItem, Project
from ..core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/memory", tags=["memory"])

# Initialize OpenAI client
client = OpenAI(api_key=settings.openai_api_key)

# Pydantic models
from pydantic import BaseModel

class MemoryStoreRequest(BaseModel):
    project_id: str
    task_id: Optional[str] = None
    kind: str  # doc, code, note, decision, log, artifact
    title: str
    content: str
    metadata: Optional[dict] = {}

class MemorySearchRequest(BaseModel):
    project_id: str
    query: str
    kind: Optional[str] = None
    limit: Optional[int] = 10

class MemoryResponse(BaseModel):
    id: str
    project_id: str
    task_id: Optional[str]
    kind: str
    title: str
    content: str
    metadata: dict
    similarity: Optional[float] = None
    created_at: str
    updated_at: str

def get_embedding(text: str) -> List[float]:
    """Get embedding for text using OpenAI."""
    try:
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input=text,
            dimensions=1536
        )
        return response.data[0].embedding
    except Exception as e:
        logger.error(f"Failed to get embedding: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate embedding"
        )

@router.post("/store", response_model=MemoryResponse)
async def store_memory(
    memory_req: MemoryStoreRequest,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Store a new memory item with vector embedding."""
    try:
        # Validate project exists
        project = db.query(Project).filter(Project.id == UUID(memory_req.project_id)).first()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Generate embedding for the content
        combined_text = f"{memory_req.title}\n\n{memory_req.content}"
        embedding = get_embedding(combined_text)
        
        # Create memory item
        memory_item = MemoryItem(
            project_id=UUID(memory_req.project_id),
            task_id=UUID(memory_req.task_id) if memory_req.task_id else None,
            kind=memory_req.kind,
            title=memory_req.title,
            content=memory_req.content,
            embedding=embedding,
            metadata=memory_req.metadata or {}
        )
        db.add(memory_item)
        db.commit()
        
        logger.info(f"Stored memory item: {memory_req.kind} - {memory_req.title[:50]}...")
        
        return MemoryResponse(
            id=str(memory_item.id),
            project_id=str(memory_item.project_id),
            task_id=str(memory_item.task_id) if memory_item.task_id else None,
            kind=memory_item.kind,
            title=memory_item.title,
            content=memory_item.content,
            metadata=memory_item.metadata,
            created_at=memory_item.created_at.isoformat(),
            updated_at=memory_item.updated_at.isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to store memory: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to store memory item"
        )

@router.post("/search", response_model=List[MemoryResponse])
async def search_memory(
    search_req: MemorySearchRequest,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Search memory items by semantic similarity."""
    try:
        # Validate project exists
        project = db.query(Project).filter(Project.id == UUID(search_req.project_id)).first()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Generate embedding for query
        query_embedding = get_embedding(search_req.query)
        
        # Use the database function for vector search
        query_sql = text("""
            SELECT * FROM search_memory(
                :project_id, 
                :query_embedding, 
                :kind, 
                :limit
            )
        """)
        
        result = db.execute(query_sql, {
            "project_id": UUID(search_req.project_id),
            "query_embedding": query_embedding,
            "kind": search_req.kind,
            "limit": search_req.limit or settings.max_memory_results
        })
        
        items = []
        for row in result.fetchall():
            items.append(MemoryResponse(
                id=str(row.id),
                project_id=search_req.project_id,
                task_id=None,  # Not returned by search function
                kind=row.kind,
                title=row.title,
                content=row.content,
                metadata=row.metadata,
                similarity=float(row.similarity),
                created_at=row.created_at.isoformat(),
                updated_at=row.created_at.isoformat()  # Using created_at as fallback
            ))
        
        logger.info(f"Memory search returned {len(items)} results for: {search_req.query[:50]}...")
        return items
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to search memory: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search memory"
        )

@router.get("/kinds")
async def get_memory_kinds(
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Get all unique memory kinds for filtering."""
    try:
        result = db.execute(text("SELECT DISTINCT kind FROM memory_items ORDER BY kind"))
        kinds = [row[0] for row in result.fetchall()]
        
        return {"kinds": kinds}
        
    except Exception as e:
        logger.error(f"Failed to get memory kinds: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve memory kinds"
        )

@router.get("/{memory_id}", response_model=MemoryResponse)
async def get_memory_item(
    memory_id: UUID,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Get a specific memory item."""
    try:
        memory_item = db.query(MemoryItem).filter(MemoryItem.id == memory_id).first()
        if not memory_item:
            raise HTTPException(status_code=404, detail="Memory item not found")
        
        return MemoryResponse(
            id=str(memory_item.id),
            project_id=str(memory_item.project_id),
            task_id=str(memory_item.task_id) if memory_item.task_id else None,
            kind=memory_item.kind,
            title=memory_item.title,
            content=memory_item.content,
            metadata=memory_item.metadata,
            created_at=memory_item.created_at.isoformat(),
            updated_at=memory_item.updated_at.isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get memory item {memory_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve memory item"
        )