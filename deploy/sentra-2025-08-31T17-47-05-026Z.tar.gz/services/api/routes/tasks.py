from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
from datetime import datetime
import logging

from ..core.database import get_db
from ..core.auth import verify_token
from ..db.models import Task, Project, Agent, Event

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/tasks", tags=["tasks"])

# Pydantic models
from pydantic import BaseModel

class TaskCreate(BaseModel):
    project_id: str
    title: str
    spec: str
    assigned_agent_id: Optional[str] = None
    parent_task_id: Optional[str] = None
    priority: Optional[int] = 1
    metadata: Optional[dict] = {}

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    spec: Optional[str] = None
    status: Optional[str] = None
    assigned_agent_id: Optional[str] = None
    priority: Optional[int] = None
    metadata: Optional[dict] = None

class TaskResponse(BaseModel):
    id: str
    project_id: str
    title: str
    spec: str
    status: str
    assigned_agent_id: Optional[str]
    parent_task_id: Optional[str]
    priority: int
    metadata: dict
    created_at: datetime
    updated_at: datetime

@router.post("", response_model=TaskResponse)
async def create_task(
    task_req: TaskCreate,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Create a new task."""
    try:
        # Validate project exists
        project = db.query(Project).filter(Project.id == UUID(task_req.project_id)).first()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Validate agent exists if specified
        if task_req.assigned_agent_id:
            agent = db.query(Agent).filter(Agent.id == UUID(task_req.assigned_agent_id)).first()
            if not agent:
                raise HTTPException(status_code=404, detail="Agent not found")
        
        # Validate parent task exists if specified
        if task_req.parent_task_id:
            parent = db.query(Task).filter(Task.id == UUID(task_req.parent_task_id)).first()
            if not parent:
                raise HTTPException(status_code=404, detail="Parent task not found")
        
        # Create task
        task = Task(
            project_id=UUID(task_req.project_id),
            title=task_req.title,
            spec=task_req.spec,
            assigned_agent=UUID(task_req.assigned_agent_id) if task_req.assigned_agent_id else None,
            parent_task_id=UUID(task_req.parent_task_id) if task_req.parent_task_id else None,
            priority=task_req.priority,
            metadata=task_req.metadata or {}
        )
        db.add(task)
        db.flush()
        
        # Create event
        event = Event(
            project_id=task.project_id,
            task_id=task.id,
            agent_id=task.assigned_agent,
            event_type="task_created",
            event_data={
                "title": task.title,
                "status": task.status,
                "priority": task.priority
            }
        )
        db.add(event)
        db.commit()
        
        return TaskResponse(
            id=str(task.id),
            project_id=str(task.project_id),
            title=task.title,
            spec=task.spec,
            status=task.status,
            assigned_agent_id=str(task.assigned_agent) if task.assigned_agent else None,
            parent_task_id=str(task.parent_task_id) if task.parent_task_id else None,
            priority=task.priority,
            metadata=task.metadata,
            created_at=task.created_at,
            updated_at=task.updated_at
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create task: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create task"
        )

@router.patch("/{task_id}", response_model=TaskResponse)
async def update_task(
    task_id: UUID,
    task_update: TaskUpdate,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Update an existing task."""
    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        # Track what changed for events
        changes = {}
        
        # Update fields if provided
        if task_update.title is not None:
            changes["title"] = {"old": task.title, "new": task_update.title}
            task.title = task_update.title
        
        if task_update.spec is not None:
            task.spec = task_update.spec
        
        if task_update.status is not None:
            if task_update.status not in ["queued", "running", "waiting_approval", "blocked", "done", "failed"]:
                raise HTTPException(status_code=400, detail="Invalid status")
            changes["status"] = {"old": task.status, "new": task_update.status}
            task.status = task_update.status
        
        if task_update.assigned_agent_id is not None:
            if task_update.assigned_agent_id:
                agent = db.query(Agent).filter(Agent.id == UUID(task_update.assigned_agent_id)).first()
                if not agent:
                    raise HTTPException(status_code=404, detail="Agent not found")
            changes["assigned_agent"] = {
                "old": str(task.assigned_agent) if task.assigned_agent else None,
                "new": task_update.assigned_agent_id
            }
            task.assigned_agent = UUID(task_update.assigned_agent_id) if task_update.assigned_agent_id else None
        
        if task_update.priority is not None:
            changes["priority"] = {"old": task.priority, "new": task_update.priority}
            task.priority = task_update.priority
        
        if task_update.metadata is not None:
            task.metadata = {**(task.metadata or {}), **task_update.metadata}
        
        db.flush()
        
        # Create event if there were changes
        if changes:
            event = Event(
                project_id=task.project_id,
                task_id=task.id,
                agent_id=task.assigned_agent,
                event_type="task_updated",
                event_data={
                    "changes": changes,
                    "current_status": task.status
                }
            )
            db.add(event)
        
        db.commit()
        
        return TaskResponse(
            id=str(task.id),
            project_id=str(task.project_id),
            title=task.title,
            spec=task.spec,
            status=task.status,
            assigned_agent_id=str(task.assigned_agent) if task.assigned_agent else None,
            parent_task_id=str(task.parent_task_id) if task.parent_task_id else None,
            priority=task.priority,
            metadata=task.metadata,
            created_at=task.created_at,
            updated_at=task.updated_at
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to update task {task_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update task"
        )

@router.get("/{task_id}", response_model=TaskResponse)
async def get_task(
    task_id: UUID,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """Get a specific task."""
    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        return TaskResponse(
            id=str(task.id),
            project_id=str(task.project_id),
            title=task.title,
            spec=task.spec,
            status=task.status,
            assigned_agent_id=str(task.assigned_agent) if task.assigned_agent else None,
            parent_task_id=str(task.parent_task_id) if task.parent_task_id else None,
            priority=task.priority,
            metadata=task.metadata,
            created_at=task.created_at,
            updated_at=task.updated_at
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get task {task_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve task"
        )

@router.get("", response_model=List[TaskResponse])
async def list_tasks(
    project_id: Optional[str] = None,
    status: Optional[str] = None,
    assigned_agent_id: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    db: Session = Depends(get_db),
    token: str = Depends(verify_token)
):
    """List tasks with optional filtering."""
    try:
        query = db.query(Task)
        
        if project_id:
            query = query.filter(Task.project_id == UUID(project_id))
        
        if status:
            query = query.filter(Task.status == status)
        
        if assigned_agent_id:
            query = query.filter(Task.assigned_agent == UUID(assigned_agent_id))
        
        tasks = query.order_by(Task.created_at.desc()).offset(offset).limit(limit).all()
        
        return [
            TaskResponse(
                id=str(task.id),
                project_id=str(task.project_id),
                title=task.title,
                spec=task.spec,
                status=task.status,
                assigned_agent_id=str(task.assigned_agent) if task.assigned_agent else None,
                parent_task_id=str(task.parent_task_id) if task.parent_task_id else None,
                priority=task.priority,
                metadata=task.metadata,
                created_at=task.created_at,
                updated_at=task.updated_at
            )
            for task in tasks
        ]
        
    except Exception as e:
        logger.error(f"Failed to list tasks: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve tasks"
        )